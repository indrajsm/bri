const amqp = require("amqplib/callback_api")
const rabbitmqConfig = require("./index").rabbitmq

const connection_string = `amqp://${rabbitmqConfig.username}:${rabbitmqConfig.password}@${rabbitmqConfig.host}:${rabbitmqConfig.port}/${rabbitmqConfig.vhost}`
const exchange = rabbitmqConfig.exchange
const routing_key = rabbitmqConfig.routing_key

let channel
let rabbitmqConnected = false

//console.log('connection_string: ', connection_string);
 

/*
try {
    amqp.connect(connection_string, function(err, conn) {
        if (err) {
            throw err
        }

        rabbitmqConnected = true
        channel = conn.createChannel()
 
        exports.rabbitmqConnected = rabbitmqConnected
        exports.rabbitmqChannel = channel

        console.log('RabbitMQ connected!');
    })
} catch (error) {
    console.log('RabbitMQ error: ', error)
}
*/


amqp.connect(connection_string, function(err, conn) {
    if (err) {
        throw err
    }

    console.log('RabbitMQ connected!');

    rabbitmqConnected = true 
    channel = conn.createChannel()

    exports.rabbitmqConnected = rabbitmqConnected 
    exports.rabbitmqChannel = channel

    conn.on("close", function(err) {
        console.log('RabbitMQ close: ', err);
    })

    conn.on("error", function(err) {
        console.log('RabbitMQ error: ', err);
    })
})
 
exports.exchangeName = exchange
exports.routingKey = routing_key

