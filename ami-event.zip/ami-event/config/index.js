const dotenv = require('dotenv')
const env = process.env.NODE_ENV

if (env == 'production') {
	dotenv.config({ path: './.env-production' })
} else if (env == 'staging') {
	dotenv.config({ path: './.env-staging' })
} else {
	dotenv.config({ path: './.env' })
}


const config = {
	env: env,
	timezone: 'Asia/Jakarta',
	port: process.env.PORT || 3000,  
	socket_server: process.env.SOCKET_SERVER,
	ami: {
		host: process.env.AMI_HOST,
		port: process.env.AMI_PORT,
		username: process.env.AMI_USERNAME,
		password: process.env.AMI_PASSWORD,
		event: process.env.AMI_EVENT
	},
	rabbitmq: {
		host: process.env.MQ_HOST,
		port: process.env.MQ_PORT,
		username: process.env.MQ_USERNAME,
		password: process.env.MQ_PASSWORD,
		exchange: process.env.MQ_EXCHANGE,
		exchange: process.env.MQ_EXCHANGE,
		routing_key: process.env.MQ_ROUTING_KEY,
		vhost: process.env.MQ_VHOST 
    }, 
    redis: {
        host: process.env.CACHE_HOST,
		port: process.env.CACHE_PORT,
		db: process.env.CACHE_DB,
		password: process.env.CACHE_PASSWORD,
		expire: process.env.CACHE_DATA_DURATION || 3600, // in seconds 
    },
	
}
 
module.exports = config
