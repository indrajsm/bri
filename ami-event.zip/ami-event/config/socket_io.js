const  io = require('socket.io-client') 
const socketServer = require('./index').socket_server
const logger = require('../helper/logger')
let socketConnected = false

const socketOption = {
	reconnection: true,
	reconnectionAttempts: Infinity,
	reconnectionDelay: 1000,
	reconnectionDelayMax: 5000,
	randomizationFactor: 0.5, 
}

const socket = io.connect(socketServer, socketOption)

socket.on('connect', function(e) {
    socketConnected = true
    exports.socketConnected = socketConnected 
    console.log('Socket IO connected! SocketID:', socket.id)
    logger("debug", { from: "socket_io:connect", message: `Socket IO connected! SocketID: ${socket.id}`});
})

socket.on("disconnect", function(e) { 
    socketConnected = false
    exports.socketConnected = socketConnected
    console.log('Disconnected from socket server: ', e);
    logger("debug", { from: "socket_io:disconnect" ,message: `Disconnected from socket server: ${socket.id}`, event: e});
})

socket.on("reconnect", function(e) { 
    console.log('Reconnect to socket server ', e);
    logger("debug", { from: "socket_io:reconnect", message: `Reconnect to socket server`, event: e});
})

socket.on("reconnect_attempt", function(e) { 
    console.log('Reconnect Attempt: ', e);
    logger("debug", { from: "socket_io:reconnect_attempt",message: `Reconnect Attempt`, event: e});
})

socket.on("connect_error", function(e) { 
    console.log('connect_error ', e);
    logger("error", { from: "socket_io:error", event: e});
})


exports.socket = socket