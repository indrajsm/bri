const { createLogger, format, transports } = require('winston');
const { combine, timestamp, prettyPrint } = format;
const log = createLogger({
    format: combine( 
        timestamp(),
        prettyPrint()
    ),
    transports: [
        new transports.Console(),
        new transports.File({ filename: `./logs/errors/${new Date().toISOString().slice(0, 10)}-error.log`, level: 'error' }),
        new transports.File({ filename: `./logs/events/${new Date().toISOString().slice(0, 10)}-event.log`, level: 'debug', format: format.json() }),
    ],
});
const logger = (status, { from, message = "", event }) => {
    log.log({
        level: status,
        from: from,
        message: message,
        event: event
    });
}

module.exports = logger;