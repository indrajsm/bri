const socketConn = require('../config/socket_io')

function emit(message, data) {
    if (socketConn.socketConnected) {
        socketConn.socket.emit(message, data)
    }
}

exports.emit = emit