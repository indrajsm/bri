const redisConn = require('../config/redis')
const _ = require("lodash")

function setExpire(key, expire) {
    return new Promise(async(resolve, reject) => {
        if (!redisConn.redisConnected) {
            return resolve(false)
        }
        
        await redisConn.redisClient.expire(key, expire, (err, res) => {
            if (err) {
                console.error(res)
            }
        })
    })
}


function setData(key, field, data, expire = null) {
    return new Promise((resolve, reject) => {
        if (!redisConn.redisConnected) { 
            return reject()
        }

        redisConn.redisClient.hmset(key, field, data, (err, res) => {
            if (expire != null) {
                setExpire(key, expire)
               
            }

            resolve()
        })
    })
}


function getData(key, field) {
    return new Promise((resolve,reject) => {
        if (!redisConn.redisConnected) {
            return resolve(false)
        }

        redisConn.redisClient.hmget(key, field, (err, res) => {
            if (err) {
                return  resolve(err)
            }
            
            resolve(_.trim(res))
        })
    })
}


function deleteData(key, field) {
    return new Promise((resolve,reject) => {
        if (!redisConn.redisConnected) {
            return resolve(false)
        }

        redisConn.redisClient.hdel(key, field, (err, res) => {
            if (err) {
                return  resolve(err)
            }

            resolve(res)
        })
    })
}

exports.setData = setData
exports.getData = getData
exports.deleteData = deleteData