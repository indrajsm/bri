/**
 * referensi syntax Arguments in Asterisk 13 AMI Actions
 * https://wiki.asterisk.org/wiki/display/AST/Asterisk+13+AMI+Actions
 */
class AmiAction {
    constructor(ami) {
        this.ami = ami;
    }
    Action(options) {
        console.log(`sending ${options.action} command `);
        const unixTime = Math.floor(Date.now() / 1000)
        const amiOptions = {
            ...options,
            ActionID: unixTime
        }
        this.ami.action(amiOptions, function (err, res) {
            if (err) throw err;
            console.log('res callback: ', res);
        })
    }

    QueueStatus(queue) {
        const option = {
            'action': "QueueStatus",
            'queue': queue,
            'async': 'yes',
        }
        this.Action(option);
    }

    QueueAdd = (queue, extension) => {
        const option = {
            'action': "QueueAdd",
            'queue': queue,
            'paused': true,
            'interface': extension,
            'async': 'yes',
        }
        this.Action(option);
    }

    QueueRemove = (queue, extension) => {
        const option = {
            'action': "QueueRemove",
            'queue': queue,
            'interface': `SIP/${extension}`,
            'async': 'yes',
        }
        this.Action(option);
    }

    QueuePause = (queue, extension, isPaused) => {
        const option = {
            'action': 'QueuePause',
            'queue': queue,
            'interface': `SIP/${extension}`,
            'paused': isPaused,
            'async': 'yes',
        }
        this.Action(option);
    }

    Originate(extension, number) {
        const option = {
            'action': 'QueuePause',
            'channel': `SIP/${extension}`,
            'context': 'default',
            'exten': number,
            'priority': 1,
            'async': 'yes',
        }
        this.Action(option);
    }
}

module.exports = AmiAction;