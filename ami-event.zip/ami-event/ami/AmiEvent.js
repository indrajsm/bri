const logger = require('../helper/logger');
const _ = require("lodash")
const moment = require('moment')
const socketIOHelper = require("../helper/socket_io")
const rabbitmqHelper = require("../helper/rabbitmq")
const redisHelper = require("../helper/redis")

const connect = (e) => {
    console.log('AMI connected!');
    logger("debug", { from: "AmiEvent:connect", message: "AMI connected!" });
};

const close = (e) => {
    console.log('close: ', e);
    logger("debug", { from: "AmiEvent:close", message: "AMI Close!" });
};

const disconnect = (e) => {
    console.log('disconnect: ', e);
    logger("debug", { from: "AmiEvent:disconnect", message: "AMI Disconnect!" });
};

const error = (e) => {
    console.log('error: ', e);
    logger("debug", { from: "AmiEvent:error", message: e });
    ami.disconnect()
};


//===== AMI Events

/**
 * PeerStatus
 * Raised when the state of a peer changes
 */
const peerstatus = async (evt) => {
    const eventTime = moment(new Date()).format("YYYY-MM-DD HH:mm:ss")
    evt.eventtime = eventTime
    console.log('=======PeerStatus: ', evt)

    const peer = evt.peer
    const peerStatus = evt.peerstatus
    const extNo = _.replace(peer, 'SIP/', '')

    const cacheKey = `ext:${extNo}`
    const cacheField = 'status'
    const cacheData = peerStatus
    redisHelper.setData(cacheKey, cacheField, cacheData)
    rabbitmqHelper.publishData(evt)

    logger("debug", { from: "AmiEvent:peerstatus", event: evt });
};


/**
 * Hangup
 * Raised when a channel is hung up.
 */
const hangup = (evt) => {
    const eventTime = moment(new Date()).format("YYYY-MM-DD HH:mm:ss")
    evt.eventtime = eventTime
    console.log('=======HangupEvent: ', evt)

    rabbitmqHelper.publishData(evt)
    if (evt.channelstate !== '5') {
        if (evt.context.includes("callout")) {
            const socketEvt = { ...evt, ...{ interface: `SIP/${evt.connectedlinenum}`, } }
            socketEvt.channel = null
            socketNotifyAgent(socketEvt)
        } else {
            const socketEvt = { ...evt, ...{ interface: `SIP/${evt.calleridnum}`, } }
            socketNotifyAgent(socketEvt)
        }
        logger("debug", { from: "AmiEvent:hangup", event: evt });
    }

};


/**
 * QueueCallerJoin
 * Raised when a caller joins a Queue.
 */
const queuecallerjoin = (evt) => {
    const eventTime = moment(new Date()).format("YYYY-MM-DD HH:mm:ss")
    evt.eventtime = eventTime
    console.log('=======QueueCallerJoin: ', evt)

    rabbitmqHelper.publishData(evt)
    socketIOHelper.emit('mon-call-count', evt)
    logger("debug", { from: "AmiEvent:queuecallerjoin", event: evt });
};


/**
 * QueueCallerLeave
 * Raised when a caller leaves a Queue.
 */
const queuecallerleave = (evt) => {
    const eventTime = moment(new Date()).format("YYYY-MM-DD HH:mm:ss")
    evt.eventtime = eventTime
    console.log('=======QueueCallerLeave: ', evt)

    rabbitmqHelper.publishData(evt)
    socketIOHelper.emit('mon-call-count', evt)
    logger("debug", { from: "AmiEvent:queuecallerleave", event: evt });
};

/**
 * BridgeEnter
 * Raised when a channel enters a bridge.
 */
const bridgeenter = async (evt) => {
    const eventTime = moment(new Date()).format("YYYY-MM-DD HH:mm:ss")
    evt.eventtime = eventTime
    console.log('=======BridgeEnterEvent: ', evt)
    console.log(evt.context.includes('ext-queues'))
    // if (!evt.context.includes('ext-queues') && !evt.context.includes('from-internal')) {
    if (!evt.context.includes('ext-queues')) {
        var interface
        if (evt.context.includes('from-trunk-sip-OUT')) {
            cacheKey = `call-out:${evt.linkedid}`
            cacheField = 'ext'
            interface = await redisHelper.getData(cacheKey, cacheField)
        }

        else {
            interface = evt.channel.split('-')[0]
        }

        data_event = {
            event: evt.event,
            eventtime: evt.eventtime,
            interface: interface,
            uniqueid: evt.uniqueid,
            channel: evt.channel,
            calleridnum: evt.calleridnum,
            queue: evt.context,
            connectedlinenum: evt.connectedlinenum

        }
        console.log(data_event)
        socketNotifyAgent(data_event)
    }

    rabbitmqHelper.publishData(evt)
};


/**
 * AgentCalled
 * Raised when an queue member is notified of a caller in the queue.
 */
const agentcalled = (evt) => {
    const eventTime = moment(new Date()).format("YYYY-MM-DD HH:mm:ss")
    evt.eventtime = eventTime
    console.log('=======AgentCalledEvent: ', evt)

    rabbitmqHelper.publishData(evt)
    logger("debug", { from: "AmiEvent:agentcalled", event: evt });
};


/**
 * AgentConnect
 * Raised when a queue member answers and is bridged to a caller in the queue.
 */
const agentconnect = (evt) => {
    const eventTime = moment(new Date()).format("YYYY-MM-DD HH:mm:ss")
    evt.eventtime = eventTime
    console.log('=======AgentConnectEvent: ', evt)

    rabbitmqHelper.publishData(evt)
    socketNotifyAgent(evt)
    logger("debug", { from: "AmiEvent:agentconnect", event: evt });
};


/**
 * AgentComplete
 * Raised when a queue member has finished servicing a caller in the queue.
 */
const agentcomplete = (evt) => {
    const eventTime = moment(new Date()).format("YYYY-MM-DD HH:mm:ss")
    evt.eventtime = eventTime
    console.log('=======AgentCompleteEvent: ', evt)

    rabbitmqHelper.publishData(evt)
    socketNotifyAgent(evt)
    logger("debug", { from: "AmiEvent:agentcomplete", event: evt });
};


/**
 * QueueMemberAdded
 * Raised when a member is added to the queue.
 */
const queuememberadded = (evt) => {
    const eventTime = moment(new Date()).format("YYYY-MM-DD HH:mm:ss")
    evt.eventtime = eventTime
    console.log('=======QueueMemberAdded: ', evt)

    rabbitmqHelper.publishData(evt)
    storeQueueMemberToCache(evt)
};


/**
 * QueueMemberRemoved
 * Raised when a member is removed from the queue.
 */
const queuememberremoved = (evt) => {
    const eventTime = moment(new Date()).format("YYYY-MM-DD HH:mm:ss")
    evt.eventtime = eventTime
    console.log('=======QueueMemberRemoved: ', evt)

    rabbitmqHelper.publishData(evt)
    deleteQueueMemberFromCache(evt)
    logger("debug", { from: "AmiEvent:queuememberremoved", event: evt });
};


/**
 * QueueMemberPause
 * Raised when a member is paused/unpaused in the queue.
 */
const queuememberpause = (evt) => {
    const eventTime = moment(new Date()).format("YYYY-MM-DD HH:mm:ss")
    evt.eventtime = eventTime
    console.log('=======QueueMemberPause: ', evt)
    rabbitmqHelper.publishData(evt)

    storeQueueMemberToCache(evt)
    logger("debug", { from: "AmiEvent:queuememberpause", event: evt });
};


/**
 * QueueMember
 * Raised when QueueStatus command fired
 */
const queuemember = (evt) => {
    const eventTime = moment(new Date()).format("YYYY-MM-DD HH:mm:ss")
    evt.eventtime = eventTime

    console.log('=======QueueMember: ', evt)
    rabbitmqHelper.publishData(evt)
    // logger("debug",{from:"AmiEvent:queuemember", event:evt});
};


/**
 * UserEvent
 * user defined event raised from the dialplan.
 */
const userevents = (evt) => {
    const eventTime = moment(new Date()).format("YYYY-MM-DD HH:mm:ss")
    evt.eventtime = eventTime
    console.log('=======UserEvent: ', evt)

    if (evt.userevent === 'incoming-call') {
        //socketIOHelper.emit('incoming-call', evt)
        rabbitmqHelper.publishData(evt)
    }
    logger("debug", { from: "AmiEvent:userevent", event: evt });
};


/**
 * OriginateResponse
 * Raised in response to an Originate command.
 */
const originateresponse = (evt) => {
    const eventTime = moment(new Date()).format("YYYY-MM-DD HH:mm:ss")
    evt.eventtime = eventTime
    console.log('=======OriginateResponse: ', evt)

    if (evt.actionid.includes("outbound-")) {
        const expired = 3600
        const callId = evt.actionid.split('-')[1]
        const cacheKey = `call-out:${evt.uniqueid}`
        const cacheField = 'call_id'
        const cacheData = callId

        redisHelper.setData(cacheKey, cacheField, cacheData, expired)

        const cacheFieldExt = 'ext'
        const cacheDataExt = evt.channel.split('-')[0]

        redisHelper.setData(cacheKey, cacheFieldExt, cacheDataExt, expired)
        rabbitmqHelper.publishData(evt)
        const data_event = { ...evt, ...{ interface: evt.channel.split("-")[0] } }

        console.log(data_event)
        if (typeof evt.interface !== "undifined") {
            socketNotifyAgent(data_event)
        }

    }
    if (evt.context.includes("app-chanspy")) {
        data_event = {
            event: evt.event,
            eventtime: evt.eventtime,
            interface: evt.channel.split('-')[0],
            uniqueid: evt.uniqueid,
            channel: evt.channel,
            calleridnum: evt.calleridnum,
            queue: null
        }
        console.log(data_event)
        socketNotifyAgent(data_event)
    }
    logger("debug", { from: "AmiEvent:originateresponse", event: evt });
};


const events = {
    'connect': connect,
    'close': close,
    'disconnect': disconnect,
    'error': error,
    'peerstatus': peerstatus,
    'hangup': hangup,
    'queuecallerjoin': queuecallerjoin,
    'queuecallerleave': queuecallerleave,
    'bridgeenter': bridgeenter,
    'agentcalled': agentcalled,
    'agentconnect': agentconnect,
    'agentcomplete': agentcomplete,
    'queuememberadded': queuememberadded,
    'queuememberremoved': queuememberremoved,
    'queuememberpause': queuememberpause,
    'queuemember': queuemember,
    'userevent': userevents,
    'originateresponse': originateresponse
}

const socketNotifyAgent = async (evt) => {

    const interface = evt.interface
    const extNo = _.replace(interface, 'SIP/', '')
    console.log(evt.event, extNo)

    // get socket id from cache
    let cacheKey = `ext:${extNo}`
    let cacheField = 'socket_id'
    let socketId = await redisHelper.getData(cacheKey, cacheField)

    if (socketId !== 'null') {
        // get call id from cache
        cacheKey = `call-in:${evt.uniqueid}`
        cacheField = 'call_id'
        let callId = await redisHelper.getData(cacheKey, cacheField)
        if (callId === 'null') {
            callId = 0
        }

        // remove quotes
        socketId = socketId.replace(/['"]+/g, '')

        const socketMessage = {
            event: evt.event,
            event_time: evt.eventtime,
            socket_id: socketId,
            unique_id: evt.uniqueid,
            call_id: callId,
            channel: evt.channel,
            destchannel: evt.destchannel || null,
            extension: extNo,
            caller_id: evt.calleridnum,
            queue: evt.queue,
            context: evt.context || null
        }
        console.log(socketMessage)
        socketIOHelper.emit(evt.event, JSON.stringify(socketMessage))
    }
}

const storeQueueMemberToCache = (evt) => {
    const interface = evt.interface
    const pause = evt.paused
    const extNo = _.replace(interface, 'SIP/', '')

    const queue = evt.queue
    const cacheKey = `queue:${queue}`
    const cacheField = extNo
    const cacheData = pause === '0' ? true : false

    redisHelper.setData(cacheKey, cacheField, cacheData)
}


const deleteQueueMemberFromCache = (evt) => {
    const interface = evt.interface
    const extNo = _.replace(interface, 'SIP/', '')

    const queue = evt.queue
    const cacheKey = `queue:${queue}`
    const cacheField = extNo

    redisHelper.deleteData(cacheKey, cacheField)
}

const AmiEvent = (ami) => {
    try {
        for (const key in events) {
            ami.on(`${key}`, events[key]);
        }
    } catch (err) {
        logger("error", { from: "AmiEvent", event: err });
    }
}

module.exports = AmiEvent;