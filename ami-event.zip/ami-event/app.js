const asterisk = require("asterisk-manager");
const config = require('./config').ami;
const logger = require('./helper/logger');
const AmiAction = require("./ami/AmiAction");
const ListenAmiEvent = require("./ami/AmiEvent");
const ami = new asterisk(
    config.port,
    config.host,
    config.username,
    config.password,
    config.event
);
try {
    ami.keepConnected();
    ListenAmiEvent(ami);
    const action = new AmiAction(ami);
    // setInterval(() => action.QueueStatus(8001), 5000);
} catch (e) {
    console.log('error: ', e);
    logger("error", { from: "App.js", message: e.getMessage });
}


module.exports = ami;