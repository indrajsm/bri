//const amqp = require("amqplib/callback_api")
const rabbitmqConfig = require("./index").rabbitmq
const connection_string = `amqp://${rabbitmqConfig.username}:${rabbitmqConfig.password}@${rabbitmqConfig.host}:${rabbitmqConfig.port}/${rabbitmqConfig.vhost}`

exports.connString = connection_string
exports.exchangeName = rabbitmqConfig.exchange
exports.queueName = rabbitmqConfig.queue
exports.routingKey = rabbitmqConfig.routing_key

