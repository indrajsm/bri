const rabbitmqHelper = require("./helper/rabbitmq")
const logger = require("./helper/logger")

try{
    rabbitmqHelper.listen()
    logger("debug",{from:"app",message:"Running..."})
}catch(e){
    logger("error",{from:"app",event:e})
}
 