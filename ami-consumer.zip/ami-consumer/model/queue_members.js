const db = require('../config/database')
const table = "queue_members";
class queue_members {
    static async insert(data) {
        return await db.insert(data)
            .into(table)
            .then(res => res[0]);
    }

    static async update(id, data) {
        return await db(table).where({ id: id }).update(data)
    }

    static async insertUpdate(where, isPaused) {
        db.select('id').where(where).table(table).then(res => {
            if (res.length > 0) {
                return db(table).where({ id: res[0].id }) //Update Data
                    .update(isPaused)
                    .then(res => res[0]);
            } else {
                return db.insert({ ...where, ...isPaused }) //Insert Data
                    .into(table)
                    .then(res => res[0]);
            }
        }).catch(err => {
            console.log(err);
        })
    }

}

module.exports = queue_members;