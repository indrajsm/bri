const db = require('../config/database')
const table = "extensions";
class extensions {
    static async updateByExtension(ext, data) {
        return await db(table).where({ ext_no: ext }).update(data)
    }

    static async insertUpdate(ext, data) {
        db.select('id').where({ ext_no: ext }).table(table).then(res => {
            if (res.length > 0) {
                return db(table).where({ id: res[0].id }) //Update Data
                    .update(data)
                    .then(res => res[0]);
            } else {
                return db.insert({ ...{ ext_no: ext }, ...data }) //Insert Data
                    .into(table)
                    .then(res => res[0]);
            }
        }).catch(err => {
            console.log(err);
        })
    }

    static async getUserIdByExt(ext) {
        const get = await db.select('user_id').where({ ext_no: ext }).table(table)
        console.log(get[0].user_id)
        return get[0].user_id
    }
}

module.exports = extensions;