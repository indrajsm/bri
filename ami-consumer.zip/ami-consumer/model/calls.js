const db = require('../config/database')
const table = "calls";
class calls {
    static async getById(id) {
        return db.select("*").where({ id: id }).table(table)
            .then(res => res[0])
            .catch(err => console.error(err))
    }


    static async getByUniqueId(uniqueid) {
        return db.select("id").where({ unique_id_2: uniqueid }).table(table)
            .then(res => res[0])
            .catch(err => console.error(err))
    }

    static async getCallCount() {
        return db("view_monitor_call_count").select("*")
            .then(res => res[0])
            .catch(err => console.error(err))
    }

    static async insert(data) {
        return await db.insert(data)
            .into(table).then(res => res[0]) //mengembalikan userId
            .catch(err => console.error(err))
    }

    static async update(unique_id, data) {
        return await db.table(table)
            .where({ id: unique_id }).update(data)
            .then(res => res[0])
            .catch(err => console.error(err))
    }

    static async updateById(id, data) {
        
        
        return await db.table(table)
            .where({ id:id }).update(data)
            .then(res => res[0])
            .catch(err => console.error(err))
    }

    static async updateHangup(data) {
      
        db.select(['id', 'call_state_id', 'pickup_date']).where({ unique_id: data.uniqueid }).table(table).then(res => {
            const calls = {}; 
            if (res[0] != undefined) {
                const { id, call_state_id, pickup_date } = res[0];
                if ([1, 2, 3, 4].includes(call_state_id)) {
                    if (pickup_date != null) {
                        calls.media_status_id = 12
                    } else {
                        calls.media_status_id = 13
                        calls.media_status_detail_id = mediaStatusDetails[call_state_id]
                    }
                    calls.hangup_date = data.hangup_date;
                   
                    return this.updateById(id, calls)
                        .then(res => res)
                        .catch(err => console.error(err))
                }
                else {
                    calls.hangup_date = data.hangup_date;
                    return this.updateById(id, calls)
                        .then(res => res)
                        .catch(err => console.error(err))
                }

            }

        }).catch(err => {
            console.log(err);
        })
    }

    static async delete(id) {
        return db.table(table).where({ id: id }).del()
            .then(res => res[0])
            .catch(err => console.error(err))
    }
}
const mediaStatusDetails = {
    1: 3, // Abandon IVR 1 adalah call_state_id 3 adalah media_status_detail_id
    2: 4, // Abandon QUEUE 2 adalah call_state_id 4 adalah media_status_detail_id
    3: 5, // Abandon AGENT 3 adalah call_state_id 5 adalah media_status_detail_id
    4: 6  // Abandon VOICEMAIL 4 adalah call_state_id 6 adalah media_status_detail_id
}
module.exports = calls;