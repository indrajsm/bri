const db = require('../config/database')
const table = "users";
class calls {
    static async getUserByExt(ext){
        const get = await db.select().where({ ext_inbound: ext }).table(table)
        return get[0];
    }
    static async insert(data) {  
         return await db.insert(data).into(table).then(res => res[0]); 
    } 

    static async updateById(id, data) {
        return await db(table).where({ id: id }).update(data)
    } 

    static async delete(id) {
        return db(table).where({ id: id }).del()
    }
}

module.exports = calls;