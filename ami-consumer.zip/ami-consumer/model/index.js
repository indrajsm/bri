  
const fs = require('fs');
const pathFolder = "./model";
let files = {};

fs.readdir(pathFolder, function (err, modules) {
    if (err) {
        throw err;
    }
    modules.filter(function (module) { return module.slice(module.length - 3) === '.js'; }).forEach(function (module) { 
        if (module != "index.js"){ 
            files[module.replace(".js","")] = require(`./${module}`);
        }
     });
});

module.exports = files;