const socketConn = require('../config/socket_io')
const redisHelper = require("../helper/redis")
const _ = require("lodash")
exports.socketNotifyAgent = async (evt) => {
    const interface = evt.interface
    const extNo = _.replace(interface, 'SIP/', '')
    // get socket id from cache
    let cacheKey = `ext:${extNo}`
    let cacheField = 'socket_id'
    let socketId = await redisHelper.getData(cacheKey, cacheField)  
    if (socketId !== 'null') {
        // get call id from cache
        cacheKey = `call-in:${evt.uniqueid}`
        cacheField = 'call_id'
        let callId = await redisHelper.getData(cacheKey, cacheField)
        if (callId === 'null') {
            callId = 0
        }

        // remove quotes
        socketId = socketId.replace(/['"]+/g, '')

        const socketMessage = {
            event: evt.event,
            event_time: evt.eventtime,
            socket_id: socketId,
            unique_id: evt.uniqueid,
            call_id: callId,
            channel: evt.channel,
            extension: evt.extension,
            caller_id: evt.calleridnum,
            queue: evt.queue
        }

        emit(evt.event, JSON.stringify(socketMessage))
    }
}

function emit(message, data) {
    if (socketConn.socketConnected) {
        socketConn.socket.emit(message, data)
    }
}

exports.emit = emit