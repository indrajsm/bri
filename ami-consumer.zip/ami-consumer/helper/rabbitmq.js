const amqp = require("amqplib")
const rabbitmqConfig = require("../config/rabbitmq")
const socketIOHelper = require("../helper/socket_io")
const redisHelper = require("../helper/redis")
const modelCalls = require('../model/calls');

const model = require('../model');
const config = require('../config/index')
const axios = require('axios').default;
const userEventHandler = async (data) => {
    const dataCall = {
        direction_id: "INBOUND",
        call_state_id: 1,
        channel: data.channel,
        unique_id: data.uniqueid,
        phone_number: data.calleridnum,
        call_date: data.eventtime,
        ivr_date: data.eventtime,
        created_at: data.eventtime
    }
    const insertId = await model.calls.insert(dataCall);
    const cacheKey = `call-in:${data.uniqueid}`
    const cacheField = 'call_id'
    const cacheData = insertId
    const expired = 3600;
    redisHelper.setData(cacheKey, cacheField, cacheData, expired)
    handleSocketCountCall();
    console.table(data);
}

const peerStatusHandler = async (data) => {
    const { peer, peerstatus } = data;
    const ext = peer.split("/")[1];
    const dataExtension = {
        peer_status: peerstatus
    }
    await model.extensions.updateByExtension(ext, dataExtension);
    console.table(data);
}

const queueCallerJoinHandler = async (data) => {
    const { uniqueid, eventtime } = data;
    let cacheKey = `call-in:${uniqueid}`
    let cacheField = 'call_id'
    let callId = await redisHelper.getData(cacheKey, cacheField)
    const dataCall = {
        call_state_id: 2,
        leave_date: null,
        ringing_date: null,
        queue_date: eventtime
    }
    await model.calls.updateById(callId, dataCall);
    handleSocketCountCall();
    console.table(data);
}

const queueCallerLeaveHandler = async (data) => {
    const { uniqueid, eventtime } = data;
    let cacheKey = `call-in:${uniqueid}`
    let cacheField = 'call_id'
    let callId = await redisHelper.getData(cacheKey, cacheField)
    const dataCall = {
        leave_date: eventtime
    }
    await model.calls.updateById(callId, dataCall);
    handleSocketCountCall();
    console.table(data);
}

const queueMemberAddHandler = async (data) => {
    console.table(data);
}

const queueMemberPauseHandler = async (data) => {
    const { queue, membername, paused } = data;
    const where = { queue: queue, extension: membername.split("/")[1] };
    const isPaused = { is_paused: paused };
    await model.queue_members.insertUpdate(where, isPaused);
    console.table(data);
}

const queueMemberRemoveHandler = async (data) => {
    console.table(data);
}

const agentCalledHandler = async (data) => {
    const { uniqueid, eventtime, destchannel, calleridnum, queue, interface } = data;
    const dataCall = {
        ringing_date: eventtime,
        call_state_id: 3
    }
    await model.calls.update(uniqueid, dataCall);
    const socketEvt = {
        "event": data.event,
        "event_time": eventtime,
        "interface": "",
        "uniqueid": uniqueid,
        "channel": destchannel,
        "extension": calleridnum,
        "caller_id": 3,
        "interface": interface,
        "queue": queue
    }
    socketIOHelper.socketNotifyAgent(socketEvt)

    console.table(dataCall);
}

// const agentConnectHandler = async (data) => {
//     const { queue, uniqueid, eventtime, connectedlinenum } = data;
//     QueueMemberPause(queue, connectedlinenum, true);
//     const user_id = await model.extensions.getUserIdByExt(connectedlinenum)
//     const dataCall = {
//         pickup_date: eventtime,
//         user_id: (typeof user_id !== 'undefined') ? user_id : null,
//         extension: connectedlinenum
//     }
//     await model.calls.update(uniqueid, dataCall);
//     await model.users.updateById(user_id, { user_activity_id: 5 })
//     console.table(data);
// }

// const agentCompleteHandler = async (data) => {
//     const { uniqueid, eventtime, connectedlinenum, queue } = data;
//     QueueMemberPause(queue, connectedlinenum, false);
//     const dataCall = {
//         dropcall_date: eventtime
//     }
//     const user_id = await model.extensions.getUserIdByExt(connectedlinenum)
//     await model.calls.update(uniqueid, dataCall);
//     await model.users.updateById(user_id, { user_activity_id: 2 })
//     console.table(data);
// }

const hangupHandler = async (data) => {
    console.table(data);
    const { uniqueid, eventtime, context } = data;
    if (data.context.includes("CTX_CALL_ANSWER")) {     


        let callId  = await modelCalls.getByUniqueId(uniqueid)
        const callID = Object.values(callId)
        
        
        const dataCall = {

            hangup_date: eventtime
        }

        
        await modelCalls.updateById(callID, dataCall);
    }

    //  handleSocketCountCall(); 
}

// const originateResoneHandler = async (data) => {
//     console.table(data);
//     const { uniqueid, eventtime, actionid, channel } = data;
//     if (data.actionid.includes("outbound-")) {
//         const callId = actionid.split('-')[1]

//         const ext = channel.split('-')[0].split('/')[1]

//         const user_id = await model.extensions.getUserIdByExt(ext)

//         const dataCall = {
//             unique_id: uniqueid,
//             call_date: eventtime,
//             channel: channel,
//             user_id: user_id
//         }

//         await model.calls.updateById(callId, dataCall);
//         await model.users.updateById(user_id, { user_activity_id: 5 })
//         const socketEvt = { ...data, ...{ interface: data.channel.split("-")[0] } }
//         socketIOHelper.socketNotifyAgent(socketEvt)
//     }
//     // handleSocketCountCall(); 
// }

// const bridgeEnterHandler = async (data) => {
//     console.table(data);
//     const { uniqueid, connectedlinenum } = data;
//     if (data.context.includes('macro-dial-one')) {
//         const user_id = await model.extensions.getUserIdByExt(connectedlinenum)
//         const dataCall = {
//             user_id: (typeof user_id !== 'undefined') ? user_id : null,
//             extension: connectedlinenum
//         }
//         await model.calls.update(uniqueid, dataCall);
//     }

// }

const handleSocketCountCall = async () => {
    const getCountCall = await modelCalls.getCallCount();
    console.table(getCountCall);
    socketIOHelper.emit("mon-call-count", getCountCall);
}

// const QueueMemberPause = (queue, extension, isPaused) => {
//     axios.put(`http://${config.ami.host}:3000/queues/${queue}/member_statuses`, {
//         extension: extension,
//         is_paused: isPaused
//     }).then(res => {
//         const { data } = res.data
//         console.log(data)
//     }).catch(err => {
//         console.log(err)
//     })
// }


const eventConsumer = {
    'UserEvent': userEventHandler,
    'PeerStatus': peerStatusHandler,
    // 'QueueCallerJoin': queueCallerJoinHandler,
    // 'QueueCallerLeave': queueCallerLeaveHandler,
    // 'QueueMemberAdd': queueMemberAddHandler,
    // 'QueueMemberPause': queueMemberPauseHandler,
    // 'QueueMemberRemove': queueMemberRemoveHandler,
    // 'AgentCalled': agentCalledHandler,
    // 'AgentConnect': agentConnectHandler,
    // 'AgentComplete': agentCompleteHandler,
    'Hangup': hangupHandler,
    // 'OriginateResponse': originateResoneHandler,
    // 'BridgeEnter': bridgeEnterHandler,
}

const consumer = (channel) => {
    return new Promise((resolve, reject) => {
        channel.consume(rabbitmqConfig.queueName, async function (msg) {
            let msgBody = msg.content.toString();
            let data = JSON.parse(msgBody);
            if (eventConsumer[String(data.event)]) {
                eventConsumer[String(data.event)](data);
            }
            await channel.ack(msg);
            resolve()
        })
    })
}

const listen = async () => {
    let connection = await amqp.connect(rabbitmqConfig.connString)
    let channel = await connection.createChannel()
    await channel.prefetch(1);
    consumer(channel)
}
exports.listen = listen