const _ = require('lodash')
const dbQueryHelper = require('./lib/db_query')
const fs = require('fs')
const nodemailer = require('nodemailer')
const { email } = require('./config')

const args = process.argv.slice(2)
let emailStatus = ''
let table = 'emails'
const currentDate = new Date()

if (!_.isEmpty(args)) {
	emailStatus = args[0]
}

const emailStatusInit = (emailStatus == 'error') ? email.status.error : email.status.queued

const getTemplate = async (data) => {
	const outboundTemplate = fs.readFileSync(email.outbound.templateFile, 'utf8')
	const bodyTemplate = eval('`' + outboundTemplate + '`')

	return bodyTemplate
}

const getEmail = async () => {
	let customConditions = []


	let conditionTypes = {
		'date': ['created_at', 'created', 'updated']
	}

	let conditions = {
		'email_status_id': emailStatusInit,
		'direction_id': 2,
		'is_complete': 1,
		//'created_at': currentDate.toISOString().slice(0, 10) // current date
	}
	let join = [
		`JOIN campaigns ON campaigns.id = ${table}.campaign_id`,
		`JOIN customers ON customers.id = ${table}.customer_id`,
	]
	customConditions.push(`CURRENT_TIMESTAMP BETWEEN campaigns.start_date AND campaigns.end_date AND campaigns.is_active = 1 AND customers.is_active = 1  `)


	const data = await dbQueryHelper.getAll({ table, conditions, conditionTypes, customConditions, join })
	const dataResult = data.data
	if (_.isEmpty(data.data)) {
		console.log('Email Not Found')
	}

	return dataResult
}




const getAttachments = async (table, id) => {
	let conditions = {
		'email_id': id
	}

	const dataAttachments = await dbQueryHelper.getAll({ table, conditions })
	const attachments = dataAttachments.data
	let arrAttachments = []

	if (!_.isEmpty(attachments)) {
		let i = 0

		attachments.forEach((row) => {
			let filename = `${row.path}/${row.filename}`

			if (fs.existsSync(filename)) {
				// only file exists
				arrAttachments[i] = {
					filename: row.filename,
					path: filename
				}
			}

			i++
		})
	}

	return arrAttachments
}

const sendEmail = async () => {
	// get email data
	const dataResult = await getEmail()

	if (!_.isEmpty(dataResult)) {

		// init email connection
		const transporter = nodemailer.createTransport({
			host: email.outbound.host,
			port: email.outbound.port,
			auth: {
				user: email.outbound.username,
				pass: email.outbound.password
			}
		})

		// loop email data
		dataResult.forEach(async (row) => {
			let mailOptions = {
				from: `${email.outbound.fromName} <${email.outbound.from}>`,
				to: row.email_to,
				subject: row.subject,
				text: row.content,
				html: row.content_html
			}

			const email_content = row.content_html || row.content
			const dataTemplate = {
				email_content: email_content.trim().replace(/(?:\r\n|\r|\n)/g, '<br>'),
				domain_name: email.outbound.fromName,
				year: currentDate.getFullYear()
			}
			const bodyTemplate = (email.outbound.useTemplate) ? await getTemplate(dataTemplate) : email_content

			mailOptions['html'] = bodyTemplate;
			mailOptions['cc'] = row.email_cc
			mailOptions['bcc'] = row.email_bcc

			// get email attachments
			const attachments = await getAttachments('email_attachments', row.id)
			mailOptions['attachments'] = attachments

			console.log('=============================================')
			console.log('email data', mailOptions)

			// reset table and conditions
			//table = 'emails'
			conditions = {
				'id': row.id,
				'email_status_id': emailStatusInit
			}

			// update status to process
			const data = {
				'email_status_id': email.status.process
			}


			const updateToProcess = await dbQueryHelper.updateData({ table, data, conditions })
			
			if (updateToProcess.total_data != 1) {
				console.log(`Email ID: ${row.id}`, 'Failed to PROCESS')
				return; // if update failed, skip to the next data
			}


			// do send email
			transporter.sendMail(mailOptions, async (error, info) => {
				// reset conditions
				// conditions['email_status_id'] = email.status.process
				conditions = {
					'id': row.id,
					'email_status_id': email.status.process
				}
			

				if (error) {
					console.log(`Email ID: ${row.id}`, error.message);

					// update status to error
					const data = {
						'email_status_id': email.status.error,
						'mail_error_info': `${error.message} ${JSON.stringify(error)}`
					}
					const updateEmail = await dbQueryHelper.updateData({ table, data, conditions })
					

					if (updateEmail.total_data == 1) {
						console.log('data updated')
					}
				} else {
					// update status to sent
					const data = {
						email_status_id: email.status.sent,
						mail_date: 'NOW()'
					}
					const updateEmail = await dbQueryHelper.updateData({ table, data, conditions })
					console.log(`Email ID: ${row.id}`, 'Email sent: ' + info.response);
					if (updateEmail.total_data == 1) {
						console.log('data updated')
					}
				}
			});
		});

		// close email connection
		transporter.close()
	}
	 
}


exports.sender = sendEmail


