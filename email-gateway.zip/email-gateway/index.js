const sender = require('./sender')


const cron = require('node-cron'); 

let is_running = false

try {
    cron.schedule('*/5 * * * * *', function () {
  

        if (is_running === false) {
            
            is_running = true 
            sender.sender();
            
            is_running = false
        } else {
            console.log(`process is already running`);
        }
    });
 
} catch (error) {
    
}