const dotenv = require('dotenv')
const env = process.env.NODE_ENV

const envModeFile= {
	'production': './.env-production',
	'staging': './.env-staging',
	'development': './.env'
}
const fileConfig = (env in envModeFile) ? envModeFile[env] : envModeFile['development']

dotenv.config({path: fileConfig})

const config = {
	env: env,
	timezone: 'Asia/Jakarta',
	port: process.env.PORT || 3000,
	publicDir: process.env.PUBLIC_DIR || './public/',
	db: {
		user: process.env.DB_USER || '',
		password: process.env.DB_PASSWORD || '',
		host: process.env.DB_HOST || '',
		port: process.env.DB_PORT || 3306,
		name: process.env.DB_NAME || ''
	},
	email: {
		inbound: {
			host: process.env.EMAIL_HOST
		},
		outbound: {
			host: process.env.EMAIL_HOST,
			port: process.env.EMAIL_PORT,
			username: process.env.EMAIL_USERNAME,
			password: process.env.EMAIL_PASSWORD,
			from: process.env.EMAIL_SENDER_ADDRESS,
			fromName: process.env.EMAIL_SENDER_NAME,
			useTemplate: process.env.EMAIL_TEMPLATE_STATUS, //true,
			templateFile: process.env.EMAIL_TEMPLATE_FILE //'D:/node-arena/bri-tele/email-gateway/template/email.html'
		},
		status: {
			unread: 7,
			read: 8,
			queued: 1,
			sent: 2,
			error: 3,
			process: 4
		}
	},
	logDir: process.env.LOG_DIR
}


module.exports = config
