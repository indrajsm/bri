import Routes from "./route";
import PrivateRoute from "./privateRoute";
import ProtectedLogin from "./protectedLogin";

export { Routes, PrivateRoute, ProtectedLogin }