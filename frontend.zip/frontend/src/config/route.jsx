import { useContext, useEffect } from 'react'
import { BrowserRouter as Router, Switch, HashRouter } from 'react-router-dom'
import { Login, ForgotPassword, MainApp } from '../pages'
import { PrivateRoute, ProtectedLogin } from '.';

const Routes = () => {
    return (
        <HashRouter>
            <Switch>
                <ProtectedLogin path="/login" component={Login} />
                <ProtectedLogin path="/forgot" component={ForgotPassword} />
                <PrivateRoute path="/" component={MainApp} />
                {/* <Route path="/" component={MainApp} /> */}
                {/* <Route path="" component={Users} /> */}
            </Switch>
        </HashRouter>
    )
}

export default Routes
