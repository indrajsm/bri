import { useState, useEffect, useContext } from 'react'
import { Button, Form, Modal, Spinner, InputGroup } from 'react-bootstrap'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import { AuthContext } from './../utils/context'
import { useUsers } from './../utils/functions'
import { cookieService } from './../utils/services'
import { Notification } from './../components'

export const ModalPasswordExpired = (props) => {
    const fnUsers = useUsers()
    const userId = cookieService.Get('user_id')
    const [notifError, setNotifError] = useState(false)
    const [modalSuccess, setModalSuccess] = useState(false)
    const [passwordShow, setPasswordShow] = useState(false)
    const { passwordExpired, setPasswordExpired } = useContext(AuthContext)
    const { handleSubmit, formState: { errors, isSubmitting }, register, clearErrors } = useForm({
        defaultValues: {
            password: "",
            password_confirm: ""
        },
        resolver: yupResolver(yup.object().shape({
            password: yup.string()
                .required("This field is required.")
                .min(8, "This field must be at least 8 characters in length.")
                .matches(
                    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[#@$!%*?&-])[A-Za-z\d@#$!%*?&-]{8,}$/,
                    "This field must contain at least one uppercase letter, one lowercase letter, one number and one special character.",
                ),
            password_confirm: yup.string()
                .required("This field is required.")
                .oneOf([yup.ref('password'), ""], 'This field does not match to password.')
        }))
    })

    useEffect(() => {
        clearErrors()
        setNotifError(false)
        setModalSuccess(false)
        setPasswordShow(false)
    }, [])

    const onSubmitForm = async (data, e) => {
        e.preventDefault()

        await fnUsers.Update(userId, {password: data['password']}).then((res) => {
            if (res.success) {
                setModalSuccess(true)
                setPasswordExpired(false)
                localStorage.setItem('passwordExpired', false)
            } else {
                setNotifError(true)
            }
        }).catch((err) => { return }) //do nothing, let it go back to login
    }

    const togglePassword = () => {
        setPasswordShow(!passwordShow)
        document.getElementById('Password').focus()
    }

    return (
        <>
            <Modal show={passwordExpired} backdrop="static" keyboard={false}>
                <Modal.Header>
                    <Modal.Title>Password Expired</Modal.Title>
                </Modal.Header>
                <Form onSubmit={handleSubmit(onSubmitForm)}>
                    <Modal.Body className="pb-1">
                        {notifError && <Notification.Error
                            message="An error occured, please try again."
                            show={true}
                            showChange={() => { setNotifError(false) }}
                        />}
                        <p>Your current password has expired, please change your current password with a new password.</p>
                        <Form.Group controlId="Password">
                            <Form.Label>Password <span className="text-danger">*</span></Form.Label>
                            <InputGroup size="sm" className="mb-3">
                                <Form.Control
                                    // type="password"
                                    type={passwordShow ? 'text' : 'password'}
                                    size="sm"
                                    isInvalid={!!errors.password}
                                    {...register("password")}
                                />
                                <InputGroup.Append>
                                    <InputGroup.Text>
                                        <i className={`far ${passwordShow ? "fa-eye-slash" : "fa-eye"} fa-fw`} onClick={togglePassword} />
                                    </InputGroup.Text>
                                </InputGroup.Append>
                                <Form.Control.Feedback type="invalid">{errors.password?.message}</Form.Control.Feedback>
                            </InputGroup>
                        </Form.Group>
                        <Form.Group controlId="PasswordConfirm">
                            <Form.Label>Password Confirm <span className="text-danger">*</span></Form.Label>
                            <Form.Control
                                type="password"
                                size="sm"
                                isInvalid={!!errors.password_confirm}
                                {...register("password_confirm")}
                            />
                            <Form.Control.Feedback type="invalid">{errors.password_confirm?.message}</Form.Control.Feedback>
                        </Form.Group>
                    </Modal.Body>
                    <Modal.Footer>
                        <Button variant="primary" type="submit" disabled={isSubmitting}>
                            {isSubmitting && <Spinner animation="border" size="sm" className="mr-1" />} Save
                        </Button>
                    </Modal.Footer>
                </Form>
            </Modal>
            <ModalPasswordExpiredSuccess
                modalShow={modalSuccess}
                modalClose={() => setModalSuccess(false)}
            />
        </>
    )
}

const ModalPasswordExpiredSuccess = ({ modalShow, modalClose }) => {
    return (
        <Modal show={modalShow} onHide={modalClose}>
            <Modal.Header closeButton>
                <Modal.Title>Password Expired</Modal.Title>
            </Modal.Header>
            <Modal.Body className="text-center">
                <i className="far fa-check-circle fa-3x d-block text-primary"></i>
                <h5 className="mt-2 mb-0">Success</h5>
                <span className="text-muted">Your password has been updated.</span>
            </Modal.Body>
            <Modal.Footer className="">
                <Button variant="outline-primary" onClick={modalClose}>Close</Button>
            </Modal.Footer>
        </Modal>
    )
}