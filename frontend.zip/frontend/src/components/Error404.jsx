import { Jumbotron, Container } from 'react-bootstrap'

export const Error404 = (props) => {
    return (
        <Jumbotron fluid>
            <Container className="text-center">
                <h1 style={{fontSize: '80px'}}>404</h1>
                <p style={{fontSize: '20px'}}>
                    The page you are looking for was not found<br />
                    Or you are unauthorized to access this page
                </p>
            </Container>
        </Jumbotron>
    )
}