import { NavbarComp } from "./Navbar";
import { FooterComp } from "./Footer";
import { Sidebar } from "./Sidebar";
import Notification from "./Notification";
import { Pagination } from './Pagination'
import EditorToolbar, { modules, formats } from "./EditorToolbar";
import { CustomPlayer } from "./CustomPlayer";
import { CustomSelect } from "./CustomSelect";
import { ModalPasswordExpired } from "./ModalPasswordExpired";
import { Error404 } from "./Error404";

export { NavbarComp, FooterComp, Sidebar, Notification, Pagination, EditorToolbar, modules, formats, CustomPlayer, CustomSelect, ModalPasswordExpired, Error404 }
