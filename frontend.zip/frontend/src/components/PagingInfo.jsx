import { isInteger } from 'lodash'

const PagingInfo = ({ totalData, limit, page }) => {
    const dataInfo = (totalData, limit, page) => {
        let lowest = 0
        let highest = 0
        let total = totalData

        if (isInteger(page)) {
            if (page == 1) {
                lowest = 1
                highest = totalData

                if (totalData > limit) {
                    highest = limit
                }
            } else if (page > 1) {
                let countLowest = (limit * (page - 1)) + 1

                if (totalData >= countLowest) {
                    lowest = countLowest
                    highest = totalData

                    if (totalData > (limit * page)) {
                        highest = limit * page
                    }
                }
            }
        }

        return `Showing ${lowest} to ${highest} of ${total} entries`
    }

    return (
        <div>
            {dataInfo(totalData, limit, page)}
        </div>
    )
}

export default PagingInfo