import { useState, useContext } from "react";
import { Link, useRouteMatch } from 'react-router-dom'
import { NavLink } from 'react-bootstrap'
import classnames from 'classnames'
import { cookieService } from './../utils/services'

export const Sidebar = () => {
    const [openCampaign, setOpenCampaign] = useState(false)
    const [openReport, setOpenReport] = useState(false)
    const [openQualityAssurance, setOpenQualityAssurance] = useState(false)
    const [openSetting, setOpenSetting] = useState(false)
    const { path, url } = useRouteMatch();
    const userLevelId = localStorage.getItem('userLevelId')

    return (
        <div id="layoutSidenav_nav">
            <nav className="sb-sidenav accordion sb-sidenav-blue" id="sidenavAccordion">
                <div className="sb-sidenav-menu">
                    <div className="nav">
                        {userLevelId && [1,2,5].includes(parseInt(userLevelId)) &&
                            <Link className="active" to='/'>
                                <div className="nav-link">
                                    Dashboard
                                </div>
                            </Link>
                        }

                        {/* Campaign Group */}
                        {userLevelId && [1,2,5].includes(parseInt(userLevelId)) && <>
                            <NavLink onClick={() => setOpenCampaign(!openCampaign)} href="#" data-toggle="collapse">
                                Campaign
                                <div className="sb-sidenav-collapse-arrow">
                                    <i className={`fas ${openCampaign ? "fa-angle-left" : "fa-angle-down"}`} />
                                </div>
                            </NavLink>
                            <div className={classnames('collapse', { 'show': openCampaign })} data-parent="#sidenavAccordion">
                                <nav className="sb-sidenav-menu-nested nav">
                                    <Link className="active" to="/campaign-calls">
                                        <div className="nav-link">
                                            Calls
                                        </div>
                                    </Link>
                                    {userLevelId && [2,5].includes(parseInt(userLevelId)) &&
                                        <Link className="active" to="/campaign-emails">
                                            <div className="nav-link">
                                                Emails
                                            </div>
                                        </Link>
                                    }
                                </nav>
                            </div>
                        </>}
                        {/* End of Campaign Group */}

                        {userLevelId && [1,2,5].includes(parseInt(userLevelId)) &&
                            <Link className="active" to='/callback'>
                                <div className="nav-link">
                                    Scheduled Calls
                                </div>
                            </Link>
                        }

                        {userLevelId && [1,2,5].includes(parseInt(userLevelId)) &&
                            <Link className="active" to='/user-activity'>
                                <div className="nav-link">
                                    User Activity
                                </div>
                            </Link>
                        }

                        {/* Reports Group */}
                        {userLevelId && [2,5].includes(parseInt(userLevelId)) && <>
                            <NavLink onClick={() => setOpenReport(!openReport)} href="#" data-toggle="collapse">
                                Reports
                                <div className="sb-sidenav-collapse-arrow">
                                    <i className={`fas ${openReport ? "fa-angle-left" : "fa-angle-down"}`} />
                                </div>
                            </NavLink>
                            <div className={classnames('collapse', { 'show': openReport })} data-parent="#sidenavAccordion">
                                <nav className="sb-sidenav-menu-nested nav">
                                    <Link className="active" to="/reports/call-detail">
                                        <div className="nav-link">
                                            Call Detail
                                        </div>
                                    </Link>
                                    <Link className="active" to="/reports/call-customer">
                                        <div className="nav-link">
                                            Call Customer
                                        </div>
                                    </Link>
                                    <Link className="active" to="/reports/call-activity">
                                        <div className="nav-link">
                                            Call Activity
                                        </div>
                                    </Link>
                                    <Link className="active" to="/reports/performance-agent">
                                        <div className="nav-link">
                                            Performance Agent
                                        </div>
                                    </Link>
                                    <Link className="active" to="/reports/business-achievement">
                                        <div className="nav-link">
                                            Business Achievement
                                        </div>
                                    </Link>
                                    <Link className="active" to="/reports/break">
                                        <div className="nav-link">
                                            Break
                                        </div>
                                    </Link>
                                    <Link className="active" to="/reports/email">
                                        <div className="nav-link">
                                            Email
                                        </div>
                                    </Link>
                                    <Link className="active" to="/reports/cost-viewer">
                                        <div className="nav-link">
                                            Cost Viewer
                                        </div>
                                    </Link>
                                    <Link className="active" to="/reports/checker">
                                        <div className="nav-link">
                                            Checker
                                        </div>
                                    </Link>
                                </nav>
                            </div>
                        </>}
                        {/* End of Reports Group */}

                        {/* QA Group */}
                        <NavLink onClick={() => setOpenQualityAssurance(!openQualityAssurance)} href="#" data-toggle="collapse">
                            Quality Assurance
                            <div className="sb-sidenav-collapse-arrow">
                                <i className={`fas ${openQualityAssurance ? "fa-angle-left" : "fa-angle-down"}`} />
                            </div>
                        </NavLink>
                        <div className={classnames('collapse', { 'show': openQualityAssurance })} data-parent="#sidenavAccordion">
                            <nav className="sb-sidenav-menu-nested nav">
                                {parseInt(userLevelId) === 4 &&
                                    <Link className="active" to="/quality-assurance">
                                        <div className="nav-link">
                                            QA List
                                        </div>
                                    </Link>
                                }
                                {userLevelId && [2,3,4,5].includes(parseInt(userLevelId)) &&
                                    <Link className="active" to="/quality-assurance-calls">
                                        <div className="nav-link">
                                            QA Calls
                                        </div>
                                    </Link>
                                }
                                {userLevelId && [1,2,4,5].includes(parseInt(userLevelId)) &&
                                    <Link className="active" to="/quality-assurance-report-summaries">
                                        <div className="nav-link">
                                            QA Report Summaries
                                        </div>
                                    </Link>
                                }
                            </nav>
                        </div>
                        {/* End of QA Group */}

                        {/* Settings Group */}
                        {userLevelId && [2,5].includes(parseInt(userLevelId)) && <>
                            <NavLink onClick={() => setOpenSetting(!openSetting)} href="#" data-toggle="collapse">
                                Settings
                                <div className="sb-sidenav-collapse-arrow">
                                    <i className={`fas ${openSetting ? "fa-angle-left" : "fa-angle-down"}`} />
                                </div>
                            </NavLink>
                            <div className={classnames('collapse', { 'show': openSetting })} data-parent="#sidenavAccordion">
                                <nav className="sb-sidenav-menu-nested nav">
                                    <Link className="active" to='/setting/users'>
                                        <div className="nav-link">
                                            Users
                                        </div>
                                    </Link>
                                    <Link className="active" to='/setting/break-reason'>
                                        <div className="nav-link">
                                            Break Reason
                                        </div>
                                    </Link>
                                    <Link className="active" to='/setting/checking-reason'>
                                        <div className="nav-link">
                                            Checking Reason
                                        </div>
                                    </Link>
                                    <Link className="active" to='/setting/outbound-category'>
                                        <div className="nav-link">
                                            Outbound Category
                                        </div>
                                    </Link>
                                    <Link className="active" to='/setting/outbound-category-detail'>
                                        <div className="nav-link">
                                            Outbound Cat. Detail
                                        </div>
                                    </Link>
                                </nav>
                            </div>
                        </>}
                        {/* End of Settings Group */}

                        
    
                        {/*
                        // <div className="sb-sidenav-menu-heading">Interface</div>
                        // <div onClick={() => setOpen(!open)} className="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                        //     <div className="sb-nav-link-icon"><i className="fas fa-columns"></i></div>
                        //         Layouts
                        //     <div className="sb-sidenav-collapse-arrow"><i className="fas fa-angle-down"></i></div>
                        // </div>
                        // <Collapse in={open}>
                        // <div className="collapse" id="collapseLayouts" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
                        //     <nav className="sb-sidenav-menu-nested nav">
                        //         <div className="nav-link" href="layout-static.html">Static Navigation</div>
                        //         <div className="nav-link" href="layout-sidenav-light.html">Light Sidenav</div>
                        //     </nav>
                        // </div>
                        </Collapse>
                        <div onClick={() => setOpen2(!open2)} className="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="false" aria-controls="collapsePages">
                            <div className="sb-nav-link-icon"><i className="fas fa-book-open"></i></div>
                                Pages
                                <div className="sb-sidenav-collapse-arrow"><i className="fas fa-angle-down"></i></div>
                        </div>
                        <Collapse in={open2}>
                        <div className="collapse" id="collapsePages" aria-labelledby="headingTwo" data-parent="#sidenavAccordion">
                            <nav className="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionPages">
                                <div className="nav-link collapsed" href="#" data-toggle="collapse" data-target="#pagesCollapseAuth" aria-expanded="false" aria-controls="pagesCollapseAuth">
                                    Authentication
                                        <div className="sb-sidenav-collapse-arrow"><i className="fas fa-angle-down"></i></div>
                                </div>
                                <div className="collapse" id="pagesCollapseAuth" aria-labelledby="headingOne" data-parent="#sidenavAccordionPages">
                                    <nav className="sb-sidenav-menu-nested nav">
                                        <div className="nav-link" href="login.html">Login</div>
                                        <div className="nav-link" href="register.html">Register</div>
                                        <div className="nav-link" href="password.html">Forgot Password</div>
                                    </nav>
                                </div>
                                <div className="nav-link collapsed" href="#" data-toggle="collapse" data-target="#pagesCollapseError" aria-expanded="false" aria-controls="pagesCollapseError">
                                    Error
                                        <div className="sb-sidenav-collapse-arrow"><i className="fas fa-angle-down"></i></div>
                                </div>
                                <div className="collapse" id="pagesCollapseError" aria-labelledby="headingOne" data-parent="#sidenavAccordionPages">
                                    <nav className="sb-sidenav-menu-nested nav">
                                        <div className="nav-link" href="401.html">401 Page</div>
                                        <div className="nav-link" href="404.html">404 Page</div>
                                        <div className="nav-link" href="500.html">500 Page</div>
                                    </nav>
                                </div>
                            </nav>
                        </div>
                        </Collapse>
                        */}
                        {/*<div className="sb-sidenav-menu-heading">Addons</div>
                        <div className="nav-link" href="charts.html">
                            <div className="sb-nav-link-icon"><i className="fas fa-chart-area"></i></div>
                                Charts
                            </div>
                        <div className="nav-link" href="tables.html">
                            <div className="sb-nav-link-icon"><i className="fas fa-table"></i></div>
                                Tables
    </div>*/}
                    </div>
                </div>
                {/* <div className="sb-sidenav-footer">
                    <div className="small">Logged in as: {user || 'user'}</div>
                    <div className="small">Logged in as: user</div>
                    <Button variant="primary"><i className="fas fa-phone-alt"></i></Button>
                </div> */}
            </nav>
        </div >
    )
}

