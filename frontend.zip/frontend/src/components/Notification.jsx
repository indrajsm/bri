import React, { useState, useEffect } from 'react'
import { Alert } from 'react-bootstrap'
import _ from 'lodash'
// import { GeneralContext } from '../context/GeneralContext'

const Error = ({ title = "", message = "", show, showChange }) => {
    const [showAlert, setShowAlert] = useState(true)

    useEffect(() => {
        if (show === false) return

        setShowAlert(true)
    }, [show])

    const handleClose = () => {
        setShowAlert(false)
        if (typeof showChange === 'function') showChange()
    }

    return (
        <Alert variant='danger' show={showAlert} onClose={handleClose} dismissible>
            {!_.isEmpty(title) && <Alert.Heading  className="mb-0">{title}</Alert.Heading>}
            <p className="mb-0">{!_.isEmpty(message) ? message : "Error"}</p>
        </Alert>
    )
}

const Success = ({ title = "", message = "", show, showChange }) => {
    const [showAlert, setShowAlert] = useState(true)

    useEffect(() => {
        if (show === false) return

        setShowAlert(true)
    }, [show])

    const handleClose = () => {
        setShowAlert(false)
        if (typeof showChange === 'function') showChange()
    }

    return (
        <Alert variant='info' show={showAlert} onClose={handleClose} dismissible>
            {!_.isEmpty(title) && <Alert.Heading  className="mb-0">{title}</Alert.Heading>}
            <p className="mb-0">{!_.isEmpty(message) ? message : "Success"}</p>
        </Alert>
    )
}

const Warning = ({ title = "", message = "", show, showChange }) => {
    const [showAlert, setShowAlert] = useState(true)

    useEffect(() => {
        if (show === false) return

        setShowAlert(true)
    }, [show])

    const handleClose = () => {
        setShowAlert(false)
        if (typeof showChange === 'function') showChange()
    }

    return (
        <Alert variant='warning' show={showAlert} onClose={handleClose} dismissible>
            {!_.isEmpty(title) && <Alert.Heading  className="mb-0">{title}</Alert.Heading>}
            <p className="mb-0">{!_.isEmpty(message) ? message : "Warning"}</p>
        </Alert>
    )
}

const Notification = {
    Error,
    Success,
    Warning
}

export default Notification
