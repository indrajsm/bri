import ReactPlayer from 'react-player'
import { generalService } from '../utils/services/'

const { isEmptyValue } = generalService

const Audio = ({url, loading, autoplay = false, size = "md"}) => {
    if (loading) {
        return (
            <div className="react-player" style={StyleAudio(size).playerMask}>Loading audio...</div>
        )
    }

    if (isEmptyValue(url)) {
        return (
            <div className="react-player" style={StyleAudio(size).playerMask}>No audio found</div>
        )
    }

    return (
        <ReactPlayer
            url={url}
            className="react-player"
            playing={autoplay}
            controls={true}
            height={StyleAudio(size).player['height']}
            width={StyleAudio(size).player['width']}
            style={StyleAudio(size).player}
        />
    )
}

const StyleAudio = (size = "md") => {
    let player = {
        width: "100%",
        color: "495057",
        height: "38px",
        border: "1px solid #CED4DA",
        borderRadius: "0.25rem",
        backgroundColor: "#F5EEF8"
    }

    let playerMask = {
        width: "100%",
        color: "495057",
        border: "1px solid #CED4DA",
        height: "calc(1.5em + 0.75rem + 2px)",
        padding: "0.375rem 0.75rem",
        fontSize: "1rem",
        textAlign: "center",
        fontWeight: "400",
        lineHeight: "1.5",
        borderRadius: "0.25rem",
        backgroundColor: "#F5EEF8"
    }

    if (size === 'sm') {
        player = {
            ...player,
            height: "31px"
        }

        playerMask = {
            ...playerMask,
            height: "calc(1.5em + 0.5rem + 2px)",
            padding: "0.25rem 0.5rem",
            fontSize: "0.875rem",
            borderRadius: "0.2rem"
        }
    }

    if (size === 'lg') {
        player = {
            ...player,
            height: "47px"
        }

        playerMask = {
            ...playerMask,
            height: "calc(1.5em + 1rem + 2px))",
            padding: "0.5rem 1rem",
            fontSize: "1.25rem",
            borderRadius: "0.3rem"
        }
    }

    return { player, playerMask }
}

export const CustomPlayer = {
    Audio
}