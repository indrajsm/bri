import React from 'react'
import classnames from 'classnames'
import { paginationService } from './../utils/services'

export const Pagination = ({pageChange, total, limit, paging, sibling = 1 }) => {
    let numDots = 0

    const {
        current,
        first,
        last,
        previuos,
        next
    } = paging

    const {
        PaginationDots,
        PaginationRange,
        PaginationInfo
    } = paginationService

    const pageRange = PaginationRange({ total, limit, current, sibling })

    const pagingInfo = PaginationInfo(total, limit, current)

    // if (current === 0 || pageRange.length < 2) {
    //     return null;
    // }

    return (
        <>
            <div key="pagingInfo" className="py-2 border-top">
                Showing { pagingInfo.lowest } to { pagingInfo.highest } of { pagingInfo.total } entries
            </div>
            <nav className={ classnames('float-right', {'d-none': current === 0 || pageRange.length < 2}) }>
                <ul className="pagination mb-0 pb-0">
                    <li key="previuos" className={ classnames('page-item', {'d-none': current === first}) }>
                        <button type="button" className="page-link" onClick={() => pageChange(previuos)}>Prev</button>
                    </li>

                    { pageRange.map(pageNumber => {
                        if (pageNumber === PaginationDots) {
                            numDots++

                            return (
                                <li key={`pageDots${numDots}`} className="page-item disabled">
                                    <span className="page-link">&#8230;</span>
                                </li>
                            )
                        }

                        return (
                            <li key={`pageNumber${pageNumber}`} className={ classnames('page-item', {'active': pageNumber === current}) }>
                                {pageNumber == current ?
                                    <span className="page-link asd">{pageNumber}</span>
                                    :
                                    <button type="button" className="page-link" onClick={() => pageChange(pageNumber)}>{pageNumber}</button>
                                }
                            </li>
                        )
                    })}

                    <li key="next" className={ classnames('page-item', {'d-none': current === last}) }>
                        <button type="button" className="page-link" onClick={() => pageChange(next)}>Next</button>
                    </li>
                </ul>
            </nav>
        </>
    )
}