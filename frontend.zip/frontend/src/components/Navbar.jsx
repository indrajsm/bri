import { useState, useEffect, useContext } from 'react'
import { useHistory } from 'react-router-dom'
import { Button, Dropdown, Nav, Navbar } from 'react-bootstrap'
import _ from 'lodash'
import { AuthContext, UserActivityContext } from '../utils/context'
import { cookieService } from '../utils/services/'
import { useUsers } from '../utils/functions'
import { BriHorizontal } from '../public/assets'

export const NavbarComp = ({ handleModalBreak, socket }) => {
    let history = useHistory()
    const { user, userId, setIsAuth } = useContext(AuthContext)
    const { setUserActivityId, userActivity, userActivityId } = useContext(UserActivityContext)

    const { AuthLogout, Update } = useUsers()

    const toggleClass = () => {
        document.body.classList.toggle("sb-sidenav-toggled");
    }

    const handleUserAvailable = async () => {
        await Update(userId, { user_activity_id: 8 }).then(async (res) => {
            if (res.success) {
                localStorage.setItem('userActivityId', 8)
                setUserActivityId(8)
                socket.emit('escorts')
            }
        }).catch((err) => { return })
    }

    const handleLogout = async (e) => {
        e.preventDefault()
        await AuthLogout(cookieService.Get('ext')).then(async (res) => {
            // console.log(res)
            if (res.success) {
                socket.emit('escorts')
                setIsAuth(false)
                cookieService.Remove('socketAuth')
            }
        }).catch((err) => { return })
    }

    return (
        <Navbar className="sb-topnav navbar navbar-expand navbar-dark bg-blue">
            {/* <a className="navbar-brand" href="index.html">Synergix Web</a> */}
            <a className="navbar-brand" href="index.html"><img src={BriHorizontal} width="80px" className="img-fluid mx-5" /></a>
            <Button variant="light" size="sm" className="order-1 order-lg-0" id="sidebarToggle" onClick={toggleClass}><i className="fas fa-bars text-secondary"></i></Button>
            {/* <Button variant="light" size="md" className="order-1 order-lg-0 phone"><i className="fas fa-phone-alt"></i></Button> */}
            <ul className="navbar-nav ml-auto mr-0 mr-md-3 my-2 my-md-0">
                <Dropdown as={Nav.Item}>
                    <Dropdown.Toggle as={Nav.Link} id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i className="fas fa-user fa-fw"></i>{user} ({userActivity})
                    </Dropdown.Toggle>
                    <Dropdown.Menu className="dropdown-menu-right" aria-labelledby="userDropdown">
                        <Dropdown.Item href="#" disabled={userActivityId == 8 && 'true'} onClick={handleUserAvailable}>Available</Dropdown.Item>
                        <Dropdown.Item href="#" onClick={handleModalBreak}>Break</Dropdown.Item>
                        <Dropdown.Divider />
                        <Dropdown.Item href="/login"
                            onClick={handleLogout}>Logout</Dropdown.Item>
                    </Dropdown.Menu>
                </Dropdown>
            </ul>
        </Navbar >
    )
}