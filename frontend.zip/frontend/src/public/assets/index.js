import SynergixLogo from './images/synergix-ticket.jpg'
import BriLogo from './images/bri.png'
import BriHorizontal from './images/bri-horizontal.png'
import UserImg from './images/muser.jpg'

export { SynergixLogo, BriLogo, UserImg, BriHorizontal }