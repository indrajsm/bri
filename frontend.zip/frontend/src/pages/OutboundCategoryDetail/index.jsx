import { useState, useEffect, useContext } from 'react'
import { Button, Form, Modal, Spinner, Table } from 'react-bootstrap'
import _ from 'lodash'
import { generalService } from './../../utils/services'
import { useOutboundCategories, useOutboundCategoryDetails } from './../../utils/functions'
import { Pagination, Notification, CustomSelect } from './../../components'
import { FormAdd } from './FormAdd'
import { FormDetail } from './FormDetail'

const { isEmptyValue } = generalService

export const OutboundCategoryDetail = (props) => {
    const fnOutboundCategories = useOutboundCategories()
    const fnOutboundCategoryDetails = useOutboundCategoryDetails()
    const { Error, Success, Warning} = Notification

    const [loading, setLoading] = useState(true)
    const [notif, setNotif] = useState(initialNotif)
    const [tableData, setTableData] = useState({})
    const [modalAdd, setModalAdd] = useState(initialModal)
    const [modalDetail, setModalDetail] = useState(initialModal)
    const [formFilter, setFormFilter] = useState({
        name: "",
        outbound_category_id: ""
    })
    const [currentFilter, setCurrentFilter] = useState({
        page: 1,
        order: "name",
        ...formFilter
    })
    const [optionOutboundCategory, setOptionOutboundCategory] = useState([{
        value: "",
        label: "Choose..."
    }])

    useEffect(() => {
        const fetchData = async () => {
            await fnOutboundCategoryDetails.Get(currentFilter).then((res) => {
                setTableData(res)
                setLoading(false)
            }).catch((err) => { return }) //do nothing, let it go back to login
        }

        if (loading) fetchData()
        return () => setLoading(false)
    }, [loading])

    useEffect(() => {
        const fetchData = async () => {
            await fnOutboundCategories.Get({
                limit: 100,
                order: "name",
                is_active: 1
            }).then((res) => {
                if (!isEmptyValue(res.data)) {
                    let mapOption = res.data.map((row) => {
                        return { value: row.id, label: row.name }
                    })

                    setOptionOutboundCategory([
                        ...optionOutboundCategory,
                        ...mapOption
                    ])
                }
            }).catch((err) => { return }) //do nothing, let it go back to login
        }

        fetchData()
        return () => setOptionOutboundCategory([{
            value: "",
            label: "Choose..."
        }])
    }, [])

    const handleChangeFormFilter = (key, val) => {
        setFormFilter({ ...formFilter, [key]: val })
    }

    const handleSubmitFormFilter = (e) => {
        e.preventDefault()

        setCurrentFilter({
            ...currentFilter,
            ...formFilter,
            page: 1
        })
        setLoading(true)
    }

    const handleModalClose = () => {
        setModalAdd(initialModal)
        setModalDetail(initialModal)
    }

    const handleModalAdd = () => {
        setModalAdd({
            ...modalAdd,
            show: !modalAdd.show
        })
    }

    const handleModalDetail = (id) => {
        setModalDetail({
            ...modalDetail,
            show: !modalDetail.show,
            dataId: id
        })
    }

    return (
        <>
            <h1 className="mt-4">Setting Outbound Category Detail</h1>
            <ol className="breadcrumb mb-4">
                <li className="breadcrumb-item">Settings</li>
                <li className="breadcrumb-item active">Outbound Category Detail</li>
            </ol>
            {notif.show && notif.type === 'error' && <Error
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            {notif.show && notif.type === 'success' && <Success
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            {notif.show && notif.type === 'warning' && <Warning
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            <div className="card mb-4">
                <div className="card-header">
                    <i className="fas fa-table mr-1"></i> Filter Data
                </div>
                <div className="card-body">
                    <form onSubmit={handleSubmitFormFilter}>
                        <div className="form-row">
                            <Form.Group className="col-md-2" controlId="name">
                                <Form.Label>Name</Form.Label>
                                <Form.Control
                                    type="text"
                                    value={formFilter.name}
                                    onChange={e => handleChangeFormFilter("name", e.target.value)}
                                />
                            </Form.Group>
                            <Form.Group className="col-md-2" controlId="OutboundCategory">
                                <Form.Label>Outbound Category</Form.Label>
                                <CustomSelect.SelectBox
                                    optionSelect={optionOutboundCategory}
                                    onChangeValue={(value) => handleChangeFormFilter("outbound_category_id", value)}
                                    value={formFilter.outbound_category_id}
                                />
                            </Form.Group>
                        </div>
                        <div className="form-row">
                            <Form.Group className="col-md-12 mb-0">
                                <Button type="submit" variant="primary">Search</Button>
                            </Form.Group>
                        </div>
                    </form>
                </div>
            </div>
            <div className="card mb-4">
                <div className="card-body">
                    <Button variant="outline-primary" onClick={handleModalAdd}>Add Data</Button>
                    <hr />
                    <Table striped hover responsive width="100%" cellSpacing="0" cellPadding="0">
                        <thead className="thead-dark">
                            <tr>
                                <th width="10%">No.</th>
                                <th width="40%">Name</th>
                                <th width="30%">Outbound Category</th>
                                <th width="10%">Active</th>
                                <th width="10%" className="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {loading &&
                                <tr>
                                    <td colSpan="3" className="text-center">
                                        <Spinner animation="border" size="sm" className="mr-1" />
                                        Loading data...
                                    </td>
                                </tr>
                            }
                            {!loading && isEmptyValue(tableData.data) &&
                                <tr>
                                    <td colSpan="3" className="text-center">
                                        <span className="text-danger">No data found</span>
                                    </td>
                                </tr>
                            }
                            {!loading && !isEmptyValue(tableData.data) &&
                                tableData.data.map((row, i) => (
                                    <tr key={ row.id }>
                                        <td>{ tableData.paging.index[i] }</td>
                                        <td>{ row.name }</td>
                                        <td>{ row.outbound_category }</td>
                                        <td>{ row.is_active === 1 ? 'Yes' : 'No' }</td>
                                        <td className="text-center">
                                            <Button variant="warning" size="sm" className="m-1" title="Detail Data" onClick={(e) => { handleModalDetail(row.id) }}>
                                                <i className="fas fa-edit fa-fw"></i>
                                            </Button>
                                        </td>
                                    </tr>
                                ))
                            }
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>No.</th>
                                <th>Name</th>
                                <th>Outbound Category</th>
                                <th>Active</th>
                                <th>Action</th>
                            </tr>
                        </tfoot>
                    </Table>

                    {!loading && !isEmptyValue(tableData.paging) &&
                         <Pagination
                            total={tableData.total_data}
                            limit={tableData.limit}
                            paging={tableData.paging}
                            pageChange={(page) => {
                                setCurrentFilter({
                                    ...currentFilter,
                                    page: page
                                })
                                setLoading(true)
                            }}
                        />
                    }
                </div>
            </div>

            <Modal show={modalAdd.show} onHide={handleModalClose} backdrop="static" keyboard={false}>
                <FormAdd
                    modalChange={(params) => {
                        handleModalClose()
                    }}
                    notifChange={(params) => {
                        setNotif({
                            ...notif,
                            ...params
                        })
                    }}
                    dataChange={() => {
                        setLoading(true)
                    }}
                />
            </Modal>

            <Modal show={modalDetail.show} onHide={handleModalClose} backdrop="static" keyboard={false}>
                <FormDetail
                    modalChange={(params) => {
                        handleModalClose()
                    }}
                    notifChange={(params) => {
                        setNotif({
                            ...notif,
                            ...params
                        })
                    }}
                    dataChange={() => {
                        setLoading(true)
                    }}
                    dataId={modalDetail.dataId}
                />
            </Modal>
        </>
    )
}

const initialNotif = {
    title: "",
    message: "",
    show: false,
    type: null
}

const initialModal = {
    show: false,
    dataId: null
}