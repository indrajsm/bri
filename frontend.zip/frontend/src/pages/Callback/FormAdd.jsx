import React, { useEffect, useState, useContext } from "react"
import { Button, Form, Modal, Card, Spinner } from "react-bootstrap"
import { useForm, Controller } from "react-hook-form"
import DatePicker from "react-datepicker"
import classnames from "classnames"
import { yupResolver } from "@hookform/resolvers/yup"
import * as yup from "yup"
import _ from "lodash"
import { Notification } from "../../components"
import { useCallbacks, useCallbackReasons } from "../../utils/functions"
import { generalService } from "../../utils/services"
import { AuthContext } from "../../utils/context"

const { formatDateTime, isEmptyValue } = generalService

export const FormAdd = ({ dataChange, handleModalClose, customerId, campaignId, phoneNo }) => {
  const { userId } = useContext(AuthContext)
  const { Create } = useCallbacks()
  const { Get } = useCallbackReasons()
  const { handleSubmit, formState: { errors }, register, control, reset, clearErrors } = useForm({
    defaultValues: initialCallback,
    resolver: validationSchemaCallback
  })
  const [callbackReason, setCallbackReason] = useState({})
  const [isLoading, setIsLoading] = useState(true)
  const [alert, setAlert] = useState(null)
  const { Success, Error } = Notification

  const handleAlert = value => {
    return value && value === 1 ? (
      <Success message="Data has been created." />
    ) : (
        <Error message="Failed to create data." />
      )
  }

  const onSubmit = async data => {
    setAlert(null)
    setIsLoading(true)
    await Create({
      ...data,
      callback_time: formatDateTime(data.callback_time),
      created_at: formatDateTime()
    })
      .then(res => {
        if (res.success) {
          setAlert(1)
          setIsLoading(false)
          dataChange()
        } else {
          setAlert(2)
        }
      })
      .catch(err => {
        return
      })
  }

  useEffect(() => {
    const fetchData = async () => {
      clearErrors()
      reset({
        ...initialCallback,
        customer_id: customerId,
        campaign_id: campaignId,
        user_id: userId,
        callback_time: new Date(),
        phone_no: phoneNo
      })
      await Get()
        .then(res => {
          if (!isEmptyValue(res.data)) {
            setCallbackReason(res.data)
            setIsLoading(false)
          }
        })
        .catch(err => {
          return
        })
    }
    fetchData()
  }, [])
  return (
    <>
      <Form className="mb-3" onSubmit={handleSubmit(onSubmit)}>
        <Modal.Body>
          {alert && handleAlert(alert)}
          <Card className="mb-3">
            {/* <Card.Header>Import Customer</Card.Header> */}
            <Card.Body>
              <Form.Group className="col-md-12">
                <Form.Label>Phone No</Form.Label>
                <Form.Control
                  type="text"
                  size="sm"
                  {...register("phone_no")}
                />
                <Form.Text className={classnames("text-danger", {
                  "d-none": !errors.phone_no
                })}>{errors.phone_no ?.message}</Form.Text>
              </Form.Group>
              <Form.Group className="col-md-12">
                <Form.Label>Schedule Call At</Form.Label>
                <Controller
                  name={"callback_time"}
                  control={control}
                  render={({ field: { value, onChange } }) => {
                    return (
                      <DatePicker
                        className="form-control form-control-sm"
                        dateFormat="yyyy-MM-dd HH:mm"
                        showTimeInput
                        disabledKeyboardNavigation
                        selected={value}
                        onChange={date => {
                          onChange(date)
                          // formatDateTime(date) === false ? setSelectedStartDate(new Date()) : setSelectedStartDate(date)
                          // setValue('end_date', date)
                        }}
                        minDate={new Date()}
                      />
                    )
                  }}
                />
                <Form.Text
                  className={classnames("text-danger", {
                    "d-none": !errors.callback_time
                  })}
                >
                  {errors.callback_time ?.message}
                </Form.Text>
              </Form.Group>

              <Form.Group className="col-md-12">
                <Form.Label>Callback Reason</Form.Label>
                <select
                  className="form-control"
                  {...register("callback_reason_id")}
                >
                  <option value="">--Please Select --</option>
                  {!isEmptyValue(callbackReason) > 0 &&
                    callbackReason.map(item => (
                      <option key={item.id} value={item.id}>
                        {item.name}
                      </option>
                    ))}
                </select>
                <Form.Text
                  className={classnames("text-danger", {
                    "d-none": !errors.callback_reason_id
                  })}
                >
                  {errors.callback_reason_id ?.message}
                </Form.Text>
              </Form.Group>
            </Card.Body>
          </Card>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="danger" onClick={handleModalClose}>Close</Button>
          <Button variant="primary" type="submit">
            {isLoading ? <Spinner animation="border" size="sm" className="mr-1" /> : 'Save'}
          </Button>
        </Modal.Footer>
      </Form>
    </>
  )
}

const initialCallback = {
  customer_id: null,
  callback_reason_id: null,
  campaign_id: null,
  user_id: null,
  callback_time: null,
  phone_no: null,
  created_at: null
}

const validationSchemaCallback = yupResolver(
  yup.object().shape({
    callback_reason_id: yup.string().required("This field is required."),
    phone_no: yup.string().required("This field is required."),
    callback_time: yup
      .date()
      .nullable()
      .required("This field is required.")
    // is_active: yup.string().oneOf(["1"], "This checkbox is required.")
  })
)
