import React, { useEffect, useState, useRef } from 'react'
import { Button, Form, Modal, Spinner, Nav } from 'react-bootstrap'
import { useForm, Controller } from 'react-hook-form'
import Select from "react-select";
import DatePicker from "react-datepicker";
import { useCampaignFields, useCampaigns, useCampaignUsers, useCustomerFields, useUsers } from '../../utils/functions'
import { Notification } from '../../components'
import { generalService } from '../../utils/services';
import _ from 'lodash'
import { CampaignInfo } from './CampaignInfo';

const { isEmptyValue, formatDate, formatDateTime } = generalService
export const FormDetail = ({ dataId, modalChange, notifChange, dataChange }) => {
    const [step, setStep] = useState(1)
    const { Success, Error } = Notification

    const handleModalClose = () => {
        return modalChange({
            show: false,
            dataId: null
        })
    }

    const handleAlert = (value) => {
        return (
            value && value === 1 ?
                <Success message="Data has been updated." /> :
                <Error message="Failed to update data." />
        )
    }

    return (
        <>
            <NavTab setStep={setStep} step={step} />
            {step === 1 &&
                <FormCampaign dataId={dataId} setStep={setStep} step={step} dataChange={dataChange} campaignId={dataId} handleAlert={handleAlert} />
            }
            {step === 2 &&
                <FormCampaignField setStep={setStep} step={step} campaignId={dataId} handleAlert={handleAlert} />
            }

            {step === 3 &&
                <FormCampaignUser setStep={setStep} step={step} campaignId={dataId} handleAlert={handleAlert} />
            }
            {step === 4 &&
                <CampaignInfo setStep={setStep} step={step} campaignId={dataId} handleAlert={handleAlert} />
            }
        </>
    )
}

const FormCampaign = ({ dataId, step, setStep, dataChange, campaignId, handleAlert }) => {
    const { Get, Update } = useCampaigns()
    const [isLoading, setIsLoading] = useState(true)
    const [alert, setAlert] = useState(null)
    const initialValue = {
        name: "",
        start_date: new Date(),
        end_date: new Date(),
        is_active: 1
    }
    const { register, handleSubmit, reset, control, formState: { errors }, setValue } = useForm({
        defaultValues: initialValue,
    });
    const [selectedStartDate, setSelectedStartDate] = useState(new Date())

    // add campaign
    const onSubmit = async (data) => {
        await setIsLoading(true)

        const body = {
            name: data.name,
            start_date: formatDateTime(data.start_date),
            end_date: formatDateTime(data.end_date),
            is_active: data.is_active ? 1 : 0,
        }

        await Update(campaignId, body).then(async (res) => {
            if (res.success) {
                await setIsLoading(false)
                dataChange()
                setAlert(1)
            } else {
                setAlert(2)
            }
        }).catch((err) => { return })
        // const update = await Update(campaignId, body)
    }


    useEffect(() => {
        const fnAbort = new AbortController()
        const fetchData = async () => {
            await Get({ id: dataId }).then((res) => {
                if (!isEmptyValue(res.data)) {
                    reset({
                        name: res.data.name || "",
                        start_date: new Date(res.data.start_date) || null,
                        end_date: new Date(res.data.end_date) || null,
                        is_active: String(res.data.is_active) === "1" ? "1" : false
                    }, { keepErrors: false })
                }
            }).catch((err) => { return () => fnAbort.abort() }) //do nothing, let it go back to login
            setIsLoading(false)
        }
        fetchData()
        return () => fnAbort.abort()
    }, [reset]);

    return (
        <>
            <Form onSubmit={handleSubmit(onSubmit)}>
                <Modal.Body>
                    {
                        alert && handleAlert(alert)
                    }
                    <Form.Group className="mb-3">
                        <Form.Label>Campaign Name</Form.Label>
                        <Form.Control type="text" placeholder="Campaign Name" {...register("name")} required />
                    </Form.Group>
                    <Form.Group className="mb-3">
                        <Form.Label>Start Campaign</Form.Label>
                        <Controller
                            control={control}
                            name='start_date'
                            className="form-control"
                            render={({ field: { value, onChange } }) => (
                                <DatePicker
                                    className="form-control form-control-sm"
                                    dateFormat="yyyy-MM-dd HH:mm"
                                    showTimeInput
                                    disabledKeyboardNavigation
                                    selected={value}
                                    onChange={(date) => {
                                        onChange(date)
                                        formatDateTime(date) === false ? setSelectedStartDate(new Date()) : setSelectedStartDate(date)
                                        setValue('end_date', date)
                                    }}
                                    highlightDates={[new Date(), new Date()]}
                                    minDate={new Date()}
                                />
                            )}
                        />

                    </Form.Group>
                    <Form.Group className="mb-3">
                        <Form.Label>End Campaign</Form.Label>
                        <Controller
                            control={control}
                            name='end_date'
                            className="form-control"
                            render={({ field: { value, onChange } }) => (
                                <DatePicker
                                    className="form-control form-control-sm"
                                    dateFormat="yyyy-MM-dd HH:mm"
                                    showTimeInput
                                    disabledKeyboardNavigation
                                    selected={value}
                                    onChange={onChange}
                                    highlightDates={[new Date(), new Date()]}
                                    minDate={selectedStartDate}
                                />
                            )}
                        />
                    </Form.Group>
                    <Form.Group className="mb-3" controlId="Predictive">
                        <Form.Check type="checkbox" {...register("is_active")} className="text-center" label="Active" />
                    </Form.Group>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="primary" type="submit">{isLoading ? <Spinner animation="border" size="sm" className="mr-1" /> : 'Update'}</Button>
                </Modal.Footer>
            </Form>
        </>
    )
}

const FormCampaignField = ({ setStep, step, campaignId, handleAlert }) => {
    const [isLoading, setIsLoading] = useState(true)
    const [isUpdate, setIsUpdate] = useState(false)
    const { Get } = useCustomerFields()
    const fnCampaignFields = useCampaignFields()
    const [field, setField] = useState({})
    const [fieldList, setFieldList] = useState({})
    const [fieldDetail, setFieldDetail] = useState({})
    const [alert, setAlert] = useState(null)
    const [require, setRequire] = useState(false)
    const inputRef = useRef(null);

    useEffect(() => {
        const fnAbort = new AbortController()
        const fetchData = async () => {
            await Get({
                limit: "100",
                order: "field_name_display",
                is_active: 1
            }).then((res) => {
                if (!isEmptyValue(res.data)) {
                    setField(res.data)
                }
            }).catch((err) => { return () => fnAbort.abort() }) //do nothing, let it go back to login
            await fnCampaignFields.Get({
                campaign_id: campaignId,
                limit: "100",
                order: "field_name_display",
                is_active: 1
            }).then((res) => {
                if (!isEmptyValue(res.data)) {
                    setFieldDetail(res.data)
                }
            }).catch((err) => { return () => fnAbort.abort() })
            setIsLoading(false)
        }
        fetchData()
    }, [step])


    // Add campaign field
    const handleStep2 = async (e) => {
        e.preventDefault(e)

        if (!isEmptyValue(fieldDetail) && _.isObject(fieldDetail)) {
            if (!isEmptyValue(fieldList) && _.isObject(fieldList)) {
                await setIsUpdate(true)

                let data_field = fieldList.map(item => {
                    return {
                        'campaign_id': campaignId,
                        'customer_field_id': item.id,
                        'is_active': 1
                    }
                })
                let new_field = data_field
                let remove_field

                new_field = data_field.filter(e => {
                    return !fieldDetail.some(item => item.customer_field_id === e.customer_field_id); // take the ! out and you're done
                })
                remove_field = fieldDetail.filter(e => {
                    return !data_field.some(item => item.customer_field_id === e.customer_field_id); // take the ! out and you're done
                })

                if (new_field) {
                    await fnCampaignFields.Create(new_field).then((resCampaignFieldCreate) => {
                        return resCampaignFieldCreate.success
                    }).catch((err) => { return })
                }

                if (remove_field) {
                    remove_field = remove_field.map((row) => {
                        return {
                            id: row.id,
                            is_active: "0"
                        }
                    })
                    await fnCampaignFields.Create(remove_field).then((resCampaignFieldUpdate) => {
                        return resCampaignFieldUpdate.success
                    }).catch((err) => { return })
                }

                setIsUpdate(false)
                setAlert(1)
            }
        } else {
            inputRef.current.focus();
            setRequire(true)
            await setIsUpdate(false)
        }
    }
    return (
        <>
            {isLoading ? (
                <Modal.Body>
                    <Spinner animation="border" size="sm" className="mr-1" />
                    Loading data...
                        </Modal.Body>
            ) : (
                    <>
                        <Form validated="true" onSubmit={handleStep2}>
                            <Modal.Body>
                                {
                                    alert && handleAlert(alert)
                                }
                                <Form.Group className="mb-3" >
                                    <Select
                                        defaultValue={
                                            !isEmptyValue(fieldDetail) && fieldDetail.filter(i => i.is_active === 1).map(item => {
                                                return {
                                                    'id': item.customer_field_id,
                                                    'field_display_name': item.field_display_name,
                                                }
                                            })
                                        }
                                        isMulti
                                        name="colors"
                                        options={field}
                                        getOptionValue={(field) => field.id}
                                        getOptionLabel={(field) => field.field_display_name}
                                        className="basic-multi-select"
                                        classNamePrefix="select"
                                        onChange={(item) => (setFieldList(item), setRequire(false))}
                                        placeholder="Select Field"
                                        ref={inputRef}
                                    />
                                    {require &&
                                        <span className="text-danger">
                                            {"Field Type is required"}
                                        </span>
                                    }
                                </Form.Group>

                            </Modal.Body>
                            <Modal.Footer>
                                <Button variant="primary" type="submit">{isUpdate ? <Spinner animation="border" size="sm" className="mr-1" /> : 'Update'}</Button>
                            </Modal.Footer>
                        </Form>
                    </>
                )}

        </>
    )
}

const FormCampaignUser = ({ setStep, step, campaignId, handleAlert }) => {
    const { Get } = useUsers()
    const fnCampaignUsers = useCampaignUsers()
    const [isLoading, setIsLoading] = useState(true)
    const [user, setUser] = useState({})
    const [userList, setUserList] = useState({})
    const [fieldDetail, setFieldDetail] = useState({})
    const [alert, setAlert] = useState(null)
    const [isUpdate, setIsUpdate] = useState(false)
    const [require, setRequire] = useState(false)
    const inputRef = useRef(null);

    useEffect(() => {
        const fnAbort = new AbortController()
        const fetchData = async () => {
            await Get({
                limit: "0",
                order: "username",
                user_level_id: 1,
                is_active: 1
            }).then((res) => {
                if (!isEmptyValue(res.data)) {
                    setUser(res.data)
                }
            }).catch((err) => { return () => fnAbort.abort() }) //do nothing, let it go back to login
            await fnCampaignUsers.Get({
                campaign_id: campaignId,
                limit: "0",
                order: "username",
                is_active: 1
            }).then((res) => {
                if (!isEmptyValue(res.data)) {
                    setFieldDetail(res.data)
                }
            }).catch((err) => { return () => fnAbort.abort() })
            setIsLoading(false)
        }
        fetchData()
    }, [step])

    // add campaign user
    const handleStep3 = async (e) => {
        e.preventDefault(e)
        await setIsUpdate(true)

        if (!isEmptyValue(userList) && _.isObject(userList)) {
            if (userList) {
                let data_user = userList.map(item => {
                    return {
                        'campaign_id': campaignId,
                        'user_id': item.id
                    }
                })

                let new_field = data_user
                let remove_field
                if (!isEmptyValue(fieldDetail) && _.isObject(fieldDetail)) {
                    new_field = data_user.filter(e => {
                        return !fieldDetail.some(item => item.user_id === e.user_id); // take the ! out and you're done
                    })
                    remove_field = fieldDetail.filter(e => {
                        return !data_user.some(item => item.user_id === e.user_id); // take the ! out and you're done
                    })
                }

                if (new_field) {
                    await fnCampaignUsers.Create(new_field).then((resCampaignUserCreate) => {
                        return resCampaignUserCreate.success
                    }).catch((err) => { return })
                }

                if (remove_field) {
                    remove_field = remove_field.map((row) => {
                        return {
                            id: row.id,
                            is_active: "0"
                        }
                    })
                    await fnCampaignUsers.Create(remove_field).then((resCampaignUserUpdate) => {
                        return resCampaignUserUpdate.success
                    }).catch((err) => { return })

                }

                setIsUpdate(false)
                setAlert(1)
            } else {
                await setIsUpdate(false)
            }
        } else {
            inputRef.current.focus();
            setRequire(true)
            await setIsUpdate(false)
        }

    }
    return (
        <>
            {isLoading ? (
                <Modal.Body>
                    <Spinner animation="border" size="sm" className="mr-1" />
                    Loading data...
                        </Modal.Body>
            ) : (
                    <>
                        <Form onSubmit={handleStep3}>
                            <Modal.Body>
                                {
                                    alert && handleAlert(alert)
                                }
                                <Form.Group className="mb-3" >
                                    <Select
                                        defaultValue={
                                            !isEmptyValue(fieldDetail) && fieldDetail.filter(i => i.is_active === 1).map(item => {
                                                return {
                                                    'id': item.user_id,
                                                    'username': item.username,
                                                }
                                            })
                                        }
                                        isMulti
                                        name="colors"
                                        options={user}
                                        getOptionValue={(user) => user.id}
                                        getOptionLabel={(user) => user.username}
                                        className="basic-multi-select"
                                        classNamePrefix="select"
                                        onChange={(item) => (setUserList(item), setRequire(false))}
                                        placeholder="Select User"
                                        ref={inputRef}
                                    />
                                    {require &&
                                        <span className="text-danger">
                                            {"Field Type is required"}
                                        </span>
                                    }
                                </Form.Group>
                            </Modal.Body>
                            <Modal.Footer>
                                <Button variant="primary" type="submit">{isUpdate ? <Spinner animation="border" size="sm" className="mr-1" /> : 'Update'}</Button>
                            </Modal.Footer>
                        </Form>
                    </>
                )}
        </>
    )
}

const NavTab = ({ setStep, step }) => {
    return (
        <Nav variant="tabs" defaultActiveKey={`link-${step}`}>
            <Nav.Item>
                <Nav.Link eventKey="link-1" onClick={() => setStep(1)}>Campaign</Nav.Link>
            </Nav.Item>
            <Nav.Item>
                <Nav.Link eventKey="link-2" onClick={() => setStep(2)}>Field</Nav.Link>
            </Nav.Item>
            <Nav.Item>
                <Nav.Link eventKey="link-3" onClick={() => setStep(3)}>User</Nav.Link>
            </Nav.Item>
            <Nav.Item>
                <Nav.Link eventKey="link-4" onClick={() => setStep(4)}>Product</Nav.Link>
            </Nav.Item>
        </Nav>
    )

}
