import React, { useState, useEffect, useCallback, useContext } from 'react'
import { Button, Form, Modal, Row, Table, Spinner, Collapse } from 'react-bootstrap'
import { useForm, Controller } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import _ from 'lodash'
import classnames from 'classnames'
import { generalService } from '../../utils/services'
import { useCampaignInfos } from '../../utils/functions'
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import { EditorToolbar, modules, formats } from '../../components';
import '../../public/assets/styles/editor.css'

const { isEmptyValue, formatDate, formatDateTime } = generalService

export const CampaignInfo = ({ modalClose, campaignId }) => {
    const { Get, Delete } = useCampaignInfos()
    const [tableData, setTableData] = useState({})
    const [loading, setLoading] = useState(true)
    const [currentFilter, setCurrentFilter] = useState({
        page: 1,
        limit: 5,
        is_active: 1,
        order: "name",
        campaign_id: campaignId
    })
    const [toggle, setToggle] = useState({
        showTableData: true,
        showFormData: false,
        campaignInfoId: ""
    })

    useEffect(() => {
        const fnAbort = new AbortController()

        const fetchData = async () => {
            await Get(currentFilter).then((res) => {
                setTableData(res)
                setLoading(false)
            }).catch((err) => { return }) //do nothing, let it go back to login
        }

        if (loading) fetchData()
        return () => fnAbort.abort()
    }, [loading])

    const handleDeleteData = async (id) => {
        await Delete(id).then((res) => {
            if (res.success) {
                setLoading(true)
            }
        }).catch((err) => { return }) //do nothing, let it go back to login
    }

    const handleToggle = (id) => {
        setToggle({
            ...toggle,
            showTableData: !toggle.showTableData,
            showFormData: !toggle.showFormData,
            campaignInfoId: !isEmptyValue(id) ? id : ""
        })
    }

    return (
        <>
            <Collapse in={toggle.showTableData} unmountOnExit={false} mountOnEnter={true}>
                <div className="collapse-wrapper">
                    <Modal.Body className="pb-1">
                        <div className="mb-2">
                            <Button variant="success" size="sm" onClick={() => handleToggle()}>Add New</Button>
                        </div>
                        <Table striped bordered hover responsive width="100%" className="mb-2" size="sm">
                            <thead className="thead-dark">
                                <tr>
                                    <th width="75%">Name</th>
                                    <th width="25%" className="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {loading &&
                                    <tr>
                                        <td colSpan="2" className="text-center">
                                            <Spinner animation="border" size="sm" className="mr-1" />
                                            Loading data...
                                        </td>
                                    </tr>
                                    || !loading && isEmptyValue(tableData.data) &&
                                    <tr>
                                        <td colSpan="2" className="text-center">
                                            <span className="text-danger">No data found</span>
                                        </td>
                                    </tr>
                                    || !loading && !isEmptyValue(tableData.data) &&
                                    tableData.data.map((row, i) => (
                                        <tr key={row.id}>
                                            <td>{row.name}</td>
                                            <td className="text-center">
                                                <Button variant="warning" className="m-1" title="Detail Data" size="sm" onClick={(e) => { handleToggle(row.id) }}>
                                                    <i className="fas fa-edit fa-fw"></i>
                                                </Button>
                                                <Button variant="danger" className="m-1" title="Delete Data" size="sm" onClick={(e) => { handleDeleteData(row.id) }}>
                                                    <i className="fas fa-trash-alt fa-fw"></i>
                                                </Button>
                                            </td>
                                        </tr>
                                    ))
                                }
                            </tbody>
                        </Table>
                        {!loading && !isEmptyValue(tableData.paging) &&
                            <div className="d-flex justify-content-between pb-2">
                                <Button variant="info" size="sm" onClick={() => {
                                    setCurrentFilter({
                                        ...currentFilter,
                                        page: tableData.paging.previuos
                                    })
                                    setLoading(true)
                                }} className={classnames('mr-auto', {
                                    'd-none': tableData.paging.current === tableData.paging.previuos
                                })}>Prev</Button>
                                <Button variant="info" size="sm" onClick={() => {
                                    setCurrentFilter({
                                        ...currentFilter,
                                        page: tableData.paging.next
                                    })
                                    setLoading(true)
                                }} className={classnames('ml-auto', {
                                    'd-none': tableData.paging.current === tableData.paging.next
                                })}>Next</Button>
                            </div>
                        }
                    </Modal.Body>
                    <Modal.Footer>
                        <Button variant="primary" onClick={modalClose}>Close</Button>
                    </Modal.Footer>
                </div>
            </Collapse>
            <FormData
                showFormData={toggle.showFormData}
                toggleChange={(params) => {
                    setToggle({
                        ...toggle,
                        ...params
                    })
                }}
                dataChange={() => {
                    setLoading(true)
                }}
                campaignId={campaignId}
                campaignInfoId={toggle.campaignInfoId}
            />
        </>
    )
}

const FormData = ({ showFormData, toggleChange, dataChange, campaignId, campaignInfoId }) => {
    const { Get, Create, Update } = useCampaignInfos()
    const { control, register, reset, handleSubmit, formState: { errors } } = useForm({
        defaultValues: initialDataCampaignInfo,
        resolver: validationSchemaCampaignInfo
    })

    useEffect(() => {
        const fnAbort = new AbortController()
        const fetchData = async () => {
            if (isEmptyValue(campaignInfoId)) {
                return reset({
                    ...initialDataCampaignInfo,
                    campaign_id: String(campaignId)
                }, { keepErrors: false })
            }

            await Get({ id: campaignInfoId }).then((res) => {
                if (!isEmptyValue(res.data)) {
                    reset({
                        ...initialDataCampaignInfo,
                        campaign_id: res.data.campaign_id || "",
                        name: res.data.name || "",
                        info: res.data.info || "",
                    }, { keepErrors: false })
                }
            }).catch((err) => { return () => fnAbort.abort() }) //do nothing, let it go back to login
        }

        fetchData()
        return () => fnAbort.abort()
    }, [campaignInfoId])

    const onSubmitForm = async (data, e) => {
        e.preventDefault()

        if (isEmptyValue(campaignInfoId)) {
            await Create(data).then((res) => {
                if (res.success) {
                    dataChange()
                }

            }).catch((err) => { return }) //do nothing, let it go back to login
        } else {
            await Update(campaignInfoId, data).then((res) => {
                if (res.success) {
                    dataChange()
                }
            }).catch((err) => { return }) //do nothing, let it go back to login
        }

        handleToggleChange()
    }

    const handleToggleChange = useCallback(() => {
        toggleChange({
            showFormData: false,
            showTableData: true,
            isDisabled: false,
            campaignInfoId: null
        })
    }, [toggleChange])

    return (
        <>
            <Collapse in={showFormData} unmountOnExit={false} mountOnEnter={true}>
                <Form onSubmit={handleSubmit(onSubmitForm)}>
                    <Modal.Body className="pb-1">
                        <Form.Group controlId="Name">
                            <Form.Label>Name</Form.Label>
                            <Form.Control
                                type="text"
                                size="sm"
                                isInvalid={!!errors.name}
                                {...register("name")}
                            />
                            <Form.Control.Feedback type="invalid">{errors.name ?.message}</Form.Control.Feedback>
                        </Form.Group>
                        <Form.Group className="mb-3">
                            <EditorToolbar toolbarId={'t1'} />
                            <Controller
                                name={"info"}
                                control={control}
                                render={({ field: { value, onChange } }) => {
                                    return (
                                        <ReactQuill
                                            theme="snow"
                                            value={value}
                                            onChange={onChange}
                                            modules={modules('t1')}
                                            formats={formats}
                                        />
                                    )
                                }}
                            />
                            <Form.Text className={classnames("text-danger", {
                                "d-none": !errors.info
                            })}>{errors.info ?.message}</Form.Text>
                        </Form.Group>
                    </Modal.Body>
                    <Modal.Footer>
                        <Button variant="success" type="submit">Save</Button>
                        <Button variant="light" onClick={handleToggleChange}>Cancel</Button>
                    </Modal.Footer>
                </Form>
                {/* <Form onSubmit={handleSubmitInfo}>
                    <Modal.Body className="pb-1">

                        <Form.Group className="mb-3">
                            <Form.Label>Name</Form.Label>
                            <Form.Control type="text" required value={newInfo.name} onChange={(e) => setNewInfo({
                                ...newInfo,
                                name: e.target.value
                            })} />
                        </Form.Group>
                        <Form.Group className="mb-3">
                            <EditorToolbar toolbarId={'t1'} />
                            <ReactQuill theme="snow"
                                value={newInfo.info}
                                onChange={(value) => setNewInfo({
                                    ...newInfo,
                                    info: value
                                })}
                                modules={modules('t1')}
                                formats={formats}
                            />
                        </Form.Group>
                    </Modal.Body >

                    <Modal.Footer>
                        <Button variant="success" type="submit">Save</Button>
                        <Button variant="light" onClick={handleToggleChange}>Cancel</Button>
                    </Modal.Footer>
                </Form> */}
            </Collapse>
        </>
    )
}

const initialDataCampaignInfo = {
    campaign_id: "",
    name: "",
    info: ""
}

const validationSchemaCampaignInfo = yupResolver(yup.object().shape({
    name: yup.string()
        .required("This field is required."),
    info: yup.string()
        .required("This field is required.")
}))