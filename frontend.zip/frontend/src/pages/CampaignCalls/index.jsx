import React, { useState, useEffect, useContext } from 'react'
import { Link } from 'react-router-dom'
import { Button, Form, Modal, Spinner, Table } from 'react-bootstrap'
import DatePicker from 'react-datepicker'
import _ from 'lodash'
import { generalService } from './../../utils/services'
import { useCampaigns } from './../../utils/functions'
import { Pagination, Notification } from './../../components'
import { FormAdd } from './FormAdd'
import { FormDetail } from './FormDetail'
import { Rollback } from './Rollback';
import { AuthContext } from '../../utils/context';

const { isEmptyValue, formatDate } = generalService

export const CampaignCalls = (props) => {
    const { GetCall } = useCampaigns()
    const { Error, Success, Warning } = Notification
    const { userLevelId } = useContext(AuthContext)
    const [loading, setLoading] = useState(true)
    const [notif, setNotif] = useState(initialNotif)
    const [tableData, setTableData] = useState({})
    const [modalAdd, setModalAdd] = useState(initialModal)
    const [modalDetail, setModalDetail] = useState(initialModal)
    const [modalRollback, setModalRollback] = useState(initialModal)
    const [disableDate, setDisableDate] = useState(false)
    const [formFilter, setFormFilter] = useState({
        start_date_list: formatDate(),
        end_date_list: formatDate(),
        name: "",
    })
    const [currentFilter, setCurrentFilter] = useState({
        page: 1,
        order: "name",
        ...formFilter
    })

    const handleModalAdd = () => {
        setModalAdd({
            ...modalAdd,
            show: !modalAdd.show
        })
    }

    const handleModalDetail = (id) => {
        setModalDetail({
            ...modalDetail,
            show: !modalDetail.show,
            dataId: id
        })
    }

    const handleModalRollback = (id, name) => {
        setModalRollback({
            ...modalRollback,
            show: !modalRollback.show,
            dataId: id,
            campaigName: name
        })
    }

    const handleChangeFormFilter = (key, val) => {
        if (['start_date_list', 'end_date_list'].includes(key)) {
            val = formatDate(val)
        }
        if (key === 'disable_date') {
            val ? setDisableDate(true) : setDisableDate(false)
        }
        setFormFilter({ ...formFilter, [key]: val })
    }

    const handleSubmitFormFilter = (e) => {
        e.preventDefault()

        setCurrentFilter({
            ...currentFilter,
            ...formFilter,
            page: 1
        })
        setLoading(true)
    }

    const handleModalClose = () => {
        setModalAdd(initialModal)
        setModalDetail(initialModal)
        setModalRollback(initialModal)
    }

    useEffect(() => {
        const fetchData = async () => {
            await GetCall(currentFilter).then((res) => {
                setTableData(res)
                setLoading(false)
            }).catch((err) => { return }) //do nothing, let it go back to login
        }

        if (loading) fetchData()
        return () => setLoading(false)
    }, [loading])

    return (
        <>
            <h1 className="mt-4">Campaign Call</h1>
            <ol className="breadcrumb mb-4">
                <li className="breadcrumb-item active">Campaign Call</li>
            </ol>
            {notif.show && notif.type === 'error' && <Error
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            {notif.show && notif.type === 'success' && <Success
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            {notif.show && notif.type === 'warning' && <Warning
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            <div className="card mb-4">
                <div className="card-header">
                    <i className="fas fa-table mr-1"></i> Filter Data
                </div>
                <div className="card-body">
                    <form onSubmit={handleSubmitFormFilter}>
                        <div className="form-row">
                            <Form.Group className="col-md-2" controlId="DisableDate">
                                <Form.Label>Disable Date</Form.Label>
                                <br />
                                <span className="btn btn-sm btn-outline-dark">
                                    <Form.Check type="checkbox" name="disable_date" className="text-center" onClick={e => handleChangeFormFilter('disable_date', e.target.checked)} />
                                </span>
                            </Form.Group>
                            <Form.Group className="col-md-2" controlId="StartDate">
                                <Form.Label>Start Date</Form.Label>
                                <DatePicker
                                    selected={new Date(formFilter.start_date_list)}
                                    dateFormat="yyyy-MM-dd"
                                    className="form-control"
                                    placeholderText="YYYY-MM-DD"
                                    name="start_date"
                                    showMonthDropdown
                                    showYearDropdown
                                    onChange={date => handleChangeFormFilter("start_date_list", date)}
                                    disabled={disableDate}
                                />
                            </Form.Group>

                            <Form.Group className="col-md-2" controlId="EndDate">
                                <Form.Label>End Date</Form.Label>
                                <DatePicker
                                    selected={new Date(formFilter.end_date_list) >= new Date(formFilter.start_date_list) ? new Date(formFilter.end_date_list) : new Date(formFilter.start_date_list)}
                                    dateFormat="yyyy-MM-dd"
                                    className="form-control"
                                    placeholderText="YYYY-MM-DD"
                                    name="end_date"
                                    minDate={new Date(formFilter.start_date_list)}
                                    // minDate={new Date()}
                                    showMonthDropdown
                                    showYearDropdown
                                    onChange={date => handleChangeFormFilter("end_date_list", date)}
                                    disabled={disableDate}
                                />
                            </Form.Group>
                            <div className="form-group col-md-2">
                                <label htmlFor="inputState">Name</label>
                                <input type="text" id="inputState" className="form-control" onChange={e => handleChangeFormFilter("name", e.target.value)} />
                            </div>
                        </div>
                        <div className="form-row">
                        </div>
                        <button type="submit" className="btn btn-primary">Search</button>
                    </form>
                </div>
            </div>
            <div className="card mb-4">
                <div className="card-body">
                    {/* <ExportToExcel rawData={exportData} fileName="user-data" />&nbsp; */}
                    {(userLevelId == 2 || userLevelId == 5) &&
                        <Button variant="outline-primary" onClick={handleModalAdd}>Add Campaign</Button>
                    }
                    <hr />
                    <Table striped hover responsive width="100%" cellSpacing="0" cellPadding="0" >
                        <thead className="thead-dark text-nowrap">
                            <tr >
                                <th width="">No.</th>
                                <th width="250">Name</th>
                                <th width="150">Start Date</th>
                                <th width="150">End Date</th>
                                <th width="">Total Agents</th>
                                <th width="">Total Customers</th>
                                <th width="">Total Calls</th>
                                <th width="">Status</th>
                                <th width="180">Action</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                                <th>No.</th>
                                <th>Name</th>
                                <th>Start Date</th>
                                <th>End Date</th>
                                <th>Total Agents</th>
                                <th>Total Customers</th>
                                <th>Total Calls</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </tfoot>
                        <tbody className="text-nowrap">
                            {loading &&
                                <tr>
                                    <td colSpan="9" className="text-center">
                                        <Spinner animation="border" size="sm" className="mr-1" />
                                        Loading data...
                                        </td>
                                </tr>
                                || !loading && isEmptyValue(tableData.data) &&
                                <tr>
                                    <td colSpan="9" className="text-center">
                                        <span className="text-danger">No data found</span>
                                    </td>
                                </tr>
                                || !loading && !isEmptyValue(tableData.data) &&
                                tableData.data.map((item, i) => (
                                    <tr key={item.id}>
                                        <td>{tableData.paging.index[i]}</td>
                                        <td>{item.name}</td>
                                        <td>{item.start_date && item.start_date.substring(0, 10)}</td>
                                        <td>{item.end_date && item.end_date.substring(0, 10)}</td>
                                        <td>{item.total_agent}</td>
                                        <td>{item.total_customer}</td>
                                        <td>{item.total_call}</td>
                                        <td>{item.is_active_campaign ? 'Active' : 'Inactive'}</td>
                                        <td>
                                            {(userLevelId == 2 || userLevelId == 5) &&
                                                <Button variant="primary" size="sm" className="m-1" data-toggle="modal" title="Edit Campign Call" onClick={(e) => { handleModalDetail(item.id) }}>
                                                    <i className="fas fa-edit fa-fw"></i>
                                                </Button>
                                            }
                                            {(userLevelId == 2 || userLevelId == 5 || userLevelId == 1) &&
                                                <Link to={`customer-calls/${item.id}/${item.name}`} variant="warning" size="sm" className="m-1" title="Customer List">
                                                    <Button variant="warning" size="sm" className="m-1">
                                                        <i className="fas fa-users fa-fw"></i>
                                                    </Button>
                                                </Link>
                                            }
                                            <Link to={`calls/${item.id}/${item.name}`} variant="info" size="sm" className="m-1" title="Call List">
                                                <Button variant="info" size="sm" className="m-1">
                                                    <i className="fas fa-phone fa-fw"></i>
                                                </Button>
                                            </Link>
                                            {(userLevelId == 2 || userLevelId == 5) &&
                                                <Button variant="danger" size="sm" className="m-1" data-toggle="modal" title="Rollback Campign Call" onClick={(e) => { handleModalRollback(item.id, item.name) }}>
                                                    <i className="fas fa-undo fa-fw"></i>
                                                </Button>
                                            }
                                        </td>
                                    </tr>
                                ))
                            }
                        </tbody>
                    </Table>

                    {!loading && !isEmptyValue(tableData.paging) &&
                        <Pagination
                            total={tableData.total_data}
                            limit={tableData.limit}
                            paging={tableData.paging}
                            pageChange={(pageNumber) => {
                                setCurrentFilter({
                                    ...currentFilter,
                                    page: pageNumber
                                })
                                setLoading(true)
                            }}
                        />
                    }
                </div>
            </div>
            <Modal show={modalAdd.show} onHide={handleModalClose} backdrop="static" keyboard={false}>
                <Modal.Header closeButton>
                    <Modal.Title>New Campaign Call</Modal.Title>
                </Modal.Header>
                <FormAdd
                    modalChange={(params) => {
                        setModalAdd({
                            ...modalAdd,
                            ...params
                        })
                    }}
                    notifChange={(value) => {
                        setNotif(value)
                    }}
                    dataChange={() => {
                        setLoading(true)
                    }}
                />
            </Modal>
            <Modal show={modalDetail.show} onHide={handleModalClose} backdrop="static" keyboard={false}>
                <Modal.Header closeButton>
                    <Modal.Title>Detail Campaign Call</Modal.Title>
                </Modal.Header>
                <FormDetail
                    modalChange={(params) => {
                        setModalDetail({
                            ...modalDetail,
                            ...params
                        })
                    }}
                    notifChange={(value) => {
                        setNotif(value)
                    }}
                    dataChange={() => {
                        setLoading(true)
                    }}
                    dataId={modalDetail.dataId}
                />
            </Modal>

            <Modal show={modalRollback.show} onHide={handleModalClose} backdrop="static" keyboard={false} size="lg">
                <Modal.Header closeButton>
                    <Modal.Title>Rollback Campaign {modalRollback.campaigName}</Modal.Title>
                </Modal.Header>
                <Rollback
                    modalChange={(params) => {
                        setModalRollback({
                            ...modalRollback,
                            ...params
                        })
                    }}
                    notifChange={(value) => {
                        setNotif(value)
                    }}
                    dataChange={() => {
                        setLoading(true)
                    }}
                    campaignId={modalRollback.dataId}
                />
            </Modal>
        </>
    )
}

const initialModal = {
    show: false,
    dataId: ""
}

const initialNotif = {
    title: "",
    message: "",
    show: false,
    type: null
}