import { useState, useEffect, useCallback, useContext } from 'react'
import { Button, Form, Modal, Spinner, Row, Nav } from 'react-bootstrap'
import { useForm, Controller } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import _ from 'lodash'
import Select from 'react-select'
import DatePicker from 'react-datepicker'
import classnames from 'classnames'
import { generalService } from '../../utils/services'
import { useCampaignFields, useCampaigns, useCampaignUsers, useCustomerFields, useUsers } from '../../utils/functions'
import { CampaignInfo } from './CampaignInfo'

const { isEmptyValue, formatDate, formatDateTime } = generalService

export const FormAdd = ({ modalChange, notifChange, dataChange }) => {
    const fnCampaigns = useCampaigns()
    const fnCampaignFields = useCampaignFields()
    const fnCampaignUsers = useCampaignUsers()
    const [step, setStep] = useState(1)
    const [savingData, setSavingData] = useState(null)
    const [campaignId, setCampaignId] = useState(null)
    const [dataCampaign, setDataCampaign] = useState({})
    const [dataCampaignField, setDataCampaignField] = useState({})
    const [dataCampaignUser, setDataCampaignUser] = useState({})

    const handleModalClose = () => {
        return modalChange({
            show: false,
            dataId: null
        })
    }

    useEffect(() => {
        if (savingData) return handleSubmit()
    }, [savingData])

    const handleSubmit = async () => {
        Object.keys(dataCampaign).forEach((key) => {
            if (['is_active'].indexOf(key) >= 0 && dataCampaign[key] === false) {
                dataCampaign[key] = "0"
            }
        })

        let saveCampaign = true
        let saveCampaignField = true
        let saveCampaignUser = true
        let dataCampaignId = null

        await fnCampaigns.Create(dataCampaign).then(async (resCampaign) => {
            saveCampaign = resCampaign.success
            if (resCampaign.success) dataCampaignId = resCampaign.data.id
        }).catch((err) => { return }) //do nothing, let it go back to login

        if (saveCampaign) {
            if ('customer_field_id' in dataCampaignField) {
                const customerFieldId = dataCampaignField.customer_field_id
                let mapDataCampaignField = customerFieldId.map((row) => {
                    return {
                        campaign_id: String(dataCampaignId),
                        customer_field_id: String(row.value),
                        is_active: "1"
                    }
                })

                await fnCampaignFields.Create(mapDataCampaignField).then((resCampaignField) => {
                    saveCampaignField = resCampaignField.success
                }).catch((err) => { return }) //do nothing, let it go back to login
            }

            if ('user_id' in dataCampaignUser) {
                const userId = dataCampaignUser.user_id
                let mapDataCampaignUser = userId.map((row) => {
                    return {
                        campaign_id: String(dataCampaignId),
                        user_id: String(row.value),
                        is_active: "1"
                    }
                })

                await fnCampaignUsers.Create(mapDataCampaignUser).then((resCampaignUser) => {
                    saveCampaignUser = resCampaignUser.success
                }).catch((err) => { return }) //do nothing, let it go back to login
            }

            if (saveCampaignField && saveCampaignUser) {
                setCampaignId(dataCampaignId)
                setStep(step => (step + 1))
            } else {
                let messageNotif = "Campaign has been saved."
                if (!saveCampaignField) messageNotif += " An error occured while save Campaign Field."
                if (!saveCampaignUser) messageNotif += " An error occured while save Campaign User."

                notifChange({
                    title: "Warning",
                    message: messageNotif,
                    show: true,
                    type: "warning"
                })
                dataChange()
                handleModalClose()
            }
        } else {
            notifChange({
                title: "Error",
                message: "Failed to save data.",
                show: true,
                type: "error"
            })
            handleModalClose()
        }
    }

    return (
        <>
            <NavTab step={step} />
            {step === 1 && <FormCampaign
                step={step}
                stepChange={setStep}
                currentData={dataCampaign}
                currentDataChange={setDataCampaign}
                modalClose={handleModalClose}
            />}
            {step === 2 && <FormCampaignField
                step={step}
                stepChange={setStep}
                currentData={dataCampaignField}
                currentDataChange={setDataCampaignField}
            />}
            {step === 3 && <FormCampaignUser
                step={step}
                stepChange={setStep}
                currentData={dataCampaignUser}
                currentDataChange={setDataCampaignUser}
                saveData={setSavingData}
            />}
            {step === 4 && <CampaignInfo
                modalClose={() => {
                    notifChange({
                        title: "Success",
                        message: "Data has been saved.",
                        show: true,
                        type: "success"
                    })
                    dataChange()
                    handleModalClose()
                }}
                campaignId={campaignId}
            />}
        </>
    )
}

const NavTab = ({ step }) => {
    return (
        <Nav fill variant="tabs">
            <Nav.Item>
                <Nav.Link className={classnames("disabled", {
                    "active text-primary": step === 1
                })}>General</Nav.Link>
            </Nav.Item>
            <Nav.Item>
                <Nav.Link className={classnames("disabled", {
                    "active text-primary": step === 2
                })}>Field</Nav.Link>
            </Nav.Item>
            <Nav.Item>
                <Nav.Link className={classnames("disabled", {
                    "active text-primary": step === 3
                })}>Agent</Nav.Link>
            </Nav.Item>
            <Nav.Item>
                <Nav.Link className={classnames("disabled", {
                    "active text-primary": step === 4
                })}>Product</Nav.Link>
            </Nav.Item>
        </Nav>
    )

}

const FormCampaign = ({ step, stepChange, currentData, currentDataChange, modalClose }) => {
    const { handleSubmit, formState: { errors }, register, control, reset, clearErrors, setValue } = useForm({
        defaultValues: initialDataCampaign,
        resolver: validationSchemaCampaign
    })
    const [selectedStartDate, setSelectedStartDate] = useState(new Date())

    useEffect(() => {
        const fetchData = () => {
            clearErrors()

            if (!isEmptyValue(currentData) && _.isObject(currentData)) {
                reset({
                    ...initialDataCampaign,
                    name: currentData.name || "",
                    start_date: new Date(currentData.start_date) || null,
                    end_date: new Date(currentData.end_date) || null,
                    is_active: currentData.is_active === "1" ? "1" : false
                })
            }
        }

        fetchData()
    }, [currentData])

    const onSubmitForm = (data, e) => {
        e.preventDefault()

        Object.keys(data).map((key) => {
            if (['start_date', 'end_date'].indexOf(key) >= 0) {
                let date = new Date(data[key]).setSeconds(0)
                data[key] = formatDateTime(date)
            }
        })

        // Object.keys(data).map((key) => {
        //     if (['is_active'].indexOf(key) >= 0 && data[key] === false) {
        //         data[key] = "0"
        //     }
        // })

        currentDataChange(data)
        handleStepNext()
    }

    const handleStepNext = useCallback(() => {
        stepChange(step => (step + 1))
    }, [stepChange])

    return (
        <Form onSubmit={handleSubmit(onSubmitForm)}>
            <Modal.Body className="pb-1">
                <Form.Group>
                    <Form.Label>Campaign Name</Form.Label>
                    <Form.Control
                        type="text"
                        size="sm"
                        {...register("name")}
                    />
                    <Form.Text className={classnames("text-danger", {
                        "d-none": !errors.name
                    })}>{errors.name ?.message}</Form.Text>
                </Form.Group>
                <Row>
                    <Form.Group className="col-md-6">
                        <Form.Label>Start Campaign</Form.Label>
                        <Controller
                            name={"start_date"}
                            control={control}
                            render={({ field: { value, onChange } }) => {
                                return (
                                    <DatePicker
                                        className="form-control form-control-sm"
                                        dateFormat="yyyy-MM-dd HH:mm"
                                        showTimeInput
                                        disabledKeyboardNavigation
                                        selected={value}
                                        onChange={(date) => {
                                            onChange(date)
                                            formatDateTime(date) === false ? setSelectedStartDate(new Date()) : setSelectedStartDate(date)
                                            setValue('end_date', date)
                                        }}
                                        highlightDates={[new Date(), new Date()]}
                                        minDate={new Date()}
                                    />
                                )
                            }}
                        />
                        <Form.Text className={classnames("text-danger", {
                            "d-none": !errors.start_date
                        })}>{errors.start_date ?.message}</Form.Text>
                    </Form.Group>
                    <Form.Group className="col-md-6">
                        <Form.Label>End Campaign</Form.Label>
                        <Controller
                            name={"end_date"}
                            control={control}
                            render={({ field: { value, onChange } }) => {
                                return (
                                    <DatePicker
                                        className="form-control form-control-sm"
                                        dateFormat="yyyy-MM-dd HH:mm"
                                        showTimeInput
                                        disabledKeyboardNavigation
                                        selected={value}
                                        onChange={onChange}
                                        highlightDates={[new Date(), new Date()]}
                                        minDate={selectedStartDate}
                                    />
                                )
                            }}
                        />
                        <Form.Text className={classnames("text-danger", {
                            "d-none": !errors.end_date
                        })}>{errors.end_date ?.message}</Form.Text>
                    </Form.Group>
                </Row>
                <Form.Group controlId="IsActive">
                    <Form.Check
                        className="text-center"
                        type="checkbox"
                        label="Active"
                        value="1"
                        // isInvalid={!!errors.is_active}
                        // feedback={errors.is_active?.message}
                        {...register("is_active")}
                    />
                </Form.Group>
            </Modal.Body>
            <Modal.Footer>
                <Button variant="light" onClick={modalClose}>Cancel</Button>
                <Button variant="primary" type="submit">Next</Button>
            </Modal.Footer>
        </Form>
    )
}

const FormCampaignField = ({ step, stepChange, currentData, currentDataChange }) => {
    const { handleSubmit, formState: { errors }, control, reset, clearErrors, getValues } = useForm({
        defaultValues: initialDataCampaignField,
        resolver: validationSchemaCampaignField
    })
    const { Get } = useCustomerFields()
    const [optionField, setOptionField] = useState([])

    useEffect(() => {
        const fetchData = async () => {
            await Get({
                limit: 100,
                is_active: 1,
                order: "field_name_display"
            }).then((res) => {
                if (!isEmptyValue(res.data)) {
                    let mapOptionField = res.data.map((row) => {
                        return { value: row.id, label: row.field_display_name }
                    })

                    setOptionField([
                        ...mapOptionField
                    ])
                }
            }).catch((err) => { return }) //do nothing, let it go back to login
        }

        fetchData()
        return () => setOptionField([])
    }, [])

    useEffect(() => {
        const fetchData = () => {
            clearErrors()

            if (!isEmptyValue(currentData) && _.isObject(currentData)) {
                reset({
                    ...initialDataCampaignField,
                    customer_field_id: currentData.customer_field_id || null
                })
            }
        }

        fetchData()
    }, [currentData])

    const onSubmitForm = (data, e) => {
        e.preventDefault()

        currentDataChange(data)
        handleStepNext()
    }

    const handleStepNext = useCallback(() => {
        stepChange(step => (step + 1))
    }, [stepChange])

    const handleStepPrev = useCallback(() => {
        stepChange(step => (step - 1))
    }, [stepChange])

    return (
        <Form onSubmit={handleSubmit(onSubmitForm)}>
            <Modal.Body className="pb-1">
                <Form.Group>
                    <Form.Label>Select Campaign Field</Form.Label>
                    <Controller
                        name={"customer_field_id"}
                        control={control}
                        render={({ field: { value, onChange } }) => {
                            return (
                                <Select
                                    isMulti
                                    options={optionField}
                                    onChange={(selected) => {
                                        let mapSelected = selected.map((row) => {
                                            return { value: row.value, label: row.label }
                                        })
                                        onChange(mapSelected)
                                    }}
                                    value={getValues('customer_field_id')}
                                    getOptionValue={field => field.value}
                                    getOptionLabel={field => field.label}
                                />
                            )
                        }}
                    />
                    <Form.Text className={classnames("text-danger", {
                        "d-none": !errors.customer_field_id
                    })}>{errors.customer_field_id ?.message}</Form.Text>
                </Form.Group>
            </Modal.Body>
            <Modal.Footer>
                <Button variant="outline-primary" onClick={handleStepPrev}>Prev</Button>
                <Button variant="primary" type="submit">Next</Button>
            </Modal.Footer>
        </Form>
    )
}

const FormCampaignUser = ({ step, stepChange, currentData, currentDataChange, saveData }) => {
    const { handleSubmit, formState: { errors, isSubmitting }, control, reset, clearErrors, getValues } = useForm({
        defaultValues: initialDataCampaignUser,
        resolver: validationSchemaCampaignUser
    })
    const { Get } = useUsers()
    const [optionField, setOptionField] = useState([])

    useEffect(() => {
        const fetchData = async () => {
            await Get({
                limit: 100,
                order: "username",
                is_active: 1,
                user_level_id: 1
            }).then((res) => {
                if (!isEmptyValue(res.data)) {
                    let mapOptionField = res.data.map((row) => {
                        return { value: row.id, label: row.username }
                    })

                    setOptionField([
                        ...mapOptionField
                    ])
                }
            }).catch((err) => { return }) //do nothing, let it go back to login
        }

        fetchData()
        return () => setOptionField([])
    }, [])

    useEffect(() => {
        const fetchData = () => {
            clearErrors()

            if (!isEmptyValue(currentData) && _.isObject(currentData)) {
                reset({
                    ...initialDataCampaignUser,
                    user_id: currentData.user_id || null
                })
            }
        }

        fetchData()
    }, [currentData])

    const onSubmitForm = (data, e) => {
        e.preventDefault()

        currentDataChange(data)
        handleStepSave()
    }

    const handleStepSave = useCallback(() => {
        saveData(true)
    }, [saveData])

    const handleStepNext = useCallback(() => {
        stepChange(step => (step + 1))
    }, [stepChange])

    const handleStepPrev = useCallback(() => {
        stepChange(step => (step - 1))
    }, [stepChange])

    return (
        <Form onSubmit={handleSubmit(onSubmitForm)}>
            <Modal.Body className="pb-1">
                <Form.Group>
                    <Form.Label>Select Campaign User</Form.Label>
                    <Controller
                        name={"user_id"}
                        control={control}
                        render={({ field: { value, onChange } }) => {
                            return (
                                <Select
                                    isMulti
                                    options={optionField}
                                    onChange={(selected) => {
                                        let mapSelected = selected.map((row) => {
                                            return { value: row.value, label: row.label }
                                        })
                                        onChange(mapSelected)
                                    }}
                                    value={getValues('user_id')}
                                    getOptionValue={field => field.value}
                                    getOptionLabel={field => field.label}
                                />
                            )
                        }}
                    />
                    <Form.Text className={classnames("text-danger", {
                        "d-none": !errors.user_id
                    })}>{errors.user_id ?.message}</Form.Text>
                </Form.Group>
            </Modal.Body>
            <Modal.Footer>
                <Button variant="outline-primary" onClick={handleStepPrev} disabled={isSubmitting}>Prev</Button>
                <Button variant="primary" type="submit" disabled={isSubmitting}>
                    {isSubmitting && <Spinner animation="border" size="sm" className="mr-1" />} Save & Next
                </Button>
            </Modal.Footer>
        </Form>
    )
}

const initialDataCampaign = {
    name: "",
    start_date: null,
    end_date: null,
    media_id: "1",
    is_active: false
}

const validationSchemaCampaign = yupResolver(yup.object().shape({
    name: yup.string()
        .required("This field is required."),
    start_date: yup.date().nullable()
        .required("This field is required."),
    end_date: yup.date().nullable()
        .required("This field is required."),
    // is_active: yup.string().oneOf(["1"], "This checkbox is required.")
}))

const initialDataCampaignField = {
    customer_field_id: null
}

const validationSchemaCampaignField = yupResolver(yup.object().shape({
    customer_field_id: yup.array().nullable()
        .required("This field is required.")
        .min(1, "This field is required.")
}))

const initialDataCampaignUser = {
    user_id: null
}

const validationSchemaCampaignUser = yupResolver(yup.object().shape({
    user_id: yup.array().nullable()
        .required("This field is required.")
        .min(1, "This field is required.")
}))