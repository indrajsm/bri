import { Button, Form, Modal, Spinner, Table, Row } from "react-bootstrap";
import React, { useEffect, useState } from "react";
import DatePicker from 'react-datepicker'
import _ from "lodash";
import { Pagination, Notification } from "./../../components";
import { useFileUploads, useCampaigns } from "../../utils/functions";
import { generalService } from "../../utils/services";

const { formatDate } = generalService

export const Rollback = ({ campaignId, dataChange }) => {
    const { Get } = useFileUploads()
    const fnCampaign = useCampaigns()
    const [isLoading, setIsLoading] = useState(false)
    const [tableData, setTableData] = useState({})
    const [modalConfirm, setModalConfirm] = useState(initialModal)
    const [disableDate, setDisableDate] = useState(true)
    const [alert, setAlert] = useState(null)
    const { Success, Error } = Notification

    const [formFilter, setFormFilter] = useState({
        start: formatDate(),
        end: formatDate(),
        disable_date: true,
        campaign_id: campaignId,
        is_active: 1,
        limit: 5,
    })

    const [currentFilter, setCurrentFilter] = useState({
        page: 1,
        ...formFilter
    });

    const handleChangeFormFilter = (key, val) => {
        if (['start', 'end'].includes(key)) {
            val = formatDate(val)
        }
        if (key === 'disable_date') {
            val ? setDisableDate(true) : setDisableDate(false)
        }
        setFormFilter({ ...formFilter, [key]: val })
    }

    const handleSubmitFormFilter = async (e) => {
        e.preventDefault()
        await setIsLoading(true)
        setCurrentFilter({
            page: 1,
            ...formFilter
        })
    }

    const handleModalConfirm = async (id) => {
        setModalConfirm({
            ...modalConfirm,
            show: !modalConfirm.show,
            dataId: id
        })
    }

    const handleModalRollback = async (id) => {
        setAlert(null)
        await fnCampaign.Rollback(id)
            .then(async res => {
                console.log(res)
                if (res.success) {
                    setAlert(1)
                    setIsLoading(true)
                } else {
                    setAlert(2)
                }
            })
            .catch(err => {
                return
            })
        handleModalClose()
        dataChange()
    }

    const handleModalClose = async () => {
        setModalConfirm(initialModal)
    }

    const handleAlert = (value) => {
        return (
            value && value === 1 ?
                <Success message="Rollback successed." /> :
                <Error message="Failed to rollback this file." />
        )
    }

    useEffect(() => {
        const fetchData = async () => {
            await Get(currentFilter)
                .then(res => {
                    setTableData(res);
                    setIsLoading(false);
                })
                .catch(err => {
                    return;
                });
        };
        fetchData();
    }, [isLoading, currentFilter]);

    return (
        <>
            <div className="card mb-4">
                <div className="card-body">
                    {
                        alert && handleAlert(alert)
                    }
                    <form onSubmit={handleSubmitFormFilter}>
                        <Row>
                            <Form.Group className="col-md-2" controlId="DisableDate">
                                <Form.Label>Disable Date</Form.Label>
                                <br />
                                <span className="btn btn-sm btn-outline-dark">
                                    <Form.Check type="checkbox" name="disable_date" defaultChecked={formFilter.disable_date} className="text-center" onClick={e => handleChangeFormFilter('disable_date', e.target.checked)} />
                                </span>
                            </Form.Group>
                            <Form.Group className="col-md-3" controlId="StartDate">
                                <Form.Label>Start Date</Form.Label>
                                <DatePicker
                                    selected={new Date(formFilter.start)}
                                    dateFormat="yyyy-MM-dd"
                                    className="form-control"
                                    placeholderText="YYYY-MM-DD"
                                    name="start"
                                    showMonthDropdown
                                    showYearDropdown
                                    onChange={date => handleChangeFormFilter("start", date)}
                                    disabled={disableDate}
                                />
                            </Form.Group>

                            <Form.Group className="col-md-3" controlId="EndDate">
                                <Form.Label>End Date</Form.Label>
                                <DatePicker
                                    selected={new Date(formFilter.end) >= new Date(formFilter.start) ? new Date(formFilter.end) : new Date(formFilter.start)}
                                    dateFormat="yyyy-MM-dd"
                                    className="form-control"
                                    placeholderText="YYYY-MM-DD"
                                    name="end"
                                    minDate={new Date(formFilter.start)}
                                    // minDate={new Date()}
                                    showMonthDropdown
                                    showYearDropdown
                                    onChange={date => handleChangeFormFilter("end", date)}
                                    disabled={disableDate}
                                />
                            </Form.Group>
                        </Row>
                        <button type="submit" className="btn btn-primary mt-4">Search</button>
                    </form>
                    <hr />
                    <div className="table-responsive">
                        <Table
                            striped
                            hover
                            responsive
                            width="100%"
                            cellSpacing="0"
                            cellPadding="0"
                        >
                            <thead className="thead-dark text-nowrap">
                                <tr>
                                    <th>File Name</th>
                                    <th>Uploaded Date</th>
                                    <th>Uploaded By</th>
                                    <th>Action</th>
                                </tr>
                            </thead>

                            <tbody className="text-nowrap">
                                {isLoading ? (
                                    <tr>
                                        <td colSpan="9" className="text-center">
                                            <Spinner animation="border" size="sm" className="mr-1" />
                                            Loading data...
                    </td>
                                    </tr>
                                ) : tableData.total_data > 0 ? (
                                    tableData.data.map((item, i) => (
                                        <tr key={item.id}>
                                            <td>{item.original_filename}</td>
                                            <td>{item.created_at}</td>
                                            <td>{item.upload_by}</td>
                                            <td>
                                                <Button variant="danger" size="sm" className="m-1" data-toggle="modal" onClick={(e) => { handleModalConfirm(item.id) }}>
                                                    Rollback
                                                </Button>
                                            </td>
                                        </tr>
                                    ))
                                ) : (
                                            <>
                                                <tr>
                                                    <td colSpan="9" className="text-center">
                                                        <span className="text-danger">No data found</span>
                                                    </td>
                                                </tr>
                                            </>
                                        )}
                            </tbody>
                        </Table>
                    </div>
                    {isLoading === false && !_.isEmpty(tableData) && (
                        <Pagination
                            total={tableData.total_data}
                            limit={tableData.limit}
                            paging={tableData.paging}
                            pageChange={async pageNumber => {
                                await setIsLoading(true);
                                setCurrentFilter({
                                    ...currentFilter,
                                    page: pageNumber
                                });
                            }}
                        />
                    )}
                </div>
            </div>
            <Modal show={modalConfirm.show} onHide={handleModalClose} backdrop="static" keyboard={false} >
                <Modal.Header closeButton>
                    <Modal.Title>Confirm Rollback File</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    Are you sure want to rollback this file?
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="danger" onClick={handleModalClose}>No</Button>
                    <Button variant="primary" onClick={e => { handleModalRollback(modalConfirm.dataId) }}>
                        Yes
                    </Button>
                </Modal.Footer>
            </Modal>
        </>
    );
};

const initialModal = {
    show: false,
    dataId: null
}