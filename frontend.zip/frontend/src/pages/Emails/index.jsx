import { Button, Form, Modal, Spinner, Table, Row } from 'react-bootstrap'
import React, { useEffect, useState, useContext } from 'react'
import { useParams } from 'react-router-dom';
import DatePicker from 'react-datepicker'
import Select from 'react-select'
import _ from 'lodash'
import { Pagination, Notification } from './../../components'
import { FormAdd } from './FormAdd';
import { FormDetail } from './FormDetail';
import { useEmails, useEmailStatuses, useCustomers } from '../../utils/functions';
import { generalService } from '../../utils/services';
import { AuthContext } from '../../utils/context';

const { isEmptyValue, formatDate } = generalService

export const Emails = (props) => {
    const { userLevelId } = useContext(AuthContext)
    const { Get } = useEmails()
    const fnEmailStatuses = useEmailStatuses()
    const { Update } = useCustomers()
    const { Error, Success, Warning } = Notification
    const [isLoading, setIsLoading] = useState(true)
    const [notif, setNotif] = useState(initialNotif)
    const [modalAdd, setModalAdd] = useState(initialModal)
    const [modalDetail, setModalDetail] = useState(initialModal)
    const [modalConfirm, setModalConfirm] = useState(initialModal)
    const [tableData, setTableData] = useState({})
    const [emailStatus, setEmailStatus] = useState({})
    const [disableDate, setDisableDate] = useState(false)
    const [alert, setAlert] = useState(null)
    const { campaignId } = useParams();

    const [formFilter, setFormFilter] = useState({
        customer_name: "",
        start_date: formatDate(),
        end_date: formatDate(),
        email_status_id: "",
        campaign_id: campaignId
    })
    const [currentFilter, setCurrentFilter] = useState({
        page: 1,
        order: "created_at",
        ...formFilter
    })

    const handleModalAdd = () => {
        setModalAdd({
            ...modalAdd,
            show: !modalAdd.show,
            dataId: campaignId
        })
    }

    const handleModalDetail = (id) => {
        setModalDetail({
            ...modalDetail,
            show: !modalDetail.show,
            dataId: id
        })
    }

    const handleChangeFormFilter = (key, val) => {
        if (['start_date', 'end_date'].includes(key)) {
            val = formatDate(val)
        }
        if (key === 'disable_date') {
            val ? setDisableDate(true) : setDisableDate(false)
        }
        setFormFilter({ ...formFilter, [key]: val })
    }

    const handleSubmitFormFilter = async (e) => {
        e.preventDefault()
        await setIsLoading(true)
        setCurrentFilter({
            page: 1,
            ...formFilter
        })
    }

    const handleModalClose = async () => {
        await Get()
        setModalAdd(initialModal)
        setModalDetail(initialModal)
        setModalConfirm(initialModal)
    }

    const handleModalConfirm = async (id) => {
        setModalConfirm({
            ...modalConfirm,
            show: !modalConfirm.show,
            dataId: id
        })
    }

    const handleModalRevoke = async (id) => {
        setAlert(null)
        await Update(id, { is_active: 0 })
            .then(async res => {
                console.log(res)
                if (res.success) {
                    setAlert(1)
                    setIsLoading(true)
                } else {
                    setAlert(2)
                }
            })
            .catch(err => {
                return
            })
        handleModalClose()
        setIsLoading(true)
    }

    const handleAlert = (value) => {
        return (
            value && value === 1 ?
                <Success message="Revoke successed." /> :
                <Error message="Failed to revoke this customer." />
        )
    }

    const fnAbort = new AbortController()

    useEffect(() => {
        const fetchData = async () => {
            await Get(currentFilter).then(res => {
                setTableData(res)
                setIsLoading(false)
            }).catch((err) => { return () => fnAbort.abort() })
        }
        fetchData()
    }, [isLoading, currentFilter])

    useEffect(() => {
        const fnAbort = new AbortController()
        const fetchData = async () => {
            await fnEmailStatuses.Get().then(res => {
                if (!isEmptyValue(res.data)) {
                    let emailStatusOption = res.data.map((row) => {
                        return { value: row.id, label: row.name }
                    })
                    setEmailStatus([
                        ...initialOption,
                        ...emailStatusOption
                    ])
                } else {
                    setEmailStatus(initialOption)
                }
            }).catch((err) => { return () => fnAbort.abort() })

        }
        fetchData()
    }, [])

    return (
        <>
            <h1 className="mt-4">Email</h1>
            <ol className="breadcrumb mb-4">
                <li className="breadcrumb-item">Email</li>
            </ol>
            {notif.show && notif.type === 'error' && <Error
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            {notif.show && notif.type === 'success' && <Success
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            {notif.show && notif.type === 'warning' && <Warning
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            <div className="card mb-4">
                <div className="card-header">
                    <i className="fas fa-table mr-1"></i> Filter Data
                </div>
                <div className="card-body">
                    <form onSubmit={handleSubmitFormFilter}>
                        <Row>
                            <Form.Group className="col-md-2" controlId="DisableDate">
                                <Form.Label>Disable Date</Form.Label>
                                <br />
                                <span className="btn btn-sm btn-outline-dark">
                                    <Form.Check type="checkbox" name="disable_date" className="text-center" onClick={e => handleChangeFormFilter('disable_date', e.target.checked)} />
                                </span>
                            </Form.Group>
                            <Form.Group className="col-md-2" controlId="StartDate">
                                <Form.Label>Start Date</Form.Label>
                                <DatePicker
                                    selected={new Date(formFilter.start_date)}
                                    dateFormat="yyyy-MM-dd"
                                    className="form-control"
                                    placeholderText="YYYY-MM-DD"
                                    name="start_date"
                                    showMonthDropdown
                                    showYearDropdown
                                    onChange={date => handleChangeFormFilter("start_date", date)}
                                    disabled={disableDate}
                                />
                            </Form.Group>

                            <Form.Group className="col-md-2" controlId="EndDate">
                                <Form.Label>End Date</Form.Label>
                                <DatePicker
                                    selected={new Date(formFilter.end_date) >= new Date(formFilter.start_date) ? new Date(formFilter.end_date) : new Date(formFilter.start_date)}
                                    dateFormat="yyyy-MM-dd"
                                    className="form-control"
                                    placeholderText="YYYY-MM-DD"
                                    name="end_date"
                                    minDate={new Date(formFilter.start_date)}
                                    // minDate={new Date()}
                                    showMonthDropdown
                                    showYearDropdown
                                    onChange={date => handleChangeFormFilter("end_date", date)}
                                    disabled={disableDate}
                                />
                            </Form.Group>

                            <Form.Group className="col-md-2" controlId="EndDate">
                                <Form.Label>Customer Name</Form.Label>
                                <input type="text" id="inputState" className="form-control" onChange={e => handleChangeFormFilter("customer_name", e.target.value)} />
                            </Form.Group>
                            <Form.Group className="col-md-2" controlId="EndDate">
                                <Form.Label>Email Status</Form.Label>
                                <Select
                                    options={emailStatus}
                                    onChange={(selected) => handleChangeFormFilter("email_status_id", selected.value)}
                                    value={!isEmptyValue(emailStatus) && emailStatus.filter((opt) => {
                                        return opt.value === formFilter.email_status_id;
                                    })}
                                />
                            </Form.Group>
                        </Row>
                        <button type="submit" className="btn btn-primary">Search</button>
                    </form>
                </div>
            </div>
            <div className="card mb-4">
                <div className="card-body">
                    {
                        alert && handleAlert(alert)
                    }
                    {/* <ExportToExcel rawData={exportData} fileName="user-data" />&nbsp; */}
                    {(userLevelId == 2 || userLevelId == 5 || userLevelId == 1) &&
                        <Button variant="outline-primary" onClick={handleModalAdd}>Upload Customer</Button>
                    }
                    <hr />
                    <div className="table-responsive">
                        <Table striped hover responsive width="100%" cellSpacing="0" cellPadding="0">
                            <thead className="thead-dark">
                                <tr className="text-center">
                                    <th>No.</th>
                                    <th>Customer Name</th>
                                    <th>Email</th>
                                    <th>Send Date</th>
                                    <th>Email Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr className="text-center">
                                    <th>No.</th>
                                    <th>Customer Name</th>
                                    <th>Email</th>
                                    <th>Send Date</th>
                                    <th>Email Status</th>
                                    <th>Action</th>
                                </tr>
                            </tfoot>
                            <tbody>
                                {isLoading ? (
                                    <tr>
                                        <td colSpan="9" className="text-center">
                                            <Spinner animation="border" size="sm" className="mr-1" />
                                            Loading data...
                                        </td>
                                    </tr>
                                ) : (
                                        tableData.total_data > 0 ? (
                                            tableData.data.map((item, i) => (
                                                <tr key={item.id} className="text-center">
                                                    <td>{tableData.paging.index[i]}</td>
                                                    <td>{item.customer_name}</td>
                                                    <td>{item.content && item.content.replace(/<[^>]+>/g, ' ').substring(0, 30)}...</td>
                                                    <td>{item.created_at && item.created_at.substring(0, 10)}</td>
                                                    <td>{item.email_status}</td>
                                                    <td>
                                                        <Button variant="warning" size="sm" className="m-1" data-toggle="modal" onClick={(e) => { handleModalDetail(item.id) }}>
                                                            <i className="fas fa-search fa-fw"></i>
                                                        </Button>

                                                        {item.email_status_id == 2 ?
                                                            (
                                                                <Button variant="danger" size="sm" className="m-1" data-toggle="modal" title="Revoke" disabled onClick={(e) => { handleModalConfirm(item.customer_id, item.name) }}>
                                                                    <i className="fas fa-undo fa-fw"></i>
                                                                </Button>
                                                            ) : (
                                                                <Button variant="danger" size="sm" className="m-1" data-toggle="modal" title="Revoke" onClick={(e) => { handleModalConfirm(item.customer_id, item.name) }}>
                                                                    <i className="fas fa-undo fa-fw"></i>
                                                                </Button>
                                                            )
                                                        }
                                                    </td>
                                                </tr>
                                            ))
                                        ) : (
                                                <>
                                                    <tr>
                                                        <td colSpan="6" className="text-center"><span className="text-danger">No data found</span></td>
                                                    </tr>
                                                </>
                                            )
                                    )}
                            </tbody>
                        </Table>
                    </div>
                    {isLoading === false && !_.isEmpty(tableData) &&
                        <Pagination
                            total={tableData.total_data}
                            limit={tableData.limit}
                            paging={tableData.paging}
                            pageChange={async (pageNumber) => {
                                await setIsLoading(true)
                                setCurrentFilter({
                                    ...currentFilter,
                                    page: pageNumber
                                })
                            }}
                        />
                    }
                </div>
            </div>
            <Modal show={modalAdd.show} onHide={handleModalClose} backdrop="static" keyboard={false} size="lg">
                <Modal.Header closeButton>
                    <Modal.Title>Import Campaign</Modal.Title>
                </Modal.Header>
                <FormAdd
                    dataId={modalAdd.dataId}

                    modalChange={(params) => {
                        setModalAdd({
                            ...modalAdd,
                            ...params
                        })
                    }}
                    notifChange={(value) => {
                        setNotif(value)
                    }}
                    dataChange={async () => {
                        await setIsLoading(true)
                    }}
                    isLoading={isLoading}
                    setIsLoading={setIsLoading}
                />
            </Modal>
            <Modal show={modalDetail.show} onHide={handleModalClose} backdrop="static" keyboard={false}>
                <Modal.Header closeButton>
                    <Modal.Title>Detail Email</Modal.Title>
                </Modal.Header>
                <FormDetail
                    dataId={modalDetail.dataId}
                    modalChange={(params) => {
                        setModalDetail({
                            ...modalDetail,
                            ...params
                        })
                    }}
                    notifChange={(value) => {
                        setNotif(value)
                    }}
                    dataChange={async () => {
                        await setIsLoading(true)
                    }}
                />
            </Modal>

            <Modal show={modalConfirm.show} onHide={handleModalClose} backdrop="static" keyboard={false} >
                <Modal.Header closeButton>
                    <Modal.Title>Confirm Revoke</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    Are you sure want to revoke this customer?
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="danger" onClick={handleModalClose}>No</Button>
                    <Button variant="primary" onClick={e => { handleModalRevoke(modalConfirm.dataId) }}>
                        Yes
                    </Button>
                </Modal.Footer>
            </Modal>

        </>
    )
}

const initialNotif = {
    title: "",
    message: "",
    show: false,
    type: null
}

const initialModal = {
    show: false,
    dataId: null
}

const initialOption = [{
    value: "",
    label: "Choose..."
}]
