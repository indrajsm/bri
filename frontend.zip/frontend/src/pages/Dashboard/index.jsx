import { useState, useEffect, useContext } from 'react'
import { Form, Col, Card } from 'react-bootstrap'
import _ from 'lodash'
import Highcharts from 'highcharts'
import HighchartsExporting from 'highcharts/modules/exporting'
import HighchartsReact from 'highcharts-react-official'
import { generalService } from './../../utils/services'
import { useCampaigns } from './../../utils/functions'
import { CustomSelect } from './../../components'

const { isEmptyValue } = generalService

if (typeof Highcharts === 'object') {
    HighchartsExporting(Highcharts)
}

export const Dashboard = ({ socket }) => {
    const fnCampaigns = useCampaigns()
    const [highchartsAmount, setHighchartsAmount] = useState([])
    const [highchartsCall, setHighchartsCall] = useState([])
    const [optionCampaign, setOptionCampaign] = useState([{
        value: "",
        label: "All Campaign"
    }])
    const [selectedCampaign, setSelectedCampaign] = useState("")

    useEffect(() => {
        const fetchData = async () => {
            await fnCampaigns.Get({
                limit: 100,
                order: "name",
                media_id: 1
            }).then((res) => {
                if (!isEmptyValue(res.data)) {
                    let mapOption = res.data.map((row) => {
                        return { value: row.id, label: row.name }
                    })

                    setOptionCampaign([
                        ...optionCampaign,
                        ...mapOption
                    ])
                }
            }).catch((err) => { return }) //do nothing, let it go back to login
        }

        fetchData()
        return () => setOptionCampaign([{
            value: "",
            label: "All Campaign"
        }])
    }, [])

    useEffect(() => {
        const socketEmit = () => {
            socket.emit("amount-all-campaigns")
            socket.emit("call-all-campaigns")
        }

        const socketEmitFilter = () => {
            socket.emit("amount-campaigns", {
                campaign_id: selectedCampaign
            })
            socket.emit("call-campaigns", {
                campaign_id: selectedCampaign
            })
        }

        isEmptyValue(selectedCampaign) ? socketEmit() : socketEmitFilter()
    }, [socket, selectedCampaign])

    useEffect(() => {
        const socketEvent = () => {
            socket.on("total-amount-all-campaigns", (data) => {
                data = JSON.parse(data)
                let mapData = data.map((row) => {
                    return {
                        name: row.username,
                        data: [row.amount]
                    }
                })
                setHighchartsAmount(mapData)
            })
            socket.on("total-call-all-campaigns", (data) => {
                data = JSON.parse(data)
                let mapData = data.map((row) => {
                    return {
                        name: row.username,
                        data: [row.total_call]
                    }
                })
                setHighchartsCall(mapData)
            })
            socket.on("total-amount-campaigns", (data) => {
                data = JSON.parse(data)
                let mapData = data.filter(i => i.campaign_id === selectedCampaign).map((row) => {
                    return {
                        name: row.username,
                        data: [row.amount]
                    }
                })
                setHighchartsAmount(mapData)
            })
            socket.on("total-call-campaigns", (data) => {
                data = JSON.parse(data)
                // console.log(data, 'total-call-campaings')
                let mapData = data.filter(i => i.campaign_id === selectedCampaign).map((row) => {
                    return {
                        name: row.username,
                        data: [row.total_call]
                    }
                })
                setHighchartsCall(mapData)
            })
        }

        socketEvent()
        return () => {
            setHighchartsAmount([])
            setHighchartsCall([])
        }
    }, [socket, selectedCampaign])

    const optionHighchartsAmount = {
        chart: {
            type: 'column'
        },
        title: {
            text: ''
        },
        xAxis: {
            type: 'category',
            categories: [null],
            crosshair: true,
            labels: {
                formatter: () => {
                    return null
                }
            }
        },
        yAxis: {
            min: 0,
            title: {
                text: 'Amount'
            }
        },
        credits: false,
        series: highchartsAmount
    }

    const optionHighchartsCall = {
        chart: {
            type: 'column'
        },
        title: {
            text: ''
        },
        xAxis: {
            type: 'category',
            categories: [null],
            crosshair: true,
            labels: {
                formatter: () => {
                    return null
                }
            }
        },
        yAxis: {
            min: 0,
            title: {
                text: 'Total Call'
            }
        },
        credits: false,
        series: highchartsCall
    }

    return (
        <>
            <h1 className="mt-4">Dashboard</h1>
            <ol className="breadcrumb mb-4">
                <li className="breadcrumb-item active">Dashboard</li>
            </ol>
            <Card className="mb-4">
                <Card.Header>
                    <i className="fas fa-table mr-1"></i> Filter Data
                </Card.Header>
                <Card.Body>
                    <Form.Row>
                        <Col md="3">
                            <Form.Label srOnly>Campaign</Form.Label>
                            <CustomSelect.SelectBox
                                optionSelect={optionCampaign}
                                onChangeValue={(value) => setSelectedCampaign(value)}
                                value={selectedCampaign}
                            />
                        </Col>
                    </Form.Row>
                </Card.Body>
            </Card>
            <Card className="mb-4">
                <Card.Header>
                    <i className="fas fa-chart-bar mr-1"></i> Outgoing Call
                </Card.Header>
                <Card.Body>
                    <HighchartsReact
                        highcharts={Highcharts}
                        options={optionHighchartsCall}
                    />
                </Card.Body>
            </Card>
            <Card>
                <Card.Header>
                    <i className="fas fa-chart-bar mr-1"></i> Nilai Transaksi
                </Card.Header>
                <Card.Body>
                    <HighchartsReact
                        highcharts={Highcharts}
                        options={optionHighchartsAmount}
                    />
                </Card.Body>
            </Card>
        </>
    )
}
