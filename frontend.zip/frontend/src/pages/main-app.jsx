import { useState, useEffect, useContext } from 'react'
import { BrowserRouter as Router, Switch, Route, useRouteMatch } from 'react-router-dom'
import { FooterComp, Sidebar, NavbarComp, ModalPasswordExpired, Error404 } from './../components'
import { Modal } from 'react-bootstrap'
import { PrivateRoute } from './../config'
import { SocketContext } from './../utils/context'
import { generalService } from './../utils/services'
import _ from 'lodash'

// Dashboard
import { Dashboard } from './Dashboard'

// Campaign
import { CampaignEmails } from './CampaignEmails'
import { CampaignCalls } from './CampaignCalls';

// Customer 
import { CustomerCalls } from './CustomerCalls';

// Call
import { Calls } from './Calls';

// Email
import { Emails } from './Emails';

// Callback
import { Callback } from './Callback'

// User Activity
import { UserActivity } from './UserActivity'

// Reports
import {
    ReportBreak,
    ReportBusinessAchievement,
    ReportCallActivity,
    ReportCallCustomer,
    ReportCallDetail,
    ReportChecker,
    ReportCostViewer,
    ReportEmail,
    ReportPerformanceAgent,
    ReportQualityAssuranceSummary
} from './Reports'

// Quality Assurance
import { QualityAssurance } from './QualityAssurance'
import { QualityAssuranceCalls } from './QualityAssuranceCalls'

// Setting
import { Users } from './Users'
import { BreakReason } from './BreakReason'
import { CheckingReason } from './CheckingReason'
import { OutboundCategory } from './OutboundCategory'
import { OutboundCategoryDetail } from './OutboundCategoryDetail'

// element
import { Break } from './Elements/Break';
import { Element } from './Elements';

export const MainApp = () => {
    const [modalBreak, setModalBreak] = useState(initialModalBreak)
    const userLevelId = localStorage.getItem('userLevelId')

    const handleModalBreak = () => {
        setModalBreak({
            ...modalBreak,
            show: !modalBreak.show
        })
    }

    const handleModalClose = () => {
        setModalBreak(initialModalBreak)
    }

    useEffect(() => {
        const start_break = localStorage.getItem('startBreak')
        if (start_break) return handleModalBreak()
    }, [])

    const socket = useContext(SocketContext)
    const { useLocalStorage } = generalService
    const [listenData, setListenData] = useLocalStorage('listenData', false)
    const [whisperData, setWhisperData] = useLocalStorage('whisperData', false)

    // listen and whisper
    useEffect(() => {
        const socketEventListenData = () => {
            socket.on('originate-response-event', (data) => {
                setListenData({
                    ...listenData,
                    channel: data['channel']
                })
                setWhisperData(false)
            })
        }
        const socketEventWhisperData = () => {
            socket.on('originate-response-event', (data) => {
                setWhisperData({
                    ...whisperData,
                    channel: data['channel']
                })
                setListenData(false)
            })
        }

        if (listenData) socketEventListenData()
        if (whisperData) socketEventWhisperData()
    }, [socket, setListenData, setWhisperData])

    return (
        <div>
            < Element />
            <div id="wrapper">
                <NavbarComp handleModalBreak={handleModalBreak} socket={socket} />
                <div id="layoutSidenav">
                    <Sidebar />
                    <div id="layoutSidenav_content">
                        <main>
                            <div className="container-fluid">
                                <Switch>
                                    {[1,2,5].includes(parseInt(userLevelId)) &&
                                        <PrivateRoute exact path="/">
                                            <Dashboard socket={socket} />
                                        </PrivateRoute>
                                    }

                                    {[1,2,5].includes(parseInt(userLevelId)) &&
                                        <PrivateRoute path="/campaign-calls">
                                            <CampaignCalls />
                                        </PrivateRoute>
                                    }

                                    {[2,5].includes(parseInt(userLevelId)) &&
                                        <PrivateRoute path="/campaign-emails">
                                            <CampaignEmails />
                                        </PrivateRoute>
                                    }

                                    <PrivateRoute path="/customer-calls/:campaignId/:campaignName">
                                        <CustomerCalls />
                                    </PrivateRoute>
                                    <PrivateRoute path="/calls/:campaignId/:campaignName">
                                        <Calls />
                                    </PrivateRoute>
                                    <PrivateRoute path="/emails/:campaignId/:campaignName">
                                        <Emails />
                                    </PrivateRoute>

                                    {[1,2,5].includes(parseInt(userLevelId)) &&
                                        <PrivateRoute path="/callback">
                                            <Callback />
                                        </PrivateRoute>
                                    }

                                    {[1,2,5].includes(parseInt(userLevelId)) &&
                                        <PrivateRoute path="/user-activity">
                                            <UserActivity
                                                socket={socket}
                                                listenData={listenData}
                                                whisperData={whisperData}
                                                setListenData={setListenData}
                                                setWhisperData={setWhisperData}
                                            />
                                        </PrivateRoute>
                                    }

                                    {[2,5].includes(parseInt(userLevelId)) &&
                                        <Route path="/reports" render={({ match: { url } }) => (
                                            <>
                                                <PrivateRoute path={url} exact>
                                                    <Error404 />
                                                </PrivateRoute>
                                                <PrivateRoute path={`${url}/break`} exact>
                                                    <ReportBreak />
                                                </PrivateRoute>
                                                <PrivateRoute path={`${url}/business-achievement`} exact>
                                                    <ReportBusinessAchievement />
                                                </PrivateRoute>
                                                <PrivateRoute path={`${url}/call-activity`} exact>
                                                    <ReportCallActivity />
                                                </PrivateRoute>
                                                <PrivateRoute path={`${url}/call-customer`} exact>
                                                    <ReportCallCustomer />
                                                </PrivateRoute>
                                                <PrivateRoute path={`${url}/call-detail`} exact>
                                                    <ReportCallDetail />
                                                </PrivateRoute>
                                                <PrivateRoute path={`${url}/checker`} exact>
                                                    <ReportChecker />
                                                </PrivateRoute>
                                                <PrivateRoute path={`${url}/cost-viewer`} exact>
                                                    <ReportCostViewer />
                                                </PrivateRoute>
                                                <PrivateRoute path={`${url}/email`} exact>
                                                    <ReportEmail />
                                                </PrivateRoute>
                                                <PrivateRoute path={`${url}/performance-agent`} exact>
                                                    <ReportPerformanceAgent />
                                                </PrivateRoute>
                                            </>
                                        )} />
                                    }

                                    {[4].includes(parseInt(userLevelId)) &&
                                        <PrivateRoute path="/quality-assurance">
                                            <QualityAssurance />
                                        </PrivateRoute>
                                    }
                                    {[2,3,4,5].includes(parseInt(userLevelId)) &&
                                        <PrivateRoute path="/quality-assurance-calls">
                                            <QualityAssuranceCalls />
                                        </PrivateRoute>
                                    }
                                    {[1,2,4,5].includes(parseInt(userLevelId)) &&
                                        <PrivateRoute path="/quality-assurance-report-summaries">
                                            <ReportQualityAssuranceSummary />
                                        </PrivateRoute>
                                    }

                                    {[2,5].includes(parseInt(userLevelId)) &&
                                        <Route path="/setting" render={({ match: { url } }) => (
                                            <>
                                                <PrivateRoute path={url} exact>
                                                    <Error404 />
                                                </PrivateRoute>
                                                <PrivateRoute path={`${url}/users`} exact>
                                                    <Users />
                                                </PrivateRoute>
                                                <PrivateRoute path={`${url}/break-reason`} exact>
                                                    <BreakReason />
                                                </PrivateRoute>
                                                <PrivateRoute path={`${url}/checking-reason`} exact>
                                                    <CheckingReason />
                                                </PrivateRoute>
                                                <PrivateRoute path={`${url}/outbound-category`} exact>
                                                    <OutboundCategory />
                                                </PrivateRoute>
                                                <PrivateRoute path={`${url}/outbound-category-detail`} exact>
                                                    <OutboundCategoryDetail />
                                                </PrivateRoute>
                                            </>
                                        )} />
                                    }

                                    <PrivateRoute path="*">
                                        <Error404 />
                                    </PrivateRoute>
                                </Switch>
                            </div>
                        </main>
                        <FooterComp />
                    </div>
                </div>
                <ModalPasswordExpired />
            </div>


            <Modal show={modalBreak.show} onHide={handleModalClose} backdrop="static" keyboard={false}>
                <Modal.Header >
                    <Modal.Title>Break</Modal.Title>
                </Modal.Header>
                <Break handleModalClose={handleModalClose} socket={socket} />
            </Modal>

            {/* <script src="https://unpkg.com/react/umd/react.production.min.js" crossOrigin="true"></script>
            <script src="https://unpkg.com/react-dom/umd/react-dom.production.min.js" crossOrigin="true"></script>
            <script src="https://unpkg.com/react-bootstrap@next/dist/react-bootstrap.min.js" crossOrigin="true"></script> */}
            {/* <script src="sb-admin-2.min.js"></script>
            <Router>
                <Switch>
                    <Route path="/users">
                        <Users />
                    </Route>
                    <Route path="/" >
                        <Dashboard />
                    </Route>
                </Switch>
            </Router> */}
        </div >
    )
}

const initialModalBreak = {
    show: false,
    dataId: ""
}
