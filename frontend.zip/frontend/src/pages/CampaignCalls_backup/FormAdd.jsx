import React, { useEffect, useState, useCallback, useRef } from 'react'
import { Button, Form, Modal, Table, Spinner } from 'react-bootstrap'
import Select from "react-select";
import DatePicker from "react-datepicker";
import moment from 'moment'
import _ from 'lodash'
import { campaignController, customerFieldController, campaignFieldController, userController, campaignUserController, campaignInfoController } from '../../utils/controllers';
import { generalService } from '../../utils/services';

const { isEmptyValue } = generalService
export const FormAdd = ({ modalChange, notifChange, dataChange }) => {
    const [campaignId, setCampaignId] = useState('')
    const [step, setStep] = useState(1)

    const handleModalClose = useCallback(() => {
        modalChange({
            show: false,
            campaignId: ''
        })
    }, [modalChange])

    return (
        <>
            {step === 1 &&
                <FormCampaign setStep={setStep} setCampaignId={setCampaignId} dataChange={dataChange} />
            }
            {step === 2 &&
                <FormCampaignField setStep={setStep} step={step} campaignId={campaignId} />
            }

            {step === 3 &&
                <FormCampaignUser setStep={setStep} step={step} campaignId={campaignId} />
            }
            {step === 4 &&
                <FormCampaignInfo setStep={setStep} step={step} campaignId={campaignId} handleModalClose={handleModalClose} />
            }
        </>
    )
}

const FormCampaign = ({ setStep, setCampaignId, dataChange }) => {
    const { Add } = campaignController
    const [newCampaign, setNewCampaign] = useState({
        name: "",
        start_date: moment().toDate(),
        end_date: new Date(),
        is_active: 1
    })
    const [process, setProcess] = useState(false)


    // add campaign
    const handleStep1 = async (e) => {
        e.preventDefault()
        await setProcess(true)
        newCampaign.start_date = moment(newCampaign.start_date).format("YYYY-MM-DD HH:mm")
        newCampaign.end_date = moment(newCampaign.end_date).format("YYYY-MM-DD HH:mm")
        const add = await Add({ ...newCampaign, media_id: 1 })

        if (add.success) {
            setStep(2)
            setCampaignId(add.data.id)
            dataChange()
        }
    }
    return (
        <>
            <Form onSubmit={handleStep1}>
                <Modal.Body>
                    <Form.Group className="mb-3">
                        <Form.Label>Campaign Name</Form.Label>
                        <Form.Control type="text" placeholder="Campaign Name" name="name" value={newCampaign.name} onChange={(e) => setNewCampaign({ ...newCampaign, name: e.target.value })} required />
                    </Form.Group>
                    <Form.Group className="mb-3">
                        <Form.Label>Start Campaign</Form.Label>
                        <DatePicker
                            className="form-control"
                            selected={newCampaign.start_date}
                            onChange={(date) => setNewCampaign({ ...newCampaign, start_date: date })}
                            name="start_date"
                            timeInputLabel="Time:"
                            dateFormat="yyyy-MM-dd HH:mm"
                            showTimeInput
                            minDate={new Date()}
                            value={newCampaign.start_date}
                            required
                        />
                    </Form.Group>
                    <Form.Group className="mb-3">
                        <Form.Label>End Campaign</Form.Label>
                        <DatePicker
                            className="form-control"
                            selected={newCampaign.end_date}
                            onChange={(date) => setNewCampaign({ ...newCampaign, end_date: date })}
                            name="end_date"
                            timeInputLabel="Time:"
                            dateFormat="yyyy-MM-dd HH:mm"
                            showTimeInput
                            minDate={new Date()}
                            value={newCampaign.end_date}
                            required
                        />
                    </Form.Group>
                    <Form.Group className="mb-3" controlId="Predictive">
                        <Form.Check type="checkbox" defaultChecked={true} name="is_active" className="text-center" onChange={(e) => setNewCampaign({ ...newCampaign, is_active: e.target.checked === false ? 0 : 1 })} label="Predictive Call" />
                    </Form.Group>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="primary" type="submit">{process ? <Spinner animation="border" size="sm" className="mr-1" /> : 'Next'}</Button>
                </Modal.Footer>
            </Form>
        </>
    )
}

const FormCampaignField = ({ setStep, step, campaignId }) => {
    const [isLoading, setIsLoading] = useState(true)
    const { Get } = customerFieldController
    const { Add } = campaignFieldController
    const [field, setField] = useState({})
    const [fieldList, setFieldList] = useState({})
    const [process, setProcess] = useState(false)
    const [require, setRequire] = useState(false)
    const inputRef = useRef(null);

    useEffect(() => {
        const fetchData = async () => {
            const res = await Get()
            setField(res.data)
            setIsLoading(false)
        }
        fetchData()
    }, [step])

    // Add campaign field
    const handleStep2 = async (e) => {
        e.preventDefault(e)
        await setProcess(true)

        if (!isEmptyValue(fieldList) && _.isObject(fieldList)) {
            let data_field = fieldList.map(item => {
                return {
                    'campaign_id': campaignId,
                    'customer_field_id': item.id
                }
            })
            const add_field = await Add(data_field)

            if (add_field.success) {
                setStep(3)
            } else {
                await setProcess(false)
            }
        } else {
            inputRef.current.focus();
            setRequire(true)
            await setProcess(false)
        }

    }
    return (
        <>
            {isLoading ? (
                <Modal.Body>
                    <Spinner animation="border" size="sm" className="mr-1" />
                    Loading data...
                            </Modal.Body>
            ) : (
                    <>
                        <Form onSubmit={handleStep2}>
                            <Modal.Body>
                                <Form.Group className="mb-3" >
                                    <Select
                                        // defaultValue={}
                                        isMulti
                                        name="colors"
                                        options={field}
                                        getOptionValue={(field) => field.id}
                                        getOptionLabel={(field) => field.field_display_name}
                                        className="basic-multi-select"
                                        classNamePrefix="select"
                                        onChange={(item) => (setFieldList(item), setRequire(false))}
                                        placeholder="Select Field"
                                        ref={inputRef}
                                    />
                                    {require &&
                                        <span className="text-danger">
                                            {"Field Type is required"}
                                        </span>
                                    }
                                </Form.Group>
                            </Modal.Body>
                            <Modal.Footer>
                                <Button variant="primary" type="submit">{process ? <Spinner animation="border" size="sm" className="mr-1" /> : 'Next'}</Button>
                            </Modal.Footer>
                        </Form>
                    </>
                )}

        </>
    )
}

const FormCampaignUser = ({ setStep, step, campaignId }) => {
    const { Get } = userController
    const { Add } = campaignUserController
    const [isLoading, setIsLoading] = useState(true)
    const [user, setUser] = useState({})
    const [userList, setUserList] = useState({})
    const [process, setProcess] = useState(false)
    const [require, setRequire] = useState(false)
    const inputRef = useRef(null);

    useEffect(() => {
        const fetchData = async () => {
            const res = await Get({ user_level_id: 1 })
            setUser(res.data)
            setIsLoading(false)
        }
        fetchData()
    }, [step])

    // add campaign user
    const handleStep3 = async (e) => {
        e.preventDefault(e)
        await setProcess(true)
        if (!isEmptyValue(userList) && _.isObject(userList)) {
            let data_user = userList.map(item => {
                return {
                    'campaign_id': campaignId,
                    'user_id': item.id
                }
            })

            const add_user = await Add(data_user)

            if (add_user.success) {
                setStep(4)
            } else {
                setProcess(false)
            }
        } else {
            inputRef.current.focus();
            setRequire(true)
            setProcess(false)
        }
    }
    return (
        <>
            {isLoading ? (
                <Modal.Body>
                    <Spinner animation="border" size="sm" className="mr-1" />
                    Loading data...
                            </Modal.Body>
            ) : (
                    <>
                        <Form onSubmit={handleStep3}>

                            <Modal.Body>
                                <Form.Group className="mb-3" >
                                    <Select
                                        // defaultValue={}
                                        isMulti
                                        name="colors"
                                        options={user}
                                        getOptionValue={(user) => user.id}
                                        getOptionLabel={(user) => user.username}
                                        className="basic-multi-select"
                                        classNamePrefix="select"
                                        onChange={(item) => (setUserList(item), setRequire(false))}
                                        placeholder="Select User"
                                        ref={inputRef}
                                    />
                                    {require &&
                                        <span className="text-danger">
                                            {"Field Type is required"}
                                        </span>
                                    }
                                </Form.Group>
                            </Modal.Body>
                            <Modal.Footer>
                                <Button variant="primary" type="submit">{process ? <Spinner animation="border" size="sm" className="mr-1" /> : 'Next'}</Button>
                            </Modal.Footer>
                        </Form>
                    </>
                )}
        </>
    )
}

const FormCampaignInfo = ({ setStep, step, campaignId, handleModalClose }) => {
    const [campaignInfo, setCampaignInfo] = useState({})
    const [newInfo, setNewInfo] = useState({
        campaign_id: "",
        name: "",
        info: "",
    })
    const [infoId, setInfoId] = useState('')
    const [isAddInfo, setIsAddInfo] = useState(true)
    const [isLoadingInfo, setIsLoadingInfo] = useState(true)
    const [isLoading, setIsLoading] = useState(true)

    const { Get, Add, Update } = campaignInfoController

    useEffect(() => {
        const fetchData = async () => {
            const res = await Get({ campaign_id: campaignId, is_active: 1 })
            setCampaignInfo(res)
        }
        setIsLoading(false)
        setIsLoadingInfo(false)
        fetchData()
    }, [step, isLoadingInfo])

    const handleSubmitInfo = async (e) => {
        e.preventDefault()

        await setIsLoadingInfo(true)
        const data_info = { ...newInfo, campaign_id: campaignId }
        const add_info = await Add(data_info)

        if (add_info.success) {
            setIsLoadingInfo(false)
        }

    }

    const handleDetailInfo = (id) => {
        setIsAddInfo(false)
        setInfoId(id)
        let selectInfo = campaignInfo.data.filter(item => item.id === id).map(row => {
            return {
                campaign_id: row.campaign_id,
                name: row.name,
                info: row.info
            }
        })
        selectInfo = selectInfo[0]
        setNewInfo({ ...newInfo, ...selectInfo })
    }

    const handleEditInfo = async (id) => {
        await setIsLoadingInfo(true)
        const update_info = await Update(id, newInfo)

        if (update_info.success) {
            setIsLoadingInfo(false)
            setIsAddInfo(true)
        }
    }

    const handleDeleteInfo = async (id) => {
        await setIsLoadingInfo(true)
        const data = { is_active: 0 }

        const delete_info = await Update(id, data)

        if (delete_info.success) {
            setIsLoadingInfo(false)
        } else {
            setIsLoadingInfo(false)
        }
    }

    const handleStep4 = async () => {
        handleModalClose()
    }

    return (
        <>
            {isLoading ? (
                <Modal.Body>
                    <Spinner animation="border" size="sm" className="mr-1" />
                    Loading data...
                            </Modal.Body>
            ) : (
                    <>
                        <Modal.Body>
                            <Form onSubmit={handleSubmitInfo}>

                                <Form.Group className="mb-3">
                                    <Form.Label>Name</Form.Label>
                                    <Form.Control type="text" required value={newInfo.name} onChange={(e) => setNewInfo({
                                        ...newInfo,
                                        name: e.target.value
                                    })} />
                                </Form.Group>
                                <Form.Group className="mb-3">
                                    <Form.Label>Info</Form.Label>
                                    <Form.Control as="textarea" rows={3} required value={newInfo.info} onChange={(e) => setNewInfo({
                                        ...newInfo,
                                        info: e.target.value
                                    })} />
                                </Form.Group>
                                <Form.Group className="mb-3">
                                    {isAddInfo ?
                                        <Button type="submit" variant="primary">Add</Button> :
                                        <Button variant="warning" onClick={e => handleEditInfo(infoId)}>Update</Button>
                                    }
                                </Form.Group>
                                <Table striped bordered hover>
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Name </th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {isLoadingInfo ? (
                                            <>
                                                <tr>
                                                    <td colSpan="9" className="text-center">
                                                        <Spinner animation="border" size="sm" className="mr-1" />
                                                        Loading data...
                                                                </td>
                                                </tr>
                                            </>
                                        ) : (
                                                campaignInfo.total_data > 0 ?
                                                    (
                                                        campaignInfo.data.map((item, index) =>
                                                            <tr key={item.id}>
                                                                <td>{index + 1}</td>
                                                                <td>{item.name}</td>
                                                                <td>
                                                                    <Button variant="warning" size="sm" className="m-1" title="Detail" data-toggle="modal" onClick={(e) => { handleDetailInfo(item.id) }}>
                                                                        <i className="fas fa-edit fa-fw"></i>
                                                                    </Button>
                                                                    <Button variant="danger" size="sm" className="m-1" title="Delete" onClick={(e) => { handleDeleteInfo(item.id) }}>
                                                                        <i className="fas fa-trash-alt fa-fw"></i>
                                                                    </Button>
                                                                </td>
                                                            </tr>
                                                        )
                                                    ) :
                                                    (
                                                        <tr>
                                                            <td colSpan="3" className="text-center">No Data Found</td>
                                                        </tr>
                                                    )
                                            )}

                                    </tbody>
                                </Table>
                            </Form>
                        </Modal.Body>
                        <Modal.Footer>
                            <Button type="submit" variant="primary" onClick={handleStep4}>Close</Button>
                        </Modal.Footer>

                    </>
                )}
        </>
    )
}
