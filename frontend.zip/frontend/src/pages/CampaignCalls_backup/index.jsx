import { Button, Form, Modal, Spinner, Table } from 'react-bootstrap'
import React, { useContext, useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import DatePicker from "react-datepicker";
import moment from 'moment'
import _ from 'lodash'
import { Pagination } from './../../components'
import { FormAdd } from './FormAdd';
import { campaignController } from '../../utils/controllers/campaignController';
import { FormDetail } from './FormDetail';

export const CampaignCalls = (props) => {
    const { GetCall } = campaignController

    const initialModal = {
        show: false,
        campaignId: ""
    }

    const [isLoading, setIsLoading] = useState(true)
    const [notif, setNotif] = useState(false)
    const [modalAdd, setModalAdd] = useState(initialModal)
    const [modalDetail, setModalDetail] = useState(initialModal)
    const [tableData, setTableData] = useState({})

    const [formFilter, setFormFilter] = useState({
        // start_date: defaultDate.toISOString().split('T')[0],
        // end_date: defaultDate.toISOString().split('T')[0],
        name: "",
    })
    const [currentFilter, setCurrentFilter] = useState({
        page: 1,
        ...formFilter
    })

    const handleModalAdd = () => {
        setModalAdd({
            ...modalAdd,
            show: !modalAdd.show,
        })
    }

    const handleModalDetail = (id) => {
        setModalDetail({
            ...modalDetail,
            show: !modalDetail.show,
            dataId: id
        })
    }

    const handleChangeFormFilter = (key, val) => {
        setFormFilter({ ...formFilter, [key]: val })
    }

    const handleSubmitFormFilter = async (e) => {
        e.preventDefault()
        // await setIsLoading(true)
        setCurrentFilter({
            page: 1,
            ...formFilter
        })
    }

    const handleModalClose = async () => {
        await GetCall()
        setModalAdd(initialModal)
        setModalDetail(initialModal)
    }

    useEffect(() => {
        const fetchData = async () => {
            const res = await GetCall(currentFilter)
            setTableData(res)
        }
        setIsLoading(false)
        fetchData()
    }, [isLoading, currentFilter])

    return (
        <>
            <h1 className="mt-4">Campaign Call</h1>
            <ol className="breadcrumb mb-4">
                <li className="breadcrumb-item"><a href="index.html">Campaigns</a></li>
                <li className="breadcrumb-item active">Campaign Call</li>
            </ol>
            <div className="card mb-4">
                <div className="card-header">
                    <i className="fas fa-table mr-1"></i> Filter Data
                </div>
                <div className="card-body">
                    <form onSubmit={handleSubmitFormFilter}>

                        <div className="form-row">
                            {/* <div className="form-group col-md-2">
                                <label htmlFor="DisableDate">Disable Date</label>
                                <br />
                                <span className="btn btn-sm btn-outline-dark">
                                    <input type="checkbox" name="disable_date" className="" id="DisableDate" value="1" data-parsley-multiple="disable_date" data-parsley-id="5" />
                                </span>
                            </div> */}
                            {/* <div className="form-group col-md-2">
                                <label htmlFor="CallDate">Start Campaign</label>
                                <br />
                                <Controller
                                    control={control}
                                    name="start_date"
                                    defaultValue={defaultDate}
                                    className="form-control"
                                    render={({ onChange, onBlur, value, className }) => (
                                        <DatePicker
                                            onChange={onChange}
                                            onBlur={onBlur}
                                            selected={value}
                                            dateFormat="yyyy-MM-dd"
                                            className="form-control"
                                            placeholderText="YYYY-MM-DD"
                                            name="start_date"
                                            id="StartDate"
                                            //withPortal
                                            minDate={new Date('2021-01-01')}
                                            minDate={new Date()}
                                            showMonthDropdown
                                            showYearDropdown
                                        />
                                    )}
                                    placeholderText="Click to select a date"
                                />
                            </div> */}
                            <div className="form-group col-md-2">
                                <label htmlFor="inputState">Name</label>
                                <input type="text" id="inputState" className="form-control" onChange={e => handleChangeFormFilter("name", e.target.value)} />
                            </div>
                        </div>
                        <div className="form-row">
                        </div>
                        <button type="submit" className="btn btn-primary">Search</button>
                    </form>
                </div>
            </div>
            <div className="card mb-4">
                <div className="card-body">
                    {/* <ExportToExcel rawData={exportData} fileName="user-data" />&nbsp; */}
                    <Button variant="outline-primary" onClick={handleModalAdd}>Add Campaign</Button>
                    <hr />
                    <div className="table-responsive">
                        <Table striped hover responsive width="100%" cellSpacing="0" cellPadding="0">
                            <thead className="thead-dark">
                                <tr className="text-center">
                                    <th>No.</th>
                                    <th>Name</th>
                                    <th>Start Date</th>
                                    <th>End Date</th>
                                    <th>Total Agents</th>
                                    <th>Total Customers</th>
                                    <th>Total Calls</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr className="text-center">
                                    <th>No.</th>
                                    <th>Name</th>
                                    <th>Start Date</th>
                                    <th>End Date</th>
                                    <th>Total Agents</th>
                                    <th>Total Customers</th>
                                    <th>Total Calls</th>
                                    <th>Action</th>
                                </tr>
                            </tfoot>
                            <tbody>
                                {isLoading ? (
                                    <tr>
                                        <td colSpan="9" className="text-center">
                                            <Spinner animation="border" size="sm" className="mr-1" />
                                            Loading data...
                                        </td>
                                    </tr>
                                ) : (
                                        tableData.total_data > 0 ? (
                                            tableData.data.map((item, i) => (
                                                <tr key={item.id} className="text-center">
                                                    <td>{tableData.paging.index[i]}</td>
                                                    <td>{item.name}</td>
                                                    <td>{item.start_date && item.start_date.substring(0, 10)}</td>
                                                    <td>{item.end_date && item.end_date.substring(0, 10)}</td>
                                                    <td>{item.total_agent}</td>
                                                    <td>{item.total_customer}</td>
                                                    <td>{item.total_call}</td>
                                                    <td >
                                                        <Button variant="primary" size="sm" className="m-1" data-toggle="modal" onClick={(e) => {
                                                            handleModalDetail(item.id)
                                                        }}>
                                                            <i className="fas fa-edit fa-fw"></i>
                                                        </Button>
                                                        <Link to={`customer-calls/${item.id}`} variant="warning" size="sm" className="m-1">
                                                            <Button variant="warning" size="sm" className="m-1">
                                                                <i className="fas fa-users fa-fw"></i>
                                                            </Button>
                                                        </Link>
                                                        <Button variant="info" size="sm" className="m-1">
                                                            <i className="fas fa-phone fa-fw"></i>
                                                        </Button>
                                                    </td>
                                                </tr>
                                            ))
                                        ) : (
                                                <>
                                                    <tr>
                                                        <td colSpan="6" className="text-center"><span className="text-danger">No data found</span></td>
                                                    </tr>
                                                </>
                                            )
                                    )}
                            </tbody>
                        </Table>
                    </div>
                    {isLoading === false && !_.isEmpty(tableData) &&
                        <Pagination
                            total={tableData.total_data}
                            limit={tableData.limit}
                            paging={tableData.paging}
                            pageChange={async (pageNumber) => {
                                await setIsLoading(true)
                                setCurrentFilter({
                                    ...currentFilter,
                                    page: pageNumber
                                })
                            }}
                        />
                    }
                </div>
            </div>
            <Modal show={modalAdd.show} onHide={handleModalClose} backdrop="static" keyboard={false}>
                <Modal.Header closeButton>
                    <Modal.Title>New Campaign</Modal.Title>
                </Modal.Header>
                <FormAdd
                    modalChange={(params) => {
                        setModalAdd({
                            ...modalAdd,
                            ...params
                        })
                    }}
                    notifChange={(value) => {
                        setNotif(value)
                    }}
                    dataChange={async () => {
                        await setIsLoading(true)
                    }}
                    isLoading={isLoading}
                    setIsLoading={setIsLoading}
                />
            </Modal>
            <Modal show={modalDetail.show} onHide={handleModalClose} backdrop="static" keyboard={false}>
                <Modal.Header closeButton>
                    <Modal.Title>Detail Campaign Call</Modal.Title>
                </Modal.Header>
                <FormDetail
                    dataId={modalDetail.dataId}
                    modalChange={(params) => {
                        setModalDetail({
                            ...modalDetail,
                            ...params
                        })
                    }}
                    notifChange={(value) => {
                        setNotif(value)
                    }}
                    dataChange={async () => {
                        await setIsLoading(true)
                    }}
                />
            </Modal>

        </>
    )
}
