import { Button, Form, Modal, Spinner, Table, Row } from 'react-bootstrap'
import React, { useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom';
import DatePicker from 'react-datepicker'
import Select from 'react-select'
import _ from 'lodash'
import { Pagination, Notification } from './../../components'
import { FormAdd } from './FormAdd';
import { FormDetail } from './FormDetail';
import { useCalls, useUsers } from '../../utils/functions';
import { generalService } from '../../utils/services';

const { isEmptyValue, formatDate } = generalService

export const Calls = (props) => {
    const { Get } = useCalls()
    const fnUsers = useUsers()
    const { Error, Success, Warning } = Notification
    const [isLoading, setIsLoading] = useState(true)
    const [notif, setNotif] = useState(initialNotif)
    const [modalAdd, setModalAdd] = useState(initialModal)
    const [modalDetail, setModalDetail] = useState(initialModal)
    const [tableData, setTableData] = useState({})
    const [disableDate, setDisableDate] = useState(false)
    const { campaignId, campaignName } = useParams();
    const [user, setUser] = useState({})


    const [formFilter, setFormFilter] = useState({
        customer_name: "",
        start: formatDate(),
        end: formatDate(),
        campaign_id: campaignId,
        user_id: ""
    })

    const [currentFilter, setCurrentFilter] = useState({
        page: 1,
        order: "created_at",
        ...formFilter
    })

    const handleModalAdd = () => {
        setModalAdd({
            ...modalAdd,
            show: !modalAdd.show,
            dataId: campaignId
        })
    }

    const handleModalDetail = (id) => {
        setModalDetail({
            ...modalDetail,
            show: !modalDetail.show,
            dataId: id
        })
    }

    const handleChangeFormFilter = (key, val) => {
        if (['start', 'end'].includes(key)) {
            val = formatDate(val)
        }
        if (key === 'disable_date') {
            val ? setDisableDate(true) : setDisableDate(false)
        }
        setFormFilter({ ...formFilter, [key]: val })
    }

    const handleSubmitFormFilter = async (e) => {
        e.preventDefault()
        await setIsLoading(true)
        setCurrentFilter({
            page: 1,
            ...formFilter
        })
    }

    const handleModalClose = async () => {
        await Get()
        setModalAdd(initialModal)
        setModalDetail(initialModal)
    }

    useEffect(() => {
        const fetchData = async () => {
            await Get(currentFilter).then(res => {
                setTableData(res)
                setIsLoading(false)
            }).catch((err) => { return })
        }
        fetchData()
    }, [isLoading, currentFilter])

    useEffect(() => {
        const fetchData = async () => {
            await fnUsers.Get({ user_level_id: 1 }).then(res => {
                if (!isEmptyValue(res.data)) {
                    let userOption = res.data.map((row) => {
                        return { value: row.id, label: row.username }
                    })
                    setUser([
                        ...initialOption,
                        ...userOption
                    ])
                } else {
                    setUser(initialOption)
                }
            }).catch((err) => { return })

        }
        fetchData()
    }, [])

    return (
        <>
            <h1 className="mt-4">Call ({campaignName})</h1>
            <ol className="breadcrumb mb-4">
                <li className="breadcrumb-item"><Link to="/campaign-calls">Campaign Call</Link></li>
                <li className="breadcrumb-item active">Call</li>
            </ol>
            {notif.show && notif.type === 'error' && <Error
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            {notif.show && notif.type === 'success' && <Success
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            {notif.show && notif.type === 'warning' && <Warning
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            <div className="card mb-4">
                <div className="card-header">
                    <i className="fas fa-table mr-1"></i> Filter Data
                </div>
                <div className="card-body">
                    <form onSubmit={handleSubmitFormFilter}>
                        <Row>
                            <Form.Group className="col-md-2" controlId="DisableDate">
                                <Form.Label>Disable Date</Form.Label>
                                <br />
                                <span className="btn btn-sm btn-outline-dark">
                                    <Form.Check type="checkbox" name="disable_date" className="text-center" onClick={e => handleChangeFormFilter('disable_date', e.target.checked)} />
                                </span>
                            </Form.Group>
                            <Form.Group className="col-md-2" controlId="StartDate">
                                <Form.Label>Start Date</Form.Label>
                                <DatePicker
                                    selected={new Date(formFilter.start)}
                                    dateFormat="yyyy-MM-dd"
                                    className="form-control"
                                    placeholderText="YYYY-MM-DD"
                                    name="start"
                                    showMonthDropdown
                                    showYearDropdown
                                    onChange={date => handleChangeFormFilter("start", date)}
                                    disabled={disableDate}
                                />
                            </Form.Group>

                            <Form.Group className="col-md-2" controlId="EndDate">
                                <Form.Label>End Date</Form.Label>
                                <DatePicker
                                    selected={new Date(formFilter.end) >= new Date(formFilter.start) ? new Date(formFilter.end) : new Date(formFilter.start)}
                                    dateFormat="yyyy-MM-dd"
                                    className="form-control"
                                    placeholderText="YYYY-MM-DD"
                                    name="end"
                                    minDate={new Date(formFilter.start)}
                                    // minDate={new Date()}
                                    showMonthDropdown
                                    showYearDropdown
                                    onChange={date => handleChangeFormFilter("end", date)}
                                    disabled={disableDate}
                                />
                            </Form.Group>
                            <Form.Group className="form-group col-md-3">
                                <Form.Label>Agent Name</Form.Label>
                                <Select
                                    options={user}
                                    onChange={(selected) => handleChangeFormFilter("user_id", selected.value)}
                                    value={!isEmptyValue(user) && user.filter((opt) => {
                                        return opt.value === formFilter.user_id;
                                    })}
                                />
                            </Form.Group>
                            <Form.Group className="col-md-2" controlId="EndDate">
                                <Form.Label>Customer Name</Form.Label>
                                <input type="text" id="inputState" className="form-control" onChange={e => handleChangeFormFilter("customer_name", e.target.value)} />
                            </Form.Group>
                        </Row>
                        <button type="submit" className="btn btn-primary">Search</button>
                    </form>
                </div>
            </div>
            <div className="card mb-4">
                <div className="card-body">
                    {/* <ExportToExcel rawData={exportData} fileName="user-data" />&nbsp; */}
                    <hr />
                    <div className="table-responsive">
                        <Table striped hover responsive width="100%" cellSpacing="0" cellPadding="0">
                            <thead className="thead-dark">
                                <tr className="text-center">
                                    <th>No.</th>
                                    <th>Customer Name</th>
                                    <th>Call Date</th>
                                    <th>Phone Number</th>
                                    <th>Call Duration</th>
                                    <th>Call Status</th>
                                    <th>Pickup By</th>
                                    <th>Notes</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr className="text-center">
                                    <th>No.</th>
                                    <th>Customer Name</th>
                                    <th>Call Date</th>
                                    <th>Phone Number</th>
                                    <th>Call Duration</th>
                                    <th>Call Status</th>
                                    <th>Pickup By</th>
                                    <th>Notes</th>
                                </tr>
                            </tfoot>
                            <tbody>
                                {isLoading ? (
                                    <tr>
                                        <td colSpan="9" className="text-center">
                                            <Spinner animation="border" size="sm" className="mr-1" />
                                            Loading data...
                                        </td>
                                    </tr>
                                ) : (
                                        tableData.total_data > 0 ? (
                                            tableData.data.map((item, i) => (
                                                <tr key={item.id} className="text-center">
                                                    <td>{tableData.paging.index[i]}</td>
                                                    <td>{item.customer_name}</td>
                                                    <td>{item.call_date && item.call_date.substring(0, 10)}</td>
                                                    <td>{item.phone_number}</td>
                                                    <td>{item.call_duration}</td>
                                                    <td>{item.outbound_status}</td>
                                                    <td>{item.pickup_by}</td>
                                                    <td>{item.note}</td>

                                                </tr>
                                            ))
                                        ) : (
                                                <>
                                                    <tr>
                                                        <td colSpan="8" className="text-center"><span className="text-danger">No data found</span></td>
                                                    </tr>
                                                </>
                                            )
                                    )}
                            </tbody>
                        </Table>
                    </div>
                    {isLoading === false && !_.isEmpty(tableData) &&
                        <Pagination
                            total={tableData.total_data}
                            limit={tableData.limit}
                            paging={tableData.paging}
                            pageChange={async (pageNumber) => {
                                await setIsLoading(true)
                                setCurrentFilter({
                                    ...currentFilter,
                                    page: pageNumber
                                })
                            }}
                        />
                    }
                </div>
            </div>

        </>
    )
}

const initialNotif = {
    title: "",
    message: "",
    show: false,
    type: null
}

const initialModal = {
    show: false,
    dataId: null
}

const initialOption = [{
    value: "",
    label: "Choose..."
}]
