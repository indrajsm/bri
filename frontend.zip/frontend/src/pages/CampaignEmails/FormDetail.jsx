import React, { useEffect, useState, useRef } from 'react'
import { Button, Form, Modal, Spinner, Row, Col, Nav } from 'react-bootstrap'
import { useForm, Controller } from 'react-hook-form'
import DatePicker from "react-datepicker";
import _ from 'lodash'
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from "yup";
import classnames from 'classnames'
import 'react-quill/dist/quill.snow.css';
import ReactQuill from 'react-quill';
import { useCampaigns, useCustomerFields, useEmailContents } from '../../utils/functions';
import { Notification } from '../../components'
import { generalService } from '../../utils/services';
import { EditorToolbar, modules, formats } from '../../components';
import '../../public/assets/styles/editor.css'

const { formatDateTime, isEmptyValue } = generalService

export const FormDetail = ({ dataId, modalChange, notifChange, dataChange }) => {
    const [step, setStep] = useState(1)
    const { Success, Error } = Notification

    const handleModalClose = () => {
        return modalChange({
            show: false,
            dataId: null
        })
    }

    const handleAlert = (value) => {
        return (
            value && value === 1 ?
                <Success message="Data has been updated." /> :
                <Error message="Failed to update data." />
        )
    }

    return (
        <>
            <NavTab setStep={setStep} step={step} />
            {step === 1 &&
                <FormCampaign dataId={dataId} setStep={setStep} step={step} dataChange={dataChange} campaignId={dataId} handleAlert={handleAlert} />
            }
            {step === 2 &&
                <FormCampaignContent setStep={setStep} step={step} campaignId={dataId} handleAlert={handleAlert} handleAlert={handleAlert} />
            }

        </>
    )
}

const FormCampaign = ({ dataId, step, setStep, dataChange, campaignId, handleAlert }) => {
    const { Get, Update } = useCampaigns()
    const [isLoading, setIsLoading] = useState(true)
    const [alert, setAlert] = useState(null)

    const { register, handleSubmit, reset, control, formState: { errors }, setValue } = useForm({
        defaultValues: initialCampaign,
        resolver: validationSchemaCampaign
    });
    const [selectedStartDate, setSelectedStartDate] = useState(new Date())

    // add campaign
    const onSubmit = async (data) => {
        await setIsLoading(true)

        const body = {
            name: data.name,
            start_date: formatDateTime(data.start_date),
            end_date: formatDateTime(data.end_date),
        }
        await Update(campaignId, body).then(async (res) => {
            if (res.success) {
                await setIsLoading(false)
                dataChange()
                setAlert(1)
            } else {
                setAlert(2)
            }
        }).catch((err) => { return })
    }


    useEffect(() => {
        const fnAbort = new AbortController()
        const fetchData = async () => {
            await Get({ id: dataId }).then((res) => {
                if (!isEmptyValue(res.data)) {
                    reset({
                        name: res.data.name || "",
                        start_date: new Date(res.data.start_date) || null,
                        end_date: new Date(res.data.end_date) || null,
                    }, { keepErrors: false })
                }
            }).catch((err) => { return () => fnAbort.abort() })
            setIsLoading(false)
        }
        fetchData()
    }, [reset]);

    return (
        <>
            <Form onSubmit={handleSubmit(onSubmit)}>
                <Modal.Body>
                    {
                        alert && handleAlert(alert)
                    }
                    <Form.Group className="mb-3">
                        <Form.Label>Campaign Name</Form.Label>
                        <Form.Control type="text" placeholder="Campaign Name" {...register("name")} isInvalid={!!errors.name} />
                        <Form.Control.Feedback type="invalid">{errors.name ?.message}</Form.Control.Feedback>
                    </Form.Group>
                    <Row>
                        <Form.Group className="col-md-6">
                            <Form.Label>Start Campaign</Form.Label>
                            <Controller
                                control={control}
                                name='start_date'
                                className="form-control"
                                render={({ field: { value, onChange } }) => (
                                    <DatePicker
                                        className="form-control form-control-sm"
                                        dateFormat="yyyy-MM-dd HH:mm"
                                        showTimeInput
                                        disabledKeyboardNavigation
                                        selected={value}
                                        onChange={(date) => {
                                            onChange(date)
                                            formatDateTime(date) === false ? setSelectedStartDate(new Date()) : setSelectedStartDate(date)
                                            setValue('end_date', date)
                                        }}
                                        highlightDates={[new Date(), new Date()]}
                                        minDate={new Date()}
                                    />
                                )}
                            />

                        </Form.Group>
                        <Form.Group className="col-md-6">
                            <Form.Label>End Campaign</Form.Label>
                            <Controller
                                control={control}
                                name='end_date'
                                className="form-control"
                                render={({ field: { value, onChange } }) => (
                                    <DatePicker
                                        className="form-control form-control-sm"
                                        dateFormat="yyyy-MM-dd HH:mm"
                                        showTimeInput
                                        disabledKeyboardNavigation
                                        selected={value}
                                        onChange={onChange}
                                        highlightDates={[new Date(), new Date()]}
                                        minDate={selectedStartDate}
                                    />
                                )}
                            />
                        </Form.Group>
                    </Row>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="primary" type="submit">{isLoading ? <Spinner animation="border" size="sm" className="mr-1" /> : 'Update'}</Button>
                </Modal.Footer>
            </Form>
        </>
    )
}

const FormCampaignContent = ({ step, campaignId, handleModalClose, handleAlert }) => {
    const [field, setField] = useState({})
    const { Get } = useCustomerFields()
    const fnEmailContents = useEmailContents()
    const [isLoading, setIsLoading] = useState(true)
    const [process, setProcess] = useState(false)
    const [emailId, setEmailId] = useState(null)
    const [alert, setAlert] = useState(null)
    const quillRef = useRef();

    const { control, register, reset, handleSubmit, setValue, formState: { errors } } = useForm({
        defaultValues: initialEmailContent,
        resolver: validationSchemaEmailContent
    })

    useEffect(() => {
        const fnAbort = new AbortController()
        const fetchData = async () => {
            await Get({
                limit: "100",
                order: "field_name_display",
                is_active: 1
            }).then((res) => {
                if (!isEmptyValue(res.data)) {
                    setField(res.data)
                }
            }).catch((err) => { return () => fnAbort.abort() }) //do nothing, let it go back to login
            await fnEmailContents.Get({
                campaign_id: campaignId,
                limit: "100",
                order: "field_name_display",
                is_active: 1
            }).then((res) => {
                if (!isEmptyValue(res.data)) {
                    reset({
                        ...initialEmailContent,
                        campaign_id: res.data.campaign_id || "",
                        subject: res.data[0].subject || "",
                        content: res.data[0].content || "",
                    }, { keepErrors: false })
                    setEmailId(res.data[0].id)
                }
            }).catch((err) => { return () => fnAbort.abort() })
            setIsLoading(false)
        }
        fetchData()
    }, [step])

    const handleInputField = e => {
        if (!isEmptyValue(quillRef.current.getEditorContents())) {
            let CurrentPosition = quillRef.current.getEditorSelection().index
            quillRef.current.editor.insertText(CurrentPosition, `<<${e.target.value}>>`)
        }
    }

    const onSubmit = async (data, e) => {
        e.preventDefault()

        await setProcess(true)
        await fnEmailContents.Update(emailId, data).then((res) => {
            if (res.success) {
                setAlert(1)
                setProcess(false)
            } else {
                setAlert(2)
                setProcess(false)
            }
        }).catch((err) => { return })
    }

    return (
        <>
            {isLoading ? (
                <Modal.Body>
                    <Spinner animation="border" size="sm" className="mr-1" />
                    Loading data...
                            </Modal.Body>
            ) : (
                    <>
                        <Form onSubmit={handleSubmit(onSubmit)}>
                            <Modal.Body>
                                {
                                    alert && handleAlert(alert)
                                }
                                <Row>
                                    <Col>
                                        <Form.Group className="mb-3">
                                            <Form.Label>Subject</Form.Label>
                                            <Form.Control
                                                type="text"
                                                size="sm"
                                                isInvalid={!!errors.subject}
                                                {...register("subject")}
                                            />
                                            <Form.Control.Feedback type="invalid">{errors.subject ?.message}</Form.Control.Feedback>
                                        </Form.Group>
                                        <Form.Group className="mb-3">
                                            <Form.Label>Content</Form.Label>
                                            <EditorToolbar toolbarId={'t1'} />
                                            <Controller
                                                name={"content"}
                                                control={control}
                                                render={({ field: { value, onChange } }) => {
                                                    return (
                                                        <ReactQuill
                                                            ref={quillRef}
                                                            theme="snow"
                                                            value={value}
                                                            onChange={onChange}
                                                            modules={modules('t1')}
                                                            formats={formats}
                                                        />
                                                    )
                                                }}
                                            />
                                        </Form.Group>
                                        <Form.Text className={classnames("text-danger", {
                                            "d-none": !errors.content
                                        })}>{errors.content ?.message}</Form.Text>
                                    </Col>
                                    {/* <Col md="auto">Variable width content</Col> */}
                                    <Col xs lg="4">
                                        <Form.Group className="mb-3" >
                                            <Form.Label>Field Name</Form.Label>
                                            <select className="form-control" size="20" onChange={handleInputField}>
                                                {field && field.map(item => (
                                                    <option key={item.id} value={item.field_name}>
                                                        {item.field_display_name}
                                                    </option>
                                                ))}
                                            </select>
                                        </Form.Group>
                                    </Col>
                                </Row>
                            </Modal.Body>
                            <Modal.Footer>
                                <Button type="submit" variant="primary">{process ? <Spinner animation="border" size="sm" className="mr-1" /> : 'Update'}</Button>
                            </Modal.Footer>
                        </Form>
                    </>
                )}
        </>
    )
}

const NavTab = ({ setStep, step }) => {
    return (
        <Nav variant="tabs" defaultActiveKey={`link-${step}`}>
            <Nav.Item>
                <Nav.Link eventKey="link-1" onClick={() => setStep(1)}>Campaign</Nav.Link>
            </Nav.Item>
            <Nav.Item>
                <Nav.Link eventKey="link-2" onClick={() => setStep(2)}>Campain Email</Nav.Link>
            </Nav.Item>
        </Nav>
    )

}

const initialCampaign = {
    name: "",
    start_date: new Date(),
    end_date: new Date()
}

const validationSchemaCampaign = yupResolver(yup.object().shape({
    name: yup.string()
        .required("This field is required."),
    start_date: yup.date().nullable()
        .required("This field is required."),
    end_date: yup.date().nullable()
        .required("This field is required."),
    // is_active: yup.string().oneOf(["1"], "This checkbox is required.")
}))

const initialEmailContent = {
    campaign_id: "",
    subject: "",
    content: "",
    is_active: 1
}

const validationSchemaEmailContent = yupResolver(yup.object().shape({
    subject: yup.string()
        .required("This field is required."),
    content: yup.string()
        .required("This field is required.")
}))