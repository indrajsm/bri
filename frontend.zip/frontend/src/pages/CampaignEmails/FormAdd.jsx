import React, { useEffect, useState, useCallback, useRef } from 'react'
import { Button, Form, Modal, Spinner, Row, Col } from 'react-bootstrap'
import { useForm, Controller } from 'react-hook-form'
import DatePicker from "react-datepicker";
import classnames from 'classnames'
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from "yup";
import 'react-quill/dist/quill.snow.css';
import ReactQuill from 'react-quill';
import { generalService } from '../../utils/services';
import { useCustomerFields, useEmailContents, useCampaigns } from '../../utils/functions';
import { EditorToolbar, modules, formats } from '../../components';
import '../../public/assets/styles/editor.css'

const { formatDateTime, isEmptyValue } = generalService

export const FormAdd = ({ modalChange, notifChange, dataChange }) => {
    const [campaignId, setCampaignId] = useState('')
    const [step, setStep] = useState(1)

    const handleModalClose = useCallback(() => {
        modalChange({
            show: false,
            campaignId: ''
        })
    }, [modalChange])

    return (
        <>
            {step === 1 &&
                <FormCampaign setStep={setStep} setCampaignId={setCampaignId} dataChange={dataChange} notifChange={notifChange} />
            }
            {step === 2 &&
                <FormCampaignContent step={step} campaignId={campaignId} handleModalClose={handleModalClose} />
            }
        </>
    )
}

const FormCampaign = ({ setStep, setCampaignId, dataChange, notifChange }) => {
    const { Create } = useCampaigns()

    const { handleSubmit, formState: { errors }, register, control, reset, clearErrors, setValue } = useForm({
        defaultValues: initialCampaign,
        resolver: validationSchemaCampaign
    })
    const [process, setProcess] = useState(false)
    const [selectedStartDate, setSelectedStartDate] = useState(new Date())

    // add campaign
    const onSubmit = async (data) => {
        await setProcess(true)
        const body = {
            name: data.name,
            start_date: formatDateTime(data.start_date),
            end_date: formatDateTime(data.end_date),
            media_id: 2
        }
        await Create(body).then(async (res) => {
            if (res.success) {
                setStep(2)
                setCampaignId(res.data.id)
                notifChange({
                    title: "Success",
                    message: "Data has been added.",
                    show: true,
                    type: "success"
                })
                dataChange()
            } else {
                notifChange({
                    title: "Error",
                    message: "Failed to add data.",
                    show: true,
                    type: "error"
                })
            }
        }).catch((err) => { return })
    }

    return (
        <>
            <Form onSubmit={handleSubmit(onSubmit)}>
                <Modal.Body>
                    <Form.Group className="mb-3">
                        <Form.Label>Campaign Names</Form.Label>
                        <Form.Control type="text" placeholder="Campaign Name" {...register("name")} isInvalid={!!errors.name} />
                        <Form.Control.Feedback type="invalid">{errors.name ?.message}</Form.Control.Feedback>
                    </Form.Group>
                    <Row>
                        <Form.Group className="col-md-6">
                            <Form.Label>Start Campaign</Form.Label>
                            <Controller
                                name={"start_date"}
                                control={control}
                                render={({ field: { value, onChange } }) => {
                                    return (
                                        <DatePicker
                                            className="form-control form-control-sm"
                                            dateFormat="yyyy-MM-dd HH:mm"
                                            showTimeInput
                                            disabledKeyboardNavigation
                                            selected={value}
                                            onChange={(date) => {
                                                onChange(date)
                                                formatDateTime(date) === false ? setSelectedStartDate(new Date()) : setSelectedStartDate(date)
                                                setValue('end_date', date)
                                            }}
                                            highlightDates={[new Date(), new Date()]}
                                            minDate={new Date()}
                                        />
                                    )
                                }}
                            />
                            <Form.Text className={classnames("text-danger", {
                                "d-none": !errors.start_date
                            })}>{errors.start_date ?.message}</Form.Text>
                        </Form.Group>
                        <Form.Group className="col-md-6">
                            <Form.Label>End Campaign</Form.Label>
                            <Controller
                                name={"end_date"}
                                control={control}
                                render={({ field: { value, onChange } }) => {
                                    return (
                                        <DatePicker
                                            className="form-control form-control-sm"
                                            dateFormat="yyyy-MM-dd HH:mm"
                                            showTimeInput
                                            disabledKeyboardNavigation
                                            selected={value}
                                            onChange={onChange}
                                            highlightDates={[new Date(), new Date()]}
                                            minDate={selectedStartDate}
                                        />
                                    )
                                }}
                            />
                            <Form.Text className={classnames("text-danger", {
                                "d-none": !errors.end_date
                            })}>{errors.end_date ?.message}</Form.Text>
                        </Form.Group>
                    </Row>
                </Modal.Body>
                <Modal.Footer>
                    <Button type="submit" variant="primary">{process ? <Spinner animation="border" size="sm" className="mr-1" /> : 'Next'}</Button>
                </Modal.Footer>
            </Form>
        </>
    )
}

const FormCampaignContent = ({ step, campaignId, handleModalClose }) => {
    const { control, register, reset, handleSubmit, setValue, formState: { errors } } = useForm({
        defaultValues: initialEmailContent,
        resolver: validationSchemaEmailContent
    })
    const [field, setField] = useState({})
    const { Get } = useCustomerFields()
    const { Create } = useEmailContents()
    const [isLoading, setIsLoading] = useState(true)
    const [process, setProcess] = useState(false)
    const quillRef = useRef();

    useEffect(() => {
        const fnAbort = new AbortController()
        const fetchData = async () => {
            await Get({
                limit: "100",
                order: "field_name_display",
                is_active: 1
            }).then((res) => {
                if (!isEmptyValue(res.data)) {
                    setField(res.data)
                }
            }).catch((err) => { return () => fnAbort.abort() }) //do nothing, let it go back to login
            setIsLoading(false)
        }
        fetchData()
    }, [step])

    const handleInputField = e => {
        if (!isEmptyValue(quillRef.current.getEditorContents())) {
            let CurrentPosition = quillRef.current.getEditorSelection().index
            quillRef.current.editor.insertText(CurrentPosition, `<<${e.target.value}>>`)
        }
    }


    const onSubmit = async (data, e) => {
        e.preventDefault()

        await setProcess(true)
        await Create({ ...data, campaign_id: campaignId }).then((res) => {
            if (res.success) {
                handleModalClose()
            }
        }).catch((err) => { return })
    }

    return (
        <>
            {isLoading ? (
                <Modal.Body>
                    <Spinner animation="border" size="sm" className="mr-1" />
                    Loading data...
                            </Modal.Body>
            ) : (
                    <>
                        <Form onSubmit={handleSubmit(onSubmit)}>
                            <Modal.Body>
                                <Row>
                                    <Col>
                                        <Form.Group className="mb-3">
                                            <Form.Label>Subject</Form.Label>
                                            <Form.Control
                                                type="text"
                                                size="sm"
                                                isInvalid={!!errors.subject}
                                                {...register("subject")}
                                            />
                                            <Form.Control.Feedback type="invalid">{errors.subject ?.message}</Form.Control.Feedback>
                                        </Form.Group>
                                        <Form.Group className="mb-3">
                                            <Form.Label>Content</Form.Label>
                                            <EditorToolbar toolbarId={'t1'} />
                                            <Controller
                                                name={"content"}
                                                control={control}
                                                render={({ field: { value, onChange } }) => {
                                                    return (
                                                        <ReactQuill
                                                            ref={quillRef}
                                                            theme="snow"
                                                            value={value}
                                                            onChange={onChange}
                                                            modules={modules('t1')}
                                                            formats={formats}
                                                        />
                                                    )
                                                }}
                                            />
                                        </Form.Group>
                                        <Form.Text className={classnames("text-danger", {
                                            "d-none": !errors.content
                                        })}>{errors.content ?.message}</Form.Text>
                                    </Col>
                                    {/* <Col md="auto">Variable width content</Col> */}
                                    <Col xs lg="4">
                                        <Form.Group className="mb-3" >
                                            <Form.Label>Field Name</Form.Label>
                                            <select className="form-control" size="20" onChange={handleInputField}>
                                                {!isEmptyValue(field) > 0 && field.map(item => (
                                                    <option key={item.id} value={item.field_name}>
                                                        {item.field_display_name}
                                                    </option>
                                                ))}
                                            </select>
                                        </Form.Group>
                                    </Col>
                                </Row>
                            </Modal.Body>
                            <Modal.Footer>
                                <Button type="submit" variant="primary">{process ? <Spinner animation="border" size="sm" className="mr-1" /> : 'Next'}</Button>
                            </Modal.Footer>
                        </Form>
                    </>
                )}
        </>
    )
}

const initialCampaign = {
    name: "",
    start_date: new Date(),
    end_date: new Date()
}

const validationSchemaCampaign = yupResolver(yup.object().shape({
    name: yup.string()
        .required("This field is required."),
    start_date: yup.date().nullable()
        .required("This field is required."),
    end_date: yup.date().nullable()
        .required("This field is required."),
    // is_active: yup.string().oneOf(["1"], "This checkbox is required.")
}))


const initialEmailContent = {
    campaign_id: "",
    subject: "",
    content: "",
    is_active: 1
}

const validationSchemaEmailContent = yupResolver(yup.object().shape({
    subject: yup.string()
        .required("This field is required."),
    content: yup.string()
        .required("This field is required.")
}))