import { Button, Form, Modal, Spinner, Table } from 'react-bootstrap'
import React, { useEffect, useState, useContext } from 'react'
import { Link } from 'react-router-dom'
import DatePicker from "react-datepicker";
import _ from 'lodash'
import { FormAdd } from './FormAdd';
import { FormDetail } from './FormDetail';
import { Pagination, Notification } from './../../components'
import { generalService } from '../../utils/services';
import { useCampaigns } from './../../utils/functions'
import { Rollback } from '../CampaignCalls/Rollback';
import { AuthContext } from '../../utils/context';

const { formatDate } = generalService

export const CampaignEmails = (props) => {
    const { GetEmail } = useCampaigns()
    const { userLevelId } = useContext(AuthContext)
    const [isLoading, setIsLoading] = useState(true)
    const [notif, setNotif] = useState(false)
    const [modalAdd, setModalAdd] = useState(initialModal)
    const [modalDetail, setModalDetail] = useState(initialModal)
    const [modalRollback, setModalRollback] = useState(initialModal)
    const [tableData, setTableData] = useState({})
    const { Error, Success, Warning } = Notification
    const [disableDate, setDisableDate] = useState(false)
    const [formFilter, setFormFilter] = useState({
        start_date_list: formatDate(),
        end_date_list: formatDate(),
        name: "",
    })
    const [currentFilter, setCurrentFilter] = useState({
        page: 1,
        ...formFilter
    })

    const handleModalAdd = () => {
        setModalAdd({
            ...modalAdd,
            show: !modalAdd.show,
        })
    }

    const handleModalDetail = (id) => {
        setModalDetail({
            ...modalDetail,
            show: !modalDetail.show,
            dataId: id
        })
    }

    const handleModalRollback = (id, name) => {
        setModalRollback({
            ...modalRollback,
            show: !modalRollback.show,
            dataId: id,
            campaigName: name
        })
    }

    const handleChangeFormFilter = (key, val) => {
        if (['start_date_list', 'end_date_list'].includes(key)) {
            val = formatDate(val)
        }
        if (key === 'disable_date') {
            val ? setDisableDate(true) : setDisableDate(false)
        }
        setFormFilter({ ...formFilter, [key]: val })
    }

    const handleSubmitFormFilter = async (e) => {
        e.preventDefault()
        await setIsLoading(true)
        setCurrentFilter({
            page: 1,
            ...formFilter
        })
    }

    const handleModalClose = async () => {
        await GetEmail()
        setModalAdd(initialModal)
        setModalDetail(initialModal)
        setModalRollback(initialModal)
    }

    useEffect(() => {
        const fnAbort = new AbortController()
        const fetchData = async () => {
            await GetEmail(currentFilter).then((res) => {
                setTableData(res)
                setIsLoading(false)
            }).catch((err) => { return () => fnAbort.abort() }) //do nothing, let it go back to login
        }

        if (isLoading) fetchData()
        return () => fnAbort.abort()
    }, [isLoading, currentFilter])

    return (
        <>
            <h1 className="mt-4">Campaign Email</h1>
            <ol className="breadcrumb mb-4">
                <li className="breadcrumb-item active">Campaign Email</li>
            </ol>
            {notif.show && notif.type === 'error' && <Error
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            {notif.show && notif.type === 'success' && <Success
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            {notif.show && notif.type === 'warning' && <Warning
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            <div className="card mb-4">
                <div className="card-header">
                    <i className="fas fa-table mr-1"></i> Filter Data
                </div>
                <div className="card-body">
                    <form onSubmit={handleSubmitFormFilter}>

                        <div className="form-row">
                            <Form.Group className="col-md-2" controlId="DisableDate">
                                <Form.Label>Disable Date</Form.Label>
                                <br />
                                <span className="btn btn-sm btn-outline-dark">
                                    <Form.Check type="checkbox" name="disable_date" className="text-center" onClick={e => handleChangeFormFilter('disable_date', e.target.checked)} />
                                </span>
                            </Form.Group>
                            <Form.Group className="col-md-2" controlId="StartDate">
                                <Form.Label>Start Date</Form.Label>
                                <DatePicker
                                    selected={new Date(formFilter.start_date_list)}
                                    dateFormat="yyyy-MM-dd"
                                    className="form-control"
                                    placeholderText="YYYY-MM-DD"
                                    name="start_date"
                                    showMonthDropdown
                                    showYearDropdown
                                    onChange={date => handleChangeFormFilter("start_date_list", date)}
                                    disabled={disableDate}
                                />
                            </Form.Group>

                            <Form.Group className="col-md-2" controlId="EndDate">
                                <Form.Label>End Date</Form.Label>
                                <DatePicker
                                    selected={new Date(formFilter.end_date_list) >= new Date(formFilter.start_date_list) ? new Date(formFilter.end_date_list) : new Date(formFilter.start_date_list)}
                                    dateFormat="yyyy-MM-dd"
                                    className="form-control"
                                    placeholderText="YYYY-MM-DD"
                                    name="end_date"
                                    minDate={new Date(formFilter.start_date_list)}
                                    // minDate={new Date()}
                                    showMonthDropdown
                                    showYearDropdown
                                    onChange={date => handleChangeFormFilter("end_date_list", date)}
                                    disabled={disableDate}
                                />
                            </Form.Group>
                            <div className="form-group col-md-2">
                                <label htmlFor="inputState">Name</label>
                                <input type="text" id="inputState" className="form-control" onChange={e => handleChangeFormFilter("name", e.target.value)} />
                            </div>
                        </div>
                        <div className="form-row">
                        </div>
                        <button type="submit" className="btn btn-primary">Search</button>
                    </form>
                </div>
            </div>
            <div className="card mb-4">
                <div className="card-body">
                    {/* <ExportToExcel rawData={exportData} fileName="user-data" />&nbsp; */}
                    {(userLevelId == 2 || userLevelId == 5) &&
                        <Button variant="outline-primary" onClick={handleModalAdd}>Add Campaign</Button>
                    }
                    <hr />
                    <div className="table-responsive">
                        <Table striped hover responsive width="100%" cellSpacing="0" cellPadding="0">
                            <thead className="thead-dark">
                                <tr className="text-center">
                                    <th>No.</th>
                                    <th>Name</th>
                                    <th>Start Date</th>
                                    <th>End Date</th>
                                    <th>Total Recepients</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr className="text-center">
                                    <th>No.</th>
                                    <th>Name</th>
                                    <th>Start Date</th>
                                    <th>End Date</th>
                                    <th>Total Recepients</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </tfoot>
                            <tbody>
                                {isLoading ? (
                                    <tr>
                                        <td colSpan="9" className="text-center">
                                            <Spinner animation="border" size="sm" className="mr-1" />
                                            Loading data...
                                        </td>
                                    </tr>
                                ) : (
                                        tableData.total_data > 0 ? (
                                            tableData.data.map((item, i) => (
                                                <tr key={item.id} className="text-center">
                                                    <td>{tableData.paging.index[i]}</td>
                                                    <td>{item.name}</td>
                                                    <td>{item.start_date.substring(0, 10)}</td>
                                                    <td>{item.end_date.substring(0, 10)}</td>
                                                    <td>{item.total_receptients}</td>
                                                    <td>{item.is_active_campaign ? 'Active' : 'Inactive'}</td>
                                                    <td >
                                                        {(userLevelId == 2 || userLevelId == 5) &&
                                                            <Button variant="primary" size="sm" className="m-1" data-toggle="modal" onClick={(e) => {
                                                                handleModalDetail(item.id)
                                                            }}>
                                                                <i className="fas fa-edit fa-fw"></i>
                                                            </Button>
                                                        }
                                                        {(userLevelId == 2 || userLevelId == 5) &&
                                                            <Link to={`emails/${item.id}/${item.name}`} variant="warning" size="sm" className="m-1">
                                                                <Button variant="warning" size="sm" className="m-1">
                                                                    <i className="fas fa-envelope fa-fw"></i>
                                                                </Button>
                                                            </Link>
                                                        }
                                                        {(userLevelId == 2 || userLevelId == 5) &&
                                                            <Button variant="danger" size="sm" className="m-1" data-toggle="modal" title="Rollback Campign Call" onClick={(e) => { handleModalRollback(item.id, item.name) }}>
                                                                <i className="fas fa-undo fa-fw"></i>
                                                            </Button>
                                                        }
                                                    </td>
                                                </tr>
                                            ))
                                        ) : (
                                                <>
                                                    <tr>
                                                        <td colSpan="7" className="text-center"><span className="text-danger">No data found</span></td>
                                                    </tr>
                                                </>
                                            )
                                    )}
                            </tbody>
                        </Table>
                    </div>
                    {isLoading === false && !_.isEmpty(tableData) &&
                        <Pagination
                            total={tableData.total_data}
                            limit={tableData.limit}
                            paging={tableData.paging}
                            pageChange={async (pageNumber) => {
                                await setIsLoading(true)
                                setCurrentFilter({
                                    ...currentFilter,
                                    page: pageNumber
                                })
                            }}
                        />
                    }
                </div>
            </div>
            <Modal show={modalAdd.show} onHide={handleModalClose} backdrop="static" size="lg" keyboard={false}>
                <Modal.Header closeButton>
                    <Modal.Title>New Campaign Email</Modal.Title>
                </Modal.Header>
                <FormAdd
                    modalChange={(params) => {
                        setModalAdd({
                            ...modalAdd,
                            ...params
                        })
                    }}
                    notifChange={(params) => {
                        setNotif({
                            ...notif,
                            ...params
                        })
                    }}
                    dataChange={async () => {
                        await setIsLoading(true)
                    }}
                    isLoading={isLoading}
                    setIsLoading={setIsLoading}
                />
            </Modal>
            <Modal show={modalDetail.show} onHide={handleModalClose} backdrop="static" size="lg" keyboard={false}>
                <Modal.Header closeButton>
                    <Modal.Title>Detail Campaign Call</Modal.Title>
                </Modal.Header>
                <FormDetail
                    dataId={modalDetail.dataId}
                    modalChange={(params) => {
                        setModalDetail({
                            ...modalDetail,
                            ...params
                        })
                    }}
                    notifChange={(value) => {
                        setNotif(value)
                    }}
                    dataChange={async () => {
                        await setIsLoading(true)
                    }}
                />
            </Modal>

            <Modal show={modalRollback.show} onHide={handleModalClose} backdrop="static" size="lg" keyboard={false}>
                <Modal.Header closeButton>
                    <Modal.Title>Rollback Campaign {modalRollback.campaigName}</Modal.Title>
                </Modal.Header>
                <Rollback
                    modalChange={(params) => {
                        setModalRollback({
                            ...modalRollback,
                            ...params
                        })
                    }}
                    notifChange={(value) => {
                        setNotif(value)
                    }}
                    dataChange={() => {
                        setIsLoading(true)
                    }}
                    campaignId={modalRollback.dataId}
                />
            </Modal>
        </>
    )
}

const initialNotif = {
    title: "",
    message: "",
    show: false,
    type: null
}

const initialModal = {
    show: false,
    campaignId: ""
}