import { useState, useEffect, useContext } from 'react'
import { Button, Form, Modal, Spinner, Table, Row } from 'react-bootstrap'
import _ from 'lodash'
import DatePicker from 'react-datepicker'
import { generalService, cookieService } from './../../utils/services'
import { useCalls, useCampaigns, useUsers } from './../../utils/functions'
import { Pagination, Notification, CustomSelect } from './../../components'
import { FormAdd } from './FormAdd'
import { FormDetail } from './FormDetail'

const { isEmptyValue, formatDate } = generalService

export const QualityAssuranceCalls = (props) => {
    const fnCalls = useCalls()
    const fnCampaigns = useCampaigns()
    const fnUsers = useUsers()
    const { Error, Success, Warning } = Notification

    const [loading, setLoading] = useState(true)
    const [notif, setNotif] = useState(initialNotif)
    const [tableData, setTableData] = useState({})
    const [modalAdd, setModalAdd] = useState(initialModal)
    const [modalDetail, setModalDetail] = useState(initialModal)
    const [formFilter, setFormFilter] = useState({
        user_id: "",
        campaign_id: "",
        start: formatDate(),
        end: formatDate(),
        disable_date: false
    })
    const [currentFilter, setCurrentFilter] = useState({
        page: 1,
        ...formFilter
    })
    const [optionAgent, setOptionAgent] = useState([{
        value: "",
        label: "Choose..."
    }])
    const [optionCampaign, setOptionCampaign] = useState([{
        value: "",
        label: "Choose..."
    }])

    useEffect(() => {
        const fetchData = async () => {
            await fnCalls.GetQA(currentFilter).then((res) => {
                setTableData(res)
                setLoading(false)
            }).catch((err) => { return }) //do nothing, let it go back to login
        }

        if (loading) fetchData()
        return () => setLoading(false)
    }, [loading])

    useEffect(() => {
        const fetchData = async () => {
            await fnUsers.Get({
                limit: 100,
                order: "username",
                is_active: 1
            }).then((res) => {
                if (!isEmptyValue(res.data)) {
                    let mapOptionAgent = res.data.map((row) => {
                        return { value: row.id, label: row.username }
                    })

                    setOptionAgent([
                        ...optionAgent,
                        ...mapOptionAgent
                    ])
                }
            }).catch((err) => { return }) //do nothing, let it go back to login
        }

        fetchData()
        return () => setOptionAgent([{
            value: "",
            label: "Choose..."
        }])
    }, [])

    useEffect(() => {
        const fetchData = async () => {
            await fnCampaigns.Get({
                limit: 100,
                order: "name"
            }).then((res) => {
                if (!isEmptyValue(res.data)){
                    let mapOptionCampaign = res.data.map((row) => {
                        return { value: row.id, label: row.name }
                    })

                    setOptionCampaign([
                        ...optionCampaign,
                        ...mapOptionCampaign
                    ])
                }
            }).catch((err) => { return }) //do nothing, let it go back to login
        }

        fetchData()
        return () => setOptionCampaign([{
            value: "",
            label: "Choose..."
        }])
    }, [])

    const handleChangeFormFilter = (key, val) => {
        if (key === 'start' && new Date(val) > new Date(formFilter.end)) {
            setFormFilter({
                ...formFilter,
                start: val,
                end: val
            })
        } else {
            setFormFilter({ ...formFilter, [key]: val })
        }
    }

    const handleSubmitFormFilter = (e) => {
        e.preventDefault()

        setCurrentFilter({
            ...currentFilter,
            ...formFilter,
            page: 1
        })
        setLoading(true)
    }

    const handleModalClose = () => {
        setModalAdd(initialModal)
        setModalDetail(initialModal)
    }

    const handleModalAdd = ({dataFile, dataAssist}) => {
        setModalAdd({
            ...modalAdd,
            show: !modalAdd.show,
            dataFile: dataFile,
            dataAssist: dataAssist
        })
    }

    const handleModalDetail = ({dataFile, dataId}) => {
        setModalDetail({
            ...modalDetail,
            show: !modalDetail.show,
            dataFile: dataFile,
            dataId: dataId
        })
    }

    return (
        <>
            <h1 className="mt-4">Quality Assurance Calls</h1>
            <ol className="breadcrumb mb-4">
                <li className="breadcrumb-item">Quality Assurance</li>
                <li className="breadcrumb-item active">Calls</li>
            </ol>
            {notif.show && notif.type === 'error' && <Error
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            {notif.show && notif.type === 'success' && <Success
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            {notif.show && notif.type === 'warning' && <Warning
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            <div className="card mb-4">
                <div className="card-header">
                    <i className="fas fa-table mr-1"></i> Filter Data
                </div>
                <div className="card-body">
                    <form onSubmit={handleSubmitFormFilter}>
                        <div className="form-row">
                            <Form.Group className="col-md-2" controlId="DisableDate">
                                <Form.Label>Disable Date</Form.Label>
                                <br />
                                <Button variant="outline-info" onClick={() => handleChangeFormFilter("disable_date", !formFilter.disable_date)}>
                                    <i className={`far ${formFilter.disable_date ? "fa-check-square" : "fa-square"}`} />
                                </Button>
                            </Form.Group>
                            <Form.Group className="col-md-2" controlId="StartDate">
                                <Form.Label>From Date</Form.Label>
                                <DatePicker
                                    className="form-control"
                                    dateFormat="yyyy-MM-dd"
                                    selected={new Date(formFilter.start)}
                                    disabledKeyboardNavigation
                                    onChange={(date) => handleChangeFormFilter("start", formatDate(date) === false ? formatDate() : formatDate(date))}
                                    highlightDates={[new Date(), new Date()]}
                                    disabled={formFilter.disable_date}
                                />
                            </Form.Group>
                            <Form.Group className="col-md-2" controlId="EndDate">
                                <Form.Label>To Date</Form.Label>
                                <DatePicker
                                    className="form-control"
                                    dateFormat="yyyy-MM-dd"
                                    disabledKeyboardNavigation
                                    selected={new Date(formFilter.end)}
                                    onChange={(date) => handleChangeFormFilter("end", formatDate(date) === false ? formFilter.start : formatDate(date))}
                                    highlightDates={[new Date(), new Date()]}
                                    minDate={new Date(formFilter.start)}
                                    disabled={formFilter.disable_date}
                                />
                            </Form.Group>
                            <Form.Group className="col-md-2" controlId="Agent">
                                <Form.Label>Agent</Form.Label>
                                <CustomSelect.SelectBox
                                    optionSelect={optionAgent}
                                    onChangeValue={(value) => handleChangeFormFilter("user_id", value)}
                                    value={formFilter.user_id}
                                />
                            </Form.Group>
                            <Form.Group className="col-md-2" controlId="CampaignName">
                                <Form.Label>Campaign Name</Form.Label>
                                <CustomSelect.SelectBox
                                    optionSelect={optionCampaign}
                                    onChangeValue={(value) => handleChangeFormFilter("campaign_id", value)}
                                    value={formFilter.campaign_id}
                                />
                            </Form.Group>
                        </div>
                        <div className="form-row">
                            <Form.Group className="col-md-12 mb-0">
                                <Button type="submit" variant="primary">Search</Button>
                            </Form.Group>
                        </div>
                    </form>
                </div>
            </div>
            <div className="card mb-4">
                <div className="card-body">
                    <Table striped hover responsive width="100%" cellSpacing="0" cellPadding="0">
                        <thead className="thead-dark">
                            <tr>
                                <th width="">No.</th>
                                <th width="">Call Date</th>
                                <th width="">Campaign</th>
                                <th width="">Customer Name</th>
                                <th width="">Agent</th>
                                <th width="">Call Duration</th>
                                <th width="">Phone Number</th>
                                <th width="" className="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {loading &&
                                <tr>
                                    <td colSpan="8" className="text-center">
                                        <Spinner animation="border" size="sm" className="mr-1" />
                                        Loading data...
                                    </td>
                                </tr>
                            }
                            {!loading && isEmptyValue(tableData.data) &&
                                <tr>
                                    <td colSpan="8" className="text-center">
                                        <span className="text-danger">No data found</span>
                                    </td>
                                </tr>
                            }
                            {!loading && !isEmptyValue(tableData.data) &&
                                tableData.data.map((row, i) => (
                                    <tr key={ row.id }>
                                        <td>{ tableData.paging.index[i] }</td>
                                        <td>{ row.call_date }</td>
                                        <td>{ row.campaign_name }</td>
                                        <td>{ row.customer_name }</td>
                                        <td>{ row.agent }</td>
                                        <td>{ row.call_duration }</td>
                                        <td>{ row.phone_number }</td>
                                        <td className="text-center">
                                            {isEmptyValue(row.quality_assurance_user_id) && cookieService.Get('user_level_id') === '3' &&
                                                <Button variant="info" size="sm" className="m-1" title="QA Observation" onClick={(e) => {
                                                    handleModalAdd({
                                                        dataFile: {
                                                            filedate: row.filedate,
                                                            filename: row.filename
                                                        },
                                                        dataAssist: {
                                                            call_id: row.id,
                                                            call_date: row.call_date,
                                                            call_duration: row.call_duration,
                                                            customer_name: row.customer_name,
                                                            user_id: row.user_id,
                                                            agent: row.agent
                                                        }
                                                    })
                                                }}>
                                                    Add QA
                                                </Button>
                                            || !isEmptyValue(row.quality_assurance_user_id) &&
                                                <Button variant="warning" size="sm" className="m-1" title="QA Observation" onClick={(e) => {
                                                    handleModalDetail({
                                                        dataFile: {
                                                            filedate: row.filedate,
                                                            filename: row.filename
                                                        },
                                                        dataId: row.quality_assurance_user_id
                                                    })
                                                }}>
                                                    View QA
                                                </Button>
                                            }
                                        </td>
                                    </tr>
                                ))
                            }
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>No.</th>
                                <th>Call Date</th>
                                <th>Campaign</th>
                                <th>Customer Name</th>
                                <th>Agent</th>
                                <th>Call Duration</th>
                                <th>Phone Number</th>
                                <th>Action</th>
                            </tr>
                        </tfoot>
                    </Table>

                    {!loading && !isEmptyValue(tableData.paging) &&
                         <Pagination
                            total={tableData.total_data}
                            limit={tableData.limit}
                            paging={tableData.paging}
                            pageChange={(page) => {
                                setCurrentFilter({
                                    ...currentFilter,
                                    page: page
                                })
                                setLoading(true)
                            }}
                        />
                    }
                </div>
            </div>

            <Modal show={modalAdd.show} onHide={handleModalClose} backdrop="static" keyboard={false} size="lg">
                <FormAdd
                    modalChange={() => {
                        handleModalClose()
                    }}
                    notifChange={(params) => {
                        setNotif({
                            ...notif,
                            ...params
                        })
                    }}
                    dataChange={() => {
                        setLoading(true)
                    }}
                    dataFile={modalAdd.dataFile}
                    dataAssist={modalAdd.dataAssist}
                />
            </Modal>

            <Modal show={modalDetail.show} onHide={handleModalClose} backdrop="static" keyboard={false} size="lg">
                <FormDetail
                    modalChange={() => {
                        handleModalClose()
                    }}
                    notifChange={(params) => {
                        setNotif({
                            ...notif,
                            ...params
                        })
                    }}
                    dataChange={() => {
                        setLoading(true)
                    }}
                    dataFile={modalDetail.dataFile}
                    dataId={modalDetail.dataId}
                />
            </Modal>
        </>
    )
}

const initialNotif = {
    title: "",
    message: "",
    show: false,
    type: null
}

const initialModal = {
    show: false,
    type: null,
    dataId: null,
    dataFile: null,
    dataAssist: null
}