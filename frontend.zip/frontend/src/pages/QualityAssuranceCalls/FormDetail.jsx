import { useState, useEffect } from 'react'
import { Button, Form, Modal, Spinner, Row, Table } from 'react-bootstrap'
import _ from 'lodash'
import { saveAs } from 'file-saver'
import { generalService, cookieService } from './../../utils/services'
import { useExports, useQualityAssuranceDetails, useQualityAssuranceUsers, useVoices } from './../../utils/functions'
import { CustomPlayer, Notification } from './../../components'

const { isEmptyValue, sleep } = generalService

export const FormDetail = ({ modalChange, notifChange, dataChange, dataFile, dataId }) => {
    const fnExports = useExports()
    const fnQualityAssuranceUsers = useQualityAssuranceUsers()
    const fnVoices = useVoices()
    const [currentData, setCurrentData] = useState({})
    const [loadingAudio, setLoadingAudio] = useState(true)
    const [audioUrl, setAudioUrl] = useState(null)
    const [exporting, setExporting] = useState(false)
    const [exportError, setExportError] = useState(false)

    useEffect(() => {
        const fetchData = async () => {
            const { filename, filedate } = dataFile

            await fnVoices.Get({ filename, filedate }).then((res) => {
                if (!isEmptyValue(res.data)) {
                    setAudioUrl(res.data.url)
                    setLoadingAudio(false)
                }
            }).catch((err) => { return }) //do nothing, let it go back to login
        }

        if (!isEmptyValue(dataFile) && _.isObject(dataFile)) fetchData()
        return () => setLoadingAudio(false)
    }, [dataFile])

    useEffect(() => {
        const fetchData = async () => {
            await fnQualityAssuranceUsers.Get({id: dataId}).then((res) => {
                if (!isEmptyValue(res.data)) {
                    setCurrentData({
                        quality_assurance_name: res.data.quality_assurance_name || "",
                        quality_assurance_date: res.data.quality_assurance_date || "",
                        observer_name: res.data.observer_name || "",
                        customer_name: res.data.customer_name || "",
                        agent: res.data.agent || "",
                        call_date: res.data.call_date || "",
                        call_duration: res.data.call_duration || "",
                        period_name: res.data.period_name || "",
                        notes: res.data.notes || ""
                    })
                }
            }).catch((err) => { return }) //do nothing, let it go back to login
        }

        if (!isEmptyValue(dataId)) fetchData()
        return () => setCurrentData({})
    }, [dataId])

    const handleExport = async () => {
        await fnExports.ReportQualityAssuranceDetail({
            quality_assurance_user_id: dataId || ""
        }).then(async (res) => {
            await sleep(5000)
            setExporting(false)

            if (res.success) {
                return saveAs(res.data.url, res.data.filename)
            }

            return setExportError(true)
        }).catch((err) => { return }) //do nothing, let it go back to login
    }

    return (
        <>
            <Modal.Header closeButton>
                <Modal.Title>QA Observation</Modal.Title>
            </Modal.Header>
            <Modal.Body className="py-1">
                {exportError && <Notification.Error
                    message="An error occured while exporting, please try again."
                    show={true}
                    showChange={() => { setExportError(false) }}
                />}
                <Row>
                    <Form.Group className="col-md-3">
                        <Form.Label>Qa Type <span className="text-danger">*</span></Form.Label>
                        <Form.Control
                            type="text"
                            size="sm"
                            value={currentData.quality_assurance_name}
                            readOnly={true}
                        />
                    </Form.Group>
                    <Form.Group className="col-md-3">
                        <Form.Label>QA Date <span className="text-danger">*</span></Form.Label>
                        <Form.Control
                            type="text"
                            size="sm"
                            value={currentData.quality_assurance_date}
                            readOnly={true}
                        />
                    </Form.Group>
                    <Form.Group className="col-md-3">
                        <Form.Label>Period <span className="text-danger">*</span></Form.Label>
                        <Form.Control
                            type="text"
                            size="sm"
                            value={currentData.period_name}
                            readOnly={true}
                        />
                    </Form.Group>
                </Row>
                <Row className="mb-2">
                    <Form.Group className="col-md-6">
                        <Form.Label>Notes</Form.Label>
                        <Form.Control
                            as="textarea"
                            size="sm"
                            rows={3}
                            value={currentData.notes}
                            readOnly={true}
                        />
                    </Form.Group>
                    <Form.Group className="col-md-6">
                        <Form.Label>Voice Call</Form.Label>
                        <CustomPlayer.Audio url={audioUrl} loading={loadingAudio} size="sm" />
                    </Form.Group>
                    <Form.Group className="col-md-3">
                        <Form.Label>Agent</Form.Label>
                        <Form.Control
                            type="text"
                            size="sm"
                            value={currentData.agent}
                            readOnly={true}
                        />
                    </Form.Group>
                    <Form.Group className="col-md-3">
                        <Form.Label>Call Date</Form.Label>
                        <Form.Control
                            type="text"
                            size="sm"
                            value={currentData.call_date}
                            readOnly={true}
                        />
                    </Form.Group>
                    <Form.Group className="col-md-3">
                        <Form.Label>Customer Name</Form.Label>
                        <Form.Control
                            type="text"
                            size="sm"
                            value={currentData.customer_name}
                            readOnly={true}
                        />
                    </Form.Group>
                    <Form.Group className="col-md-3">
                        <Form.Label>Call Duration</Form.Label>
                        <Form.Control
                            type="text"
                            size="sm"
                            value={currentData.call_duration}
                            readOnly={true}
                        />
                    </Form.Group>
                </Row>
                <TableDataResult
                    qualityAssuranceUserId={dataId}
                />
            </Modal.Body>
            <Modal.Footer>
                {['2','4','5'].includes(cookieService.Get('user_level_id')) &&
                    <Button variant="secondary" onClick={() => {
                        setExporting(true)
                        handleExport()
                    }} disabled={!exporting && !isEmptyValue(dataId) ? false : true}>
                        {exporting && <Spinner animation="border" size="sm" className="mr-1" />} Export
                    </Button>
                }
                <Button variant="light" onClick={modalChange}>Close</Button>
            </Modal.Footer>
        </>
    )
}

const TableDataResult = ({ qualityAssuranceUserId }) => {
    const { Get } = useQualityAssuranceDetails()

    const [loading, setLoading] = useState(true)
    const [tableData, setTableData] = useState({})
    const [totalNilai, setTotalNilai] = useState(0)

    useEffect(() => {
        const fetchData = async () => {
            await Get({
                quality_assurance_user_id: qualityAssuranceUserId,
                limit: "0"
            }).then((res) => {
                setTableData(res)
                setLoading(false)
            }).catch((err) => { return }) //do nothing, let it go back to login
        }

        fetchData()
        return () => setLoading(false)
    }, [qualityAssuranceUserId])

    useEffect(() => {
        const mapData = () => {
            tableData.data.map((row) => {
                return (
                    setTotalNilai(totalNilai => (totalNilai + parseInt(row.result)))
                )
            })
        }

        if (!loading && !isEmptyValue(tableData.data)) mapData()
        return () => setTotalNilai(0)
    }, [loading, tableData])

    return (
        <>
            <Table striped bordered hover responsive width="100%" className="mb-0" size="sm">
                <thead className="thead-dark">
                    <tr>
                        <th width="50%">Aspek</th>
                        <th width="25%">Hasil</th>
                        <th width="25%">Nilai</th>
                    </tr>
                </thead>
                <tbody>
                    {loading &&
                        <tr>
                            <td colSpan="3" className="text-center">
                                <Spinner animation="border" size="sm" className="mr-1" />
                                Loading data...
                            </td>
                        </tr>
                    }
                    {!loading && isEmptyValue(tableData.data) &&
                        <tr>
                            <td colSpan="3" className="text-center">
                                <span className="text-danger">No data found</span>
                            </td>
                        </tr>
                    }
                    {!loading && !isEmptyValue(tableData.data) &&
                        tableData.data.map((row, i) => (
                            <tr key={ row.id }>
                                <td key={`aspek-${row.id}`}>{ row.quality_assurance_aspect_name }</td>
                                <td>
                                    <Form.Control
                                        key={`hasil-${row.id}`}
                                        type="text"
                                        size="sm"
                                        readOnly={true}
                                        defaultValue={parseInt(row.result) !== 0 ? "Ya" : "Tidak"}
                                    />
                                </td>
                                <td>
                                    <Form.Control
                                        key={`nilai-${row.id}`}
                                        type="text"
                                        size="sm"
                                        readOnly={true}
                                        defaultValue={row.result}
                                        className="text-right"
                                    />
                                </td>
                            </tr>
                        ))
                    }
                </tbody>
            </Table>
            <div className="d-flex justify-content-between bg-dark text-white font-weight-bold mb-2">
                <span className="p-2">Total Nilai :</span>
                <span className="p-2">{totalNilai}</span>
            </div>
        </>
    )
}