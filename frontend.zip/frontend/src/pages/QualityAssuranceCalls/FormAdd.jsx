import { useState, useEffect, useCallback, useContext } from 'react'
import { Button, Form, Modal, Spinner, Row, Table } from 'react-bootstrap'
import { useForm, Controller } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import _ from 'lodash'
import DatePicker from 'react-datepicker'
import classnames from 'classnames'
import { generalService } from './../../utils/services'
import { usePeriods, useQualityAssurances, useQualityAssuranceAspects, useQualityAssuranceDetails, useQualityAssuranceUsers, useVoices } from './../../utils/functions'
import { CustomPlayer, CustomSelect } from './../../components'

const { isEmptyValue, formatDate } = generalService

export const FormAdd = ({ modalChange, notifChange, dataChange, dataFile, dataAssist }) => {
    const fnPeriods = usePeriods()
    const fnQualityAssurances = useQualityAssurances()
    const fnQualityAssuranceDetails = useQualityAssuranceDetails()
    const fnQualityAssuranceUsers = useQualityAssuranceUsers()
    const fnVoices = useVoices()
    const { handleSubmit, formState: { errors, isSubmitting }, control, register, reset, clearErrors, getValues } = useForm({
        defaultValues: initialData,
        resolver: validationSchema
    })

    const [loading, setLoading] = useState(false)
    const [optionQa, setOptionQa] = useState(initialOption)
    const [optionPeriod, setOptionPeriod] = useState(initialOption)
    const [otherData, setOtherData] = useState({})
    const [dataAspect, setDataAspect] = useState([])
    const [loadingAudio, setLoadingAudio] = useState(true)
    const [audioUrl, setAudioUrl] = useState(null)

    useEffect(() => {
        const fetchData = async () => {
            const { filename, filedate } = dataFile

            await fnVoices.Get({ filename, filedate }).then((res) => {
                if (!isEmptyValue(res.data)) {
                    setAudioUrl(res.data.url)
                    setLoadingAudio(false)
                }
            }).catch((err) => { return }) //do nothing, let it go back to login
        }

        if (!isEmptyValue(dataFile) && _.isObject(dataFile)) fetchData()
        return () => setLoadingAudio(false)
    }, [dataFile])

    useEffect(() => {
        const fetchData = async () => {
            clearErrors()

            if (!isEmptyValue(dataAssist) && _.isObject(dataAssist)) {
                reset({
                    ...initialData,
                    user_id: dataAssist.user_id || "",
                    call_id: dataAssist.call_id || ""
                })
    
                setOtherData(dataAssist)
            }
        }

        fetchData()
        return () => setOtherData({})
    }, [dataAssist])

    useEffect(() => {
        const fetchData = async () => {
            await fnPeriods.Get({
                limit: 100,
                is_active: 1
            }).then((res) => {
                if (!isEmptyValue(res.data)) {
                    let mapOptionPeriod = res.data.map((row) => {
                        return { value: row.id, label: row.name }
                    })

                    setOptionPeriod([
                        ...optionPeriod,
                        ...mapOptionPeriod
                    ])
                }
            }).catch((err) => { return }) //do nothing, let it go back to login

            await fnQualityAssurances.Get({
                limit: 100,
                order: "name",
                is_active: 1
            }).then((res) => {
                if (!isEmptyValue(res.data)) {
                    let mapOptionQa = res.data.map((row) => {
                        return { value: row.id, label: row.name }
                    })

                    setOptionQa([
                        ...optionQa,
                        ...mapOptionQa
                    ])
                }
            }).catch((err) => { return }) //do nothing, let it go back to login
        }

        fetchData()
        return () => {
            setOptionPeriod(initialOption)
            setOptionQa(initialOption)
        }
    }, [])

    const onSubmitForm = async (data, e) => {
        e.preventDefault()

        Object.keys(data).forEach((key) => {
            if (['quality_assurance_date'].indexOf(key) >= 0) {
                data[key] = formatDate(data[key])
            }
        })

        await fnQualityAssuranceUsers.Create(data).then(async (res) => {
            if (res.success) {
                let saveQaDetails = true

                if (!isEmptyValue(dataAspect)) {
                    let dataQaDetails = dataAspect.map((row) => {
                        return {
                            quality_assurance_user_id: String(res.data.id),
                            quality_assurance_aspect_id: String(row.quality_assurance_aspect_id),
                            result: row.result
                        }
                    })
    
                    await fnQualityAssuranceDetails.Create(dataQaDetails).then((resQaDetails) => {
                        saveQaDetails = resQaDetails.success
                    }).catch((err) => { return }) //do nothing, let it go back to login
                }

                if (!saveQaDetails) {
                    notifChange({
                        title: "Warning",
                        message: "QA Observation has been saved without Aspect Data",
                        show: true,
                        type: "warning"
                    })
                } else {
                    notifChange({
                        title: "Success",
                        message: "QA Observation has been saved.",
                        show: true,
                        type: "success"
                    })
                }

                dataChange()
            } else {
                notifChange({
                    title: "Error",
                    message: "Failed to save QA Observation.",
                    show: true,
                    type: "error"
                })
            }
        }).catch((err) => { return }) //do nothing, let it go back to login

        return modalChange()
    }

    return (
        <>
            <Modal.Header closeButton={isSubmitting ? false : true}>
                <Modal.Title>QA Observation</Modal.Title>
            </Modal.Header>
            <Form onSubmit={handleSubmit(onSubmitForm)}>
                <Modal.Body className="py-1">
                    <Row>
                        <Form.Group className="col-md-3">
                            <Form.Label>Qa Type <span className="text-danger">*</span></Form.Label>
                            <Controller
                                name={"quality_assurance_id"}
                                control={control}
                                render={({ field: {value, onChange} }) => {
                                    return (
                                        <CustomSelect.SelectBox
                                            optionSelect={optionQa}
                                            onChangeValue={(value) => {
                                                onChange(value)
                                                setLoading(true)
                                            }}
                                            value={getValues('quality_assurance_id')}
                                            isError={!!errors.quality_assurance_id ? true : false}
                                            isSmall={true}
                                        />
                                    )
                                }}
                            />
                            <Form.Control.Feedback type="invalid">{errors.quality_assurance_id?.message}</Form.Control.Feedback>
                        </Form.Group>
                        <Form.Group className="col-md-3">
                            <Form.Label>QA Date <span className="text-danger">*</span></Form.Label>
                            <Controller
                                name={"quality_assurance_date"}
                                control={control}
                                // value={new Date()}
                                render={({ field: {value, onChange} }) => {
                                    return (
                                        <DatePicker
                                            dateFormat="yyyy-MM-dd"
                                            disabledKeyboardNavigation
                                            selected={value}
                                            onChange={onChange}
                                            highlightDates={[new Date(), new Date()]}
                                            className={classnames("form-control form-control-sm", {
                                                "is-invalid": !!errors.quality_assurance_date
                                            })}
                                        />
                                    )
                                }}
                            />
                            <Form.Text className={classnames("text-danger", {
                                "d-none": !errors.quality_assurance_date
                            })}>{errors.quality_assurance_date?.message}</Form.Text>
                        </Form.Group>
                        <Form.Group className="col-md-3">
                            <Form.Label>Period <span className="text-danger">*</span></Form.Label>
                            <Controller
                                name={"period_id"}
                                control={control}
                                render={({ field: {value, onChange} }) => {
                                    return (
                                        <CustomSelect.SelectBox
                                            optionSelect={optionPeriod}
                                            onChangeValue={(value) => {
                                                onChange(value)
                                            }}
                                            value={getValues('period_id')}
                                            isError={!!errors.period_id ? true : false}
                                            isSmall={true}
                                        />
                                    )
                                }}
                            />
                            <Form.Control.Feedback type="invalid">{errors.period_id?.message}</Form.Control.Feedback>
                        </Form.Group>
                    </Row>
                    <Row className="mb-2">
                        <Form.Group className="col-md-6">
                            <Form.Label>Notes</Form.Label>
                            <Form.Control
                                as="textarea"
                                size="sm"
                                rows={3}
                                isInvalid={!!errors.notes}
                                {...register("notes")}
                            />
                            <Form.Control.Feedback type="invalid">{errors.notes?.message}</Form.Control.Feedback>
                        </Form.Group>
                        <Form.Group className="col-md-6">
                            <Form.Label>Voice Call</Form.Label>
                            <CustomPlayer.Audio url={audioUrl} loading={loadingAudio} size="sm" />
                        </Form.Group>
                        <Form.Group className="col-md-3">
                            <Form.Label>Agent</Form.Label>
                            <Form.Control
                                type="text"
                                size="sm"
                                defaultValue={otherData.agent || ""}
                                disabled={true}
                            />
                        </Form.Group>
                        <Form.Group className="col-md-3">
                            <Form.Label>Call Date</Form.Label>
                            <Form.Control
                                type="text"
                                size="sm"
                                defaultValue={otherData.call_date || ""}
                                disabled={true}
                            />
                        </Form.Group>
                        <Form.Group className="col-md-3">
                            <Form.Label>Customer Name</Form.Label>
                            <Form.Control
                                type="text"
                                size="sm"
                                defaultValue={otherData.customer_name || ""}
                                disabled={true}
                            />
                        </Form.Group>
                        <Form.Group className="col-md-3">
                            <Form.Label>Call Duration</Form.Label>
                            <Form.Control
                                type="text"
                                size="sm"
                                defaultValue={otherData.call_duration || ""}
                                disabled={true}
                            />
                        </Form.Group>
                    </Row>
                    <TableDataAspect
                        loading={loading}
                        loadingChange={() => {
                            setLoading(false)
                        }}
                        dataAspect={dataAspect}
                        dataAspectChange={(params) => {
                            setDataAspect(params)
                        }}
                        qualityAssuranceId={getValues("quality_assurance_id")}
                    />
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="primary" type="submit" disabled={isSubmitting}>
                        {isSubmitting && <Spinner animation="border" size="sm" className="mr-1" />} Save
                    </Button>
                    <Button variant="light" disabled={isSubmitting} onClick={modalChange}>Close</Button>
                </Modal.Footer>
            </Form>
        </>
    )
}

const TableDataAspect = ({ loading, loadingChange, dataAspect, dataAspectChange, qualityAssuranceId }) => {
    const { Get } = useQualityAssuranceAspects()

    const [tableData, setTableData] = useState({})
    const [totalNilai, setTotalNilai] = useState(0)

    useEffect(() => {
        const fetchData = async () => {
            await Get({
                limit: "0",
                is_active: 1,
                quality_assurance_id: qualityAssuranceId
            }).then((res) => {
                setTableData(res)

                if (!isEmptyValue(res.data)) {
                    let mapDataAspect = res.data.map((row) => {
                        return {
                            quality_assurance_aspect_id: String(row.id),
                            result: row.bobot
                        }
                    })

                    dataAspectChange([
                        ...mapDataAspect
                    ])
                }
            }).catch((err) => { return }) //do nothing, let it go back to login
        }

        if (!isEmptyValue(qualityAssuranceId)) {
            fetchData()
            loadingChange(false)
        }
        return () => {
            setTableData({})
            loadingChange(false)
        }
    }, [qualityAssuranceId])

    useEffect(() => {
        const mapData = () => {
            dataAspect.map((row) => {
                return (
                    setTotalNilai(totalNilai => (totalNilai + parseInt(row.result)))
                )
            })
        }

        if (dataAspect.length > 0) mapData()
        return () => setTotalNilai(0)
    }, [dataAspect])

    const handleChangeDataAspect = (id, bobot, hasil) => {
        let nilai = "0"

        if (hasil === "1") {
            nilai = bobot
        }

        dataAspectChange(dataAspect.map((data) => data.quality_assurance_aspect_id === String(id) ? {
            quality_assurance_aspect_id: String(id),
            result: nilai
        } : data))
    }

    const getAspectResult = (id) => {
        let filterData = dataAspect.filter(data => data.quality_assurance_aspect_id === String(id))

        if (filterData.length > 0) {
            return filterData[0].result || "0"
        }

        return "0"
    }

    return (
        <>
            <Table striped bordered hover responsive width="100%" className="mb-2" size="sm">
                <thead className="thead-dark">
                    <tr>
                        <th width="57%">Aspek</th>
                        <th width="23%">Hasil</th>
                        <th width="20%">Nilai</th>
                    </tr>
                </thead>
                <tbody>
                    {loading &&
                        <tr>
                            <td colSpan="3" className="text-center">
                                <Spinner animation="border" size="sm" className="mr-1" />
                                Loading data...
                            </td>
                        </tr>
                    || !loading && isEmptyValue(tableData.data) &&
                        <tr>
                            <td colSpan="3" className="text-center">
                                <span className="text-danger">No data found</span>
                            </td>
                        </tr>
                    || !loading && !isEmptyValue(tableData.data) &&
                        tableData.data.map((row, i) => (
                            <tr key={ row.id }>
                                <td>{ row.aspect_name }</td>
                                <td>
                                    <Form.Control
                                        as="select"
                                        size="sm"
                                        onChange={(e) => handleChangeDataAspect(row.id, row.bobot, e.target.value)}
                                        defaultValue="1"
                                        key={`hasil-${row.id}`}
                                    >
                                        <option value="1">Ya</option>
                                        <option value="0">Tidak</option>
                                    </Form.Control>
                                </td>
                                <td>
                                    <Form.Control
                                        type="text"
                                        size="sm"
                                        readOnly={true}
                                        value={getAspectResult(row.id)}
                                        className="text-right"
                                        key={`nilai-${row.id}`}
                                    />
                                </td>
                            </tr>
                        ))
                    }
                </tbody>
            </Table>
            <div className="d-flex justify-content-between bg-dark text-white font-weight-bold mb-2">
                <span className="p-2">Total Nilai :</span>
                <span className="p-2">{totalNilai}</span>
            </div>
        </>
    )
}

const initialOption = [{
    value: "",
    label: "Choose..."
}]

const initialData = {
    quality_assurance_id: null,
    quality_assurance_date: null,
    period_id: null,
    notes: "",
    user_id: null,
    call_id: null
}

const validationSchema = yupResolver(yup.object().shape({
    quality_assurance_id: yup.string().nullable()
        .required("This field is required."),
    quality_assurance_date: yup.date().nullable()
        .required("This field is required."),
    period_id: yup.string().nullable()
        .required("This field is required."),
    notes: yup.string()
        // .required("This field is required.")
}))