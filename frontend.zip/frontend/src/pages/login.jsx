import { useState, useEffect, useContext } from 'react'
import { Button, Form, Spinner } from 'react-bootstrap'
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import _ from 'lodash'
import { AuthContext } from '../utils/context'
import { generalService } from '../utils/services/'
import { useUsers } from '../utils/functions'
import { Notification } from '../components'
import '../public/assets/styles/login.css'
import { BriLogo } from '../public/assets'

const { isEmptyValue } = generalService

export const Login = (props) => {
    const { location, history } = props
    const { AuthLogin } = useUsers()
    const { Error, Success, Warning } = Notification
    const { isAuth } = useContext(AuthContext)
    const userLevelId = localStorage.getItem('userLevelId')
    const { handleSubmit, formState: { errors, isSubmitting }, register } = useForm({
        defaultValues: {
            username: "",
            password: "",
            extension: ""
        },
        resolver: yupResolver(yup.object().shape({
            username: yup.string()
                .required("Username is required."),
            password: yup.string()
                .required("Password is required."),
            extension: yup.string()
                .matches(/^[0-9]+$/, {
                    message: "Extension must contain only numbers.",
                    excludeEmptyString: true
                })
        }))
    })
    const [notif, setNotif] = useState({
        show: false,
        type: null
    })

    useEffect(() => {
        if (isAuth) {
            console.log(userLevelId)
            if (userLevelId && parseInt(userLevelId) === 3) {
                return history.push("/quality-assurance-calls")
            }

            if (userLevelId && parseInt(userLevelId) === 4) {
                return history.push("/quality-assurance")
            }

            return history.push("/")
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [isAuth])

    useEffect(() => {
        if (!isEmptyValue(location.state) && _.isObject(location.state)) {
            if (!isEmptyValue(location.state.alert)) {
                setNotif(location.state.alert)
            }
        }

        return () => setNotif({
            show: false,
            type: null
        })
    }, [location.state])

    const onSubmit = async (data, e) => {
        e.preventDefault()

        const authLogin = await AuthLogin(data)

        if (!authLogin.success) {
            setNotif({
                show: true,
                type: "error",
                message: "Your username or password is incorrect."
            })

            return history.replace("/login")
        }
    }

    return (
        <div className="login-container">
            <div className="row">
                <div className="col-md-6 login-form-2">
                    <h3>Login</h3>
                    {notif.show && notif.type === 'error' && <Error
                        title={notif.title}
                        message={notif.message}
                        show={notif.show}
                        showChange={() => setNotif({
                            show: false,
                            type: null
                        })}
                    />}
                    {notif.show && notif.type === 'success' && <Success
                        title={notif.title}
                        message={notif.message}
                        show={notif.show}
                        showChange={() => setNotif({
                            show: false,
                            type: null
                        })}
                    />}
                    {notif.show && notif.type === 'warning' && <Warning
                        title={notif.title}
                        message={notif.message}
                        show={notif.show}
                        showChange={() => setNotif({
                            show: false,
                            type: null
                        })}
                    />}
                    <Form onSubmit={handleSubmit(onSubmit)}>
                        <Form.Group controlId="Username">
                            <Form.Control
                                type="text"
                                placeholder="Username"
                                isInvalid={!!errors.username}
                                {...register("username")}
                            />
                            <Form.Control.Feedback type="invalid" className="text-white">
                                {errors.username?.message}
                            </Form.Control.Feedback>
                        </Form.Group>
                        <Form.Group controlId="Password">
                            <Form.Control
                                type="password"
                                placeholder="Password"
                                isInvalid={!!errors.password}
                                {...register("password")}
                            />
                            <Form.Control.Feedback type="invalid" className="text-white">
                                {errors.password?.message}
                            </Form.Control.Feedback>
                        </Form.Group>
                        <Form.Group controlId="Extension">
                            <Form.Control
                                type="text"
                                placeholder="Extension"
                                isInvalid={!!errors.extension}
                                {...register("extension")}
                            />
                            <Form.Control.Feedback type="invalid" className="text-white">
                                {errors.extension?.message}
                            </Form.Control.Feedback>
                        </Form.Group>
                        <Form.Group>
                            <Button type="submit" className="btnSubmit" disabled={isSubmitting}>
                                {isSubmitting && <Spinner animation="border" size="sm" className="mr-1" />} Login
                            </Button>
                        </Form.Group>
                        {/* <Form.Group>
                            <Link to="/forgot" className="ForgetPwd" value="Login">Forget Password?</Link>
                        </Form.Group> */}
                    </Form>
                </div>

                <div className="col-md-6 login-form-1">
                    <img src={BriLogo} className="img-fluid" />
                </div>
            </div>
        </div>
    )
}