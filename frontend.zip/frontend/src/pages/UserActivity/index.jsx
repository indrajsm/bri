import { useState, useEffect } from 'react'
import { Spinner, Table } from 'react-bootstrap'
import _ from 'lodash'
import { generalService, cookieService } from './../../utils/services'
import { Notification } from './../../components'
import { useCalls } from './../../utils/functions'
import { ButtonListen, ButtonWhisper } from './ButtonAction'

const { isEmptyValue, sleep } = generalService

export const UserActivity = ({ socket, listenData, whisperData, setListenData, setWhisperData}) => {
    const fnCalls = useCalls()
    const { Error, Success, Warning } = Notification

    const [loading, setLoading] = useState(false)
    const [notif, setNotif] = useState(initialNotif)
    const [tableData, setTableData] = useState([])

    const [loadingListen, setLoadingListen] = useState(false)
    const [loadingWhisper, setLoadingWhisper] = useState(false)

    useEffect(() => {
        socket.emit('escorts')

        socket.on('total-escorts', async (data) => {
            let totalEscorts = JSON.parse(data)

            setLoading(true)
            await sleep(1000)
            fetchData(totalEscorts)
        })

        return () => {
            setTableData([])
            setLoading(false)
        }
    }, [socket])

    const fetchData = (data) => {
        setTableData(data.sort((a,b)=> (a.agent > b.agent ? 1 : -1)))
        setLoading(false)
    }

    const handleListen = async ({ extension, username }) => {
        let success = false
        setLoadingListen(true)

        await fnCalls.Listen(extension).then((res) => {
            if (res.success) {
                success = res.success
                setListenData({
                    destination: extension,
                    username: username
                })
            }
        }).catch((err) => { return }) //do nothing, let it go back to login

        if (success) {
            setNotif({
                title: 'Success',
                message: `You are listening ${username || ''}`,
                show: true,
                type: 'success'
            })
        } else {
            setNotif({
                title: 'Error',
                message: `Failed to listening ${username || ''}`,
                show: true,
                type: 'error'
            })
        }

        setLoadingListen(false)
    }

    const handleUnlisten = async ({ channel, username }) => {
        let success = false

        await fnCalls.Unlisten(channel).then((res) => {
            if (res.success) {
                success = res.success
                setListenData(false)
                // window.localStorage.removeItem('listenData')
            }
        }).catch((err) => { return }) //do nothing, let it go back to login

        if (success) {
            setNotif({
                title: 'Success',
                message: `You are stop listening ${username || ''}`,
                show: true,
                type: 'success'
            })
        } else {
            setNotif({
                title: 'Error',
                message: `Failed to stop listening ${username || ''}`,
                show: true,
                type: 'error'
            })
        }

        setLoadingListen(false)
    }

    const handleWshiper = async ({ extension, username }) => {
        let success = false
        setLoadingWhisper(true)

        await fnCalls.Whisper(extension).then((res) => {
            if (res.success) {
                success = res.success
                setWhisperData({
                    destination: extension,
                    username: username
                })
            }
        }).catch((err) => { return }) //do nothing, let it go back to login

        if (success) {
            setNotif({
                title: 'Success',
                message: `You are whispering ${username || ''}`,
                show: true,
                type: 'success'
            })
        } else {
            setNotif({
                title: 'Error',
                message: `Failed to whispering ${username || ''}`,
                show: true,
                type: 'error'
            })
        }

        setLoadingWhisper(false)
    }

    const handleUnwhisper = async ({ channel, username }) => {
        let success = false

        await fnCalls.Unwhisper(channel).then((res) => {
            if (res.success) {
                success = res.success
                setWhisperData(false)
                // window.localStorage.removeItem('whisperData')
            }
        }).catch((err) => { return }) //do nothing, let it go back to login

        if (success) {
            setNotif({
                title: 'Success',
                message: `You are stop whispering ${username || ''}`,
                show: true,
                type: 'success'
            })
        } else {
            setNotif({
                title: 'Error',
                message: `Failed to stop whispering ${username || ''}`,
                show: true,
                type: 'error'
            })
        }

        setLoadingWhisper(false)
    }

    return (
        <>
            <h1 className="mt-4">User Activity</h1>
            <ol className="breadcrumb mb-4">
                <li className="breadcrumb-item active">User Activity</li>
            </ol>
            {notif.show && notif.type === 'error' && <Error
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            {notif.show && notif.type === 'success' && <Success
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            {notif.show && notif.type === 'warning' && <Warning
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            <div className="card mb-4">
                <div className="card-body">
                    <Table striped hover responsive width="100%" cellSpacing="0" cellPadding="0">
                        <thead className="thead-dark">
                            <tr>
                                <th className="text-nowrap">No.</th>
                                <th className="text-nowrap">Agent</th>
                                <th className="text-nowrap">Activity</th>
                                <th className="text-nowrap">Duration</th>
                                <th className="text-nowrap">First Login</th>
                                <th className="text-nowrap">Last Logout</th>
                                <th className="text-nowrap text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {loading &&
                                <tr>
                                    <td colSpan="7" className="text-center">
                                        <Spinner animation="border" size="sm" className="mr-1" />
                                        Loading data...
                                    </td>
                                </tr>
                            }
                            {!loading && isEmptyValue(tableData) &&
                                <tr>
                                    <td colSpan="7" className="text-center">
                                        <span className="text-danger">No data found</span>
                                    </td>
                                </tr>
                            }
                            {!loading && !isEmptyValue(tableData) &&
                                tableData.map((row, i) => (
                                    <tr key={ row.id }>
                                        <td>{ i + 1 }</td>
                                        <td>{ row.agent }</td>
                                        <td>{ row.activity }</td>
                                        <td>{ row.duration }</td>
                                        <td>{ row.first_login }</td>
                                        <td>{ row.last_logout }</td>
                                        <td className="text-center">
                                            <ButtonListen
                                                activityId={row.user_activity_id}
                                                ext={row.extension}
                                                user={row.agent}
                                                loggedExt={cookieService.Get('ext')}
                                                loggedUser={cookieService.Get('username')}
                                                loggedLevelId={cookieService.Get('user_level_id')}
                                                whisperData={whisperData}
                                                listenData={listenData}
                                                loading={loadingListen}
                                                onStart={(params) => {
                                                    handleListen(params)
                                                    setLoadingListen(true)
                                                }}
                                                onStop={(params) => {
                                                    handleUnlisten(params)
                                                    setLoadingListen(true)
                                                }}
                                            />
                                            <ButtonWhisper
                                                activityId={row.user_activity_id}
                                                ext={row.extension}
                                                user={row.agent}
                                                loggedExt={cookieService.Get('ext')}
                                                loggedUser={cookieService.Get('username')}
                                                loggedLevelId={cookieService.Get('user_level_id')}
                                                whisperData={whisperData}
                                                listenData={listenData}
                                                loading={loadingWhisper}
                                                onStart={(params) => {
                                                    handleWshiper(params)
                                                    setLoadingWhisper(true)
                                                }}
                                                onStop={(params) => {
                                                    handleUnwhisper(params)
                                                    setLoadingWhisper(true)
                                                }}
                                            />
                                        </td>
                                    </tr>
                                ))
                            }
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>No.</th>
                                <th>Agent</th>
                                <th>Activity</th>
                                <th>Duration</th>
                                <th>First Login</th>
                                <th>Last Logout</th>
                                <th className="text-center">Action</th>
                            </tr>
                        </tfoot>
                    </Table>

                    {!loading && !isEmptyValue(tableData) &&
                        <div className="py-2 border-top">
                            Showing 1 to {tableData.length} of {tableData.length} entries
                        </div>
                    }
                </div>
            </div>
        </>
    )
}

const initialNotif = {
    title: "",
    message: "",
    show: false,
    type: null
}