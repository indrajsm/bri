import { Button } from 'react-bootstrap'
import { generalService } from './../../utils/services'

const { isEmptyValue } = generalService

export const ButtonListen = ({
    activityId,
    ext,
    user,
    loggedExt,
    loggedUser,
    loggedLevelId,
    whisperData,
    listenData,
    loading,
    onStart,
    onStop
}) => {
    if (
        [9].includes(activityId) &&
        !isEmptyValue(ext) &&
        !isEmptyValue(loggedExt) &&
        user !== loggedUser &&
        [2,5].includes(parseInt(loggedLevelId))
    ) {
        if (listenData) {
            if (listenData['destination'] === ext) {
                return (
                    <Button variant="info" size="sm" className="m-1" onClick={(e) => onStop({
                        channel: listenData['channel'] || null,
                        username: listenData['username']
                    })} disabled={loading ? true : false}>
                        <i className="fas fa-stop fa-fw" /> Listen
                    </Button>
                )
            }
    
            return (
                <Button variant="info" size="sm" className="m-1" disabled={true}>
                    <i className="fas fa-play fa-fw" /> Listen
                </Button>
            )
        }

        if (whisperData) {
            return (
                <Button variant="info" size="sm" className="m-1" disabled={true}>
                    <i className="fas fa-play fa-fw" /> Listen
                </Button>
            )
        }

        return (
            <Button variant="info" size="sm" className="m-1" onClick={(e) => onStart({
                extension: ext,
                username: user
            })} disabled={loading ? true : false}>
                <i className={`fas ${loading ? "fa-circle-notch fa-spin" : "fa-play"} fa-fw`} /> Listen
            </Button>
        )
    }

    return (
        <Button variant="info" size="sm" className="m-1" disabled={true}>
            <i className="fas fa-play fa-fw" /> Listen
        </Button>
    )
}

export const ButtonWhisper = ({
    activityId,
    ext,
    user,
    loggedExt,
    loggedUser,
    loggedLevelId,
    whisperData,
    listenData,
    loading,
    onStart,
    onStop
}) => {
    if (
        [9].includes(activityId) &&
        !isEmptyValue(ext) &&
        !isEmptyValue(loggedExt) &&
        user !== loggedUser &&
        [2,5].includes(parseInt(loggedLevelId))
    ) {
        if (whisperData) {
            if (whisperData['destination'] === ext) {
                return (
                    <Button variant="success" size="sm" className="m-1" onClick={(e) => onStop({
                        channel: whisperData['channel'] || null,
                        username: whisperData['username']
                    })} disabled={loading ? true : false}>
                        <i className="fas fa-stop fa-fw" /> Whisper
                    </Button>
                )
            }
    
            return (
                <Button variant="success" size="sm" className="m-1" disabled={true}>
                    <i className="fas fa-play fa-fw" /> Whisper
                </Button>
            )
        }

        if (listenData) {
            return (
                <Button variant="success" size="sm" className="m-1" disabled={true}>
                    <i className="fas fa-play fa-fw" /> Whisper
                </Button>
            )
        }

        return (
            <Button variant="success" size="sm" className="m-1" onClick={(e) => onStart({
                extension: ext,
                username: user
            })} disabled={loading ? true : false}>
                <i className={`fas ${loading ? "fa-circle-notch fa-spin" : "fa-play"} fa-fw`} /> Whisper
            </Button>
        )
    }

    return (
        <Button variant="success" size="sm" className="m-1" disabled={true}>
            <i className="fas fa-play fa-fw" /> Whisper
        </Button>
    )
}