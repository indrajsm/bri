import React, { useState, useEffect, useCallback, useContext } from 'react'
import { Form, Modal, Button, Collapse } from 'react-bootstrap'
import { useForm, Controller } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import { useStopwatch } from 'react-timer-hook';
import classnames from 'classnames'
import { useBreakReasons, useUsers } from '../../utils/functions';
import { generalService } from '../../utils/services';
import { AuthContext } from '../../utils/context'
import { cookieService } from '../../utils/services/'
import { Notification } from '../../components';

const { isEmptyValue, formatDateTime, diffDate } = generalService

export const Break = ({ handleModalClose, socket }) => {
    const { Get } = useBreakReasons()
    const { StartBreak } = useUsers()
    const { setUserActivityId } = useContext(AuthContext)
    const [reason, setReason] = useState()
    const [reasonName, setReasonName] = useState(null)
    const [breakHistoryId, setBreakHistoryId] = useState()
    const { handleSubmit, formState: { errors }, register, watch } = useForm({
        defaultValues: initialBreak,
        resolver: validationSchemaReason
    })

    const start_break = localStorage.getItem('startBreak')
    const [toggle, setToggle] = useState({
        showBreak: !start_break ? true : false,
        showDuration: !start_break ? false : true
    })

    const handleBreakReason = (e) => {
        // let index = e.target.selectedIndex
        setReasonName(e.target.options[e.target.selectedIndex].text)
    }

    const onSubmit = async (data, e) => {
        e.preventDefault()
        const id = cookieService.Get('user_id')

        await StartBreak(id, data).then(async (res) => {
            if (res.success) {
                localStorage.setItem('breakHistoryId', res.data.id)
                setBreakHistoryId(res.data.id)
                handleToggleChange()
                localStorage.setItem('startBreak', formatDateTime())
                localStorage.setItem('userActivityId', 6)
                setUserActivityId(6)
                socket.emit('escorts')
            }
        }).catch((err) => { return })

    }

    const handleToggleChange = useCallback(() => {
        setToggle({
            showBreak: !toggle.showBreak,
            showDuration: !toggle.showDuration
        })
    }, [toggle])

    useEffect(() => {
        const fetchData = async () => {
            await Get({ is_active: 1 }).then((res) => {
                setReason(res.data)
            }).catch((err) => { return }) //do nothing, let it go back to login
        }
        fetchData()
    }, [])
    return (
        <>
            <Collapse in={toggle.showBreak} unmountOnExit={false} mountOnEnter={true}>
                <Form onSubmit={handleSubmit(onSubmit)}>
                    <Modal.Body>
                        <Form.Group className="mb-3">
                            <Form.Label>Break Reason</Form.Label>
                            <select className="form-control" {...register("break_reason_id")} onChange={handleBreakReason}>
                                <option value="">Please Select</option>
                                {!isEmptyValue(reason) && reason.map(item => (
                                    <option key={item.id} value={item.id}>{item.name}</option>
                                ))}
                            </select>
                        </Form.Group>
                        <Form.Text className={classnames("text-danger", {
                            "d-none": !errors.break_reason_id
                        })}>{errors.break_reason_id ?.message}</Form.Text>
                    </Modal.Body>
                    <Modal.Footer>
                        <Button variant="warning" onClick={() => handleModalClose()}>
                            Cancel
                    </Button>
                        <Button variant="primary" type="submit">
                            Save
                    </Button>
                    </Modal.Footer>
                </Form>
            </Collapse >
            <Duration
                showDuration={toggle.showDuration}
                startBreak={start_break}
                handleModalClose={handleModalClose}
                breakHistoryId={breakHistoryId}
                reasonName={reasonName}
                socket={socket}
                setUserActivityId={setUserActivityId}
            />
        </>
    )
}

const Duration = ({ showDuration, startBreak, handleModalClose, breakHistoryId, reasonName,socket,setUserActivityId }) => {
    const diff = diffDate(formatDateTime(), startBreak) / 700
    const { user, setUser } = useContext(AuthContext)
    const { EndBreak } = useUsers()
    const [alert, setAlert] = useState(null)
    const { Success, Error } = Notification

    const { handleSubmit, formState: { errors }, register } = useForm({
        defaultValues: initialDuration,
        resolver: validationSchemaDuration
    })

    const handleAlert = value => {
        return value && value === 1 ? (
            <Success message="Data has been updated." />
        ) : (
                <Error message="Your password is incorrect." />
            )
    }

    const stopwatchOffset = new Date();
    const {
        seconds,
        minutes,
        hours,
        start,
    } = useStopwatch({ autoStart: false, offsetTimestamp: stopwatchOffset.setSeconds(stopwatchOffset.getSeconds() + diff) })

    const hourTime = hours < 10 ? `0${hours}` : `${hours}`
    const minuteTime = minutes < 10 ? `0${minutes}` : `${minutes}`
    const secondTime = seconds < 10 ? `0${seconds}` : `${seconds}`

    const onSubmit = async (data, e) => {
        e.preventDefault()
        if (!breakHistoryId) return localStorage.getItem('breakHistoryId')

        const id = cookieService.Get('user_id')

        setAlert(null)
        await EndBreak(breakHistoryId, { ...data, user_id: id }).then(async (res) => {
            if (res.success) {
                handleModalClose()
                localStorage.removeItem("startBreak")
                localStorage.removeItem("breakHistoryId")
                localStorage.setItem('userActivityId', 8)
                setUserActivityId(8)
                socket.emit('escorts')
            } else {
                setAlert(2)
            }
        }).catch((err) => { return })

    }

    useEffect(() => {
        start()
        const getUser = () => {
            setUser(cookieService.Get('username'))
        }
        if (!user) getUser()
        // return () => fnAbort.abort()
    }, [showDuration])
    return (
        <>
            <Collapse in={showDuration} unmountOnExit={false} mountOnEnter={true}>
                <Form onSubmit={handleSubmit(onSubmit)}>
                    <Modal.Body>
                        {alert && handleAlert(alert)}
                        <h4 align="center"><strong>User {user} is taking a break ({reasonName})</strong></h4>
                        <div style={{ fontSize: '60px', textAlign: "center" }}>
                            <span>{hourTime}</span>:<span>{minuteTime}</span>:<span>{secondTime}</span>
                        </div>
                        <Form.Group className="mb-3">
                            {/* <Form.Label>Enter password to resume</Form.Label> */}
                            <Form.Control
                                type="password"
                                size="sm"
                                placeholder="Enter password to resume"
                                {...register("password")} required
                            />
                        </Form.Group>
                    </Modal.Body>
                    <Modal.Footer>
                        <Button variant="primary" type="submit">
                            Resume
                        </Button>
                    </Modal.Footer>
                </Form>
            </Collapse>
        </>
    )
}

const initialBreak = {
    break_reason_id: '',
}

const initialDuration = {
    password: '',
    user_id: '',
}

const validationSchemaReason = yupResolver(yup.object().shape({
    break_reason_id: yup.string()
        .required("This field is required."),
}))

const validationSchemaDuration = yupResolver(yup.object().shape({
    password: yup.string()
        .required("This field is required."),
}))