import React, { useState, useEffect, useCallback, useContext } from 'react'
import { Form, Modal, Button, Collapse } from 'react-bootstrap'
import { usePickUp, useHangUp } from '../../utils/functions';
import { generalService } from '../../utils/services';
import { AuthContext, CallContext } from '../../utils/context'
import '../../public/assets/styles/incoming-call.css'
import { UserImg } from '../../public/assets'

const { isEmptyValue } = generalService

export const IncomingCall = ({ handleModalClose }) => {
    const { ext, user } = useContext(AuthContext)
    const { incomingCall, setOnlineStatus } = useContext(CallContext)
    const { channel, phone_no, call_id } = incomingCall
    const { PickUp } = usePickUp()
    const { HangUp } = useHangUp()

    const is_pickup = localStorage.getItem('isPickUp')
    const [toggle, setToggle] = useState({
        showIncomingCall: !is_pickup ? true : false,
        showCallDetail: !is_pickup ? false : true
    })

    const handleHangUp = async (e) => {
        e.preventDefault()
        const data = {
            'channel': channel,
        }
        await HangUp(data).then(async (res) => {
            if (res.success) {
                localStorage.removeItem('onlineStatus');
                localStorage.removeItem('incomingCall');
                setOnlineStatus(null)
                handleModalClose()
            }
        }).catch((err) => { return })
        handleModalClose()
    }

    const handlePickUp = async (e) => {
        e.preventDefault()
        const data = {
            'call_id': call_id,
            'channel': channel,
            'destination': ext,
            'phone_number': phone_no,
            'username': user
        }
        await PickUp(data).then(async (res) => {
            // if (res.success) {
            //     handleModalClose()
            // }
        }).catch((err) => { return })
    }


    useEffect(() => {
        // const fetchData = async () => {
        //     await Get({ is_active: 1 }).then((res) => {
        //         setReason(res.data)
        //     }).catch((err) => { return }) //do nothing, let it go back to login
        // }
        // fetchData()
    }, [])
    return (
        <>
            <Collapse in={toggle.showIncomingCall} unmountOnExit={false} mountOnEnter={true}>
                <Form onSubmit={handlePickUp}>
                    <Modal.Body className="mt-3">
                        <Form.Group className="mb-3">
                            <div className="call-animation mb-5">
                                <img src={UserImg} className="img-circle" />
                            </div>
                            <h3 align="center">{phone_no}</h3>
                        </Form.Group>
                    </Modal.Body>
                    <Modal.Footer>
                        <Button variant="danger" onClick={handleHangUp}>
                            Hang Up
                        </Button>
                        <Button variant="info" type="submit">
                            Pick Up
                        </Button>
                    </Modal.Footer>
                </Form>
            </Collapse >
        </>
    )
}
