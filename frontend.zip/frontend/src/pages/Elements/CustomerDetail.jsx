import React, { useState, useEffect, useCallback, useContext } from 'react'
import { Form, Modal, Button, Collapse } from 'react-bootstrap'
import { useForm, Controller } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import { useStopwatch } from 'react-timer-hook';
import classnames from 'classnames'
import { useBreakReasons } from '../../utils/functions';
import { generalService } from '../../utils/services';
import { AuthContext } from '../../utils/context'
import { cookieService } from '../../utils/services/'

const { isEmptyValue, formatDateTime, diffDate } = generalService

export const CustomerDetail = ({ handleModalClose }) => {
    const { Get } = useBreakReasons()
    const [reason, setReason] = useState()
    const { handleSubmit, formState: { errors }, register, control, reset, clearErrors, setValue } = useForm({
        defaultValues: initialBreak,
        resolver: validationSchemaReason
    })

    const start_break = localStorage.getItem('startBreak')
    const [toggle, setToggle] = useState({
        showBreak: !start_break ? true : false,
        showDuration: !start_break ? false : true
    })

    const onSubmit = async (data, e) => {
        e.preventDefault()
        handleToggleChange()
        localStorage.setItem('startBreak', formatDateTime())
    }

    const handleToggleChange = useCallback(() => {
        setToggle({
            showBreak: !toggle.showBreak,
            showDuration: !toggle.showDuration
        })
    }, [toggle])

    useEffect(() => {
        const fetchData = async () => {
            await Get({ is_active: 1 }).then((res) => {
                setReason(res.data)
            }).catch((err) => { return }) //do nothing, let it go back to login
        }
        fetchData()
    }, [])
    return (
        <>
            <Collapse in={toggle.showBreak} unmountOnExit={false} mountOnEnter={true}>
                <Form onSubmit={handleSubmit(onSubmit)}>
                    <Modal.Body>
                        <Form.Group className="mb-3">
                            <Form.Label>Break Reason</Form.Label>
                            <select className="form-control" {...register("break_reason_id")}>
                                <option value="">Please Select</option>
                                {!isEmptyValue(reason) && reason.map(item => (
                                    <option key={item.id} value={item.id}>{item.name}</option>
                                ))}
                            </select>
                        </Form.Group>
                        <Form.Text className={classnames("text-danger", {
                            "d-none": !errors.break_reason_id
                        })}>{errors.break_reason_id ?.message}</Form.Text>
                    </Modal.Body>
                    <Modal.Footer>
                        <Button variant="primary" type="submit">
                            Save
                    </Button>
                    </Modal.Footer>
                </Form>
            </Collapse >
            <Durationss showDuration={toggle.showDuration} startBreak={start_break} handleModalClose={handleModalClose} />
        </>
    )
}


const Durationss = ({ showDuration, startBreak, handleModalClose }) => {
    const diff = diffDate(formatDateTime(), startBreak) / 700
    const { user, setUser } = useContext(AuthContext)

    const stopwatchOffset = new Date();
    const {
        seconds,
        minutes,
        hours,
        start,
        reset,
    } = useStopwatch({ autoStart: false, offsetTimestamp: stopwatchOffset.setSeconds(stopwatchOffset.getSeconds() + diff) })

    const hourTime = hours < 10 ? `0${hours}` : `${hours}`
    const minuteTime = minutes < 10 ? `0${minutes}` : `${minutes}`
    const secondTime = seconds < 10 ? `0${seconds}` : `${seconds}`

    const handleClick = () => {
        handleModalClose()
        localStorage.removeItem("startBreak");
    }

    useEffect(() => {
        start()
        // const fnAbort = new AbortController()

        const getUser = () => {
            setUser(cookieService.Get('username'))
        }
        if (!user) getUser()
        // return () => fnAbort.abort()
    }, [showDuration])
    return (
        <>
            <Collapse in={showDuration} unmountOnExit={false} mountOnEnter={true}>
                <Form>
                    <Modal.Body>
                        <h4 align="center"><strong>User {user} is taking a break</strong></h4>
                        <div style={{ fontSize: '60px', textAlign: "center" }}>
                            <span>{hourTime}</span>:<span>{minuteTime}</span>:<span>{secondTime}</span>
                        </div>
                        <Form.Group className="mb-3">
                            {/* <Form.Label>Enter password to resume</Form.Label> */}
                            <Form.Control
                                type="text"
                                size="sm"
                                placeholder="Enter password to resume"
                            />
                        </Form.Group>
                    </Modal.Body>
                    <Modal.Footer>
                        <Button variant="primary" onClick={handleClick}>
                            Resume
                        </Button>
                    </Modal.Footer>
                </Form>
            </Collapse>
        </>
    )
}

const initialBreak = {
    break_reason_id: '',
}

const validationSchemaReason = yupResolver(yup.object().shape({
    break_reason_id: yup.string()
        .required("This field is required."),
}))