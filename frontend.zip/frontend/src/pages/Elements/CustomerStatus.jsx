import React, { useState, useContext } from "react"
import { Button, Form, Modal, } from "react-bootstrap"
import "react-quill/dist/quill.snow.css"
import "../../public/assets/styles/editor.css"
import _ from "lodash"
import { useCustomers, useUsers } from "../../utils/functions"
import { generalService } from "../../utils/services";
import { AuthContext, UserActivityContext, CallContext } from "../../utils/context";

const { formatDateTime } = generalService

export const CustomerStatus = ({ handleModalClose, customerId, handleModalScheduleCall }) => {
    const { userId } = useContext(AuthContext)
    const { setUserActivityId } = useContext(UserActivityContext)
    const {
        onlineStatus,
        setOnlineStatus
    } = useContext(CallContext)
    const { Update } = useCustomers()
    const fnUsers = useUsers()
    const [status, setStatus] = useState(null)

    const handleSubmitStatus = async e => {
        e.preventDefault(e)
        if (status == 4) {
            await Update(customerId, {
                customer_status_id: status,
                close_date: formatDateTime()
            })
                .then(async res => {
                    if (res.success) {
                        await fnUsers.Update(userId, {
                            user_activity_id: 8
                        }).then(async res => {
                            if (res.success) {
                                handleModalClose()
                                localStorage.setItem('userActivityId', 8)
                                setUserActivityId(8)
                                setOnlineStatus(null)
                            }
                        })
                    }
                })
                .catch(err => {
                    return
                })
        } else {
            handleModalClose()
            handleModalScheduleCall()
        }
    }

    return (
        <Form onSubmit={handleSubmitStatus}>
            <Modal.Body className="pb-1">
                <Form.Group>
                    <Form.Label>Select Customer Status</Form.Label>
                    <select
                        className="form-control"
                        required
                        onChange={e => setStatus(e.target.value)}
                    >
                        <option value="">--Please Select --</option>
                        <option value="4">Close</option>
                        <option value="2">Schedule Call</option>
                    </select>
                </Form.Group>
            </Modal.Body>
            <Modal.Footer>
                <Modal.Footer>
                    {/* <Button variant="warning" onClick={handleModalClose}>Cancel</Button> */}
                    <Button variant="primary" type="submit">
                        Save
                    </Button>
                </Modal.Footer>
            </Modal.Footer>
        </Form>
    )
}

