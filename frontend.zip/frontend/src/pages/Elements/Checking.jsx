import React, { useEffect, useState, useContext } from "react"
import { Button, Form, Modal, Card, } from "react-bootstrap"
import { useForm, Controller } from "react-hook-form"
import classnames from "classnames"
import { yupResolver } from "@hookform/resolvers/yup"
import * as yup from "yup"
import _ from "lodash"
import { Notification } from "../../components"
import { useCheckingSatuses, useCheckingReasons, useCustomers } from "../../utils/functions"
import { generalService } from "../../utils/services"
import { AuthContext } from "../../utils/context"

const { formatDateTime, isEmptyValue } = generalService

export const Checking = ({ customerId, handleModalClose }) => {
    const { userId } = useContext(AuthContext)
    const { Get, Update } = useCustomers()
    const fnCheckingStatus = useCheckingSatuses()
    const fnCheckingReason = useCheckingReasons()
    const [customer, setCustomer] = useState({})
    const { handleSubmit, formState: { errors }, register, reset, clearErrors } = useForm({
        defaultValues: initialChecking,
        resolver: validationSchemaChecking
    })
    const [checkingStatus, setCheckingStatus] = useState({})
    const [checkingReason, setCheckingReason] = useState({})

    const [alert, setAlert] = useState(null)
    const { Success, Error } = Notification

    const handleAlert = value => {
        return value && value === 1 ? (
            <Success message="Data has been updated." />
        ) : (
                <Error message="Failed to updated data." />
            )
    }

    const onSubmit = async data => {
        if (data.checking_status_id == 2) {
            data = { ...data, customer_status_id: 3 }
        }
        await Update(customerId, data)
            .then(res => {
                if (res.success) {
                    console.log(res)
                    setAlert(1)
                    handleModalClose()
                } else {
                    setAlert(2)
                }
            })
            .catch(err => {
                return
            })
    }

    useEffect(() => {
        const fetchData = async () => {
            clearErrors()
            reset({
                ...initialChecking,
                updated_by: userId,
            })
            await Get({ id: customerId })
                .then(res => {
                    if (!isEmptyValue(res.data)) {
                        setCustomer(res.data)
                    }
                })
                .catch(err => {
                    return
                })
            await fnCheckingStatus.Get()
                .then(res => {
                    if (!isEmptyValue(res.data)) {
                        setCheckingStatus(res.data)
                    }
                })
                .catch(err => {
                    return
                })
            await fnCheckingReason.Get()
                .then(res => {
                    if (!isEmptyValue(res.data)) {
                        setCheckingReason(res.data)
                    }
                })
                .catch(err => {
                    return
                })
        }
        fetchData()
    }, [])

    return (
        <>
            <Form className="mb-3" onSubmit={handleSubmit(onSubmit)}>
                <Modal.Body>
                    {alert && handleAlert(alert)}
                    <Card className="mb-3">
                        {/* <Card.Header>Import Customer</Card.Header> */}
                        <Card.Body>
                            <Form.Group className="col-md-12">
                                <Form.Label>Checking Status</Form.Label>
                                <select
                                    className="form-control"
                                    {...register("checking_status_id")}
                                >
                                    <option value="">--Please Select --</option>
                                    {!isEmptyValue(checkingStatus) > 0 &&
                                        checkingStatus.map(item => (
                                            <option key={item.id} value={item.id} selected={item.id === customer.checking_reason_id && "true"}>
                                                {item.name}
                                            </option>
                                        ))}
                                </select>
                                <Form.Text
                                    className={classnames("text-danger", {
                                        "d-none": !errors.checking_status_id
                                    })}
                                >
                                    {errors.checking_status_id ?.message}
                                </Form.Text>
                            </Form.Group>

                            <Form.Group className="col-md-12">
                                <Form.Label>Checking Reason</Form.Label>
                                <select
                                    className="form-control"
                                    {...register("checking_reason_id")}
                                >
                                    <option value="">--Please Select --</option>
                                    {!isEmptyValue(checkingReason) > 0 &&
                                        checkingReason.map(item => (
                                            <option key={item.id} value={item.id} selected={item.id === customer.checking_reason_id && "true"} >
                                                {item.name}
                                            </option>
                                        ))}
                                </select>
                                <Form.Text
                                    className={classnames("text-danger", {
                                        "d-none": !errors.checking_reason_id
                                    })}
                                >
                                    {errors.checking_reason_id ?.message}
                                </Form.Text>
                            </Form.Group>
                        </Card.Body>
                    </Card>
                </Modal.Body>
                <Modal.Footer>
                    {customer.checking_status_id != 1 &&
                        <Button variant="primary" type="submit">
                            Save
                  </Button>
                    }

                </Modal.Footer>
            </Form>
        </>
    )
}

const initialChecking = {
    checking_status_id: null,
    checking_reason_id: null,
    updated_by: null,
}

const validationSchemaChecking = yupResolver(
    yup.object().shape({
        checking_status_id: yup.string().required("This field is required."),
        checking_reason_id: yup.string().required("This field is required."),
        // updated_by: yup.string().required("This field is required."),
    })
)
