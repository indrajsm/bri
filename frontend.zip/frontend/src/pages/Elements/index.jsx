import { Modal } from "react-bootstrap"
import React, { useEffect, useState, useContext } from "react"
import _ from "lodash"
import { generalService } from "../../utils/services"
import { SocketContext, CallContext, AuthContext, UserActivityContext } from "../../utils/context"
import { IncomingCall } from "./IncomingCall"
import { CustomerStatus } from "./CustomerStatus"
import { FormDetail } from "../CustomerCalls/FormDetail"
import { FormAdd } from "../Callback/FormAdd"
import { useUsers } from "../../utils/functions";

const { isEmptyValue, formatDateTime } = generalService

export const Element = props => {
  const socket = useContext(SocketContext)
  const {
    incomingCall,
    onlineStatus,
    setOnlineStatus
  } = useContext(CallContext)
  const { userId } = useContext(AuthContext)
  const { setUserActivityId } = useContext(UserActivityContext)
  const { Update } = useUsers()
  const { campaign_id } = incomingCall
  const [modalCall, setModalCall] = useState(initialModalCall)
  const [modalCustomerDetail, setModalCustomerDetail] = useState(initialModalCustomerDetail)
  const [modalCustomerStatus, setModalCusomerStatus] = useState(initialModalCustomerStatus)
  const [modalScheduleCall, setModalScheduleCall] = useState(initialModalScheduleCall)
  // const handleClose = () => setShow(false)

  const handleModalCall = () => {
    setModalCall({
      ...modalCall,
      show: !modalCall.show
    })
  }

  const handleModalCustomerDetail = () => {
    setModalCustomerDetail({
      ...modalCustomerDetail,
      show: !modalCustomerDetail.show
    })
    localStorage.setItem('userActivityId', 4)
    setUserActivityId(4)
  }

  const handleModalCustomerStatus = () => {
    setModalCusomerStatus({
      ...modalCustomerStatus,
      show: !modalCustomerStatus.show
    })
  }

  const handleModalScheduleCall = () => {
    setModalScheduleCall({
      ...modalScheduleCall,
      show: !modalScheduleCall.show
    })
  }

  const handleModalClose = () => {
    setModalCall(initialModalCall)
    socket.emit('escorts')
  }

  const handleModalCloseCustomerDetail = () => {
    setModalCustomerDetail(initialModalCustomerDetail)
    handleModalCustomerStatus()
    localStorage.setItem('userActivityId', 2)
    setUserActivityId(2)
    socket.emit('escorts')
    // setOnlineStatus(3)
  }

  const handleModalCloseStatus = () => {
    setModalCusomerStatus(initialModalCustomerStatus)
    socket.emit('escorts')
  }

  const handleModalCloseSchedule = async e => {
    setModalScheduleCall(initialModalScheduleCall)
    await Update(userId, {
      user_activity_id: 8
    }).then(async res => {
      if (res.success) {
        localStorage.setItem('userActivityId', 8)
        setUserActivityId(8)
        socket.emit('escorts')
        setOnlineStatus(null)
      }
    })
  }

  React.useEffect(() => {
    const socketEvent = () => {
      // incoming call
      socket.on("transfercallserver-event", data => {
        localStorage.setItem("incomingCall", JSON.stringify(data))
        localStorage.setItem("onlineStatus", 1)
        setOnlineStatus(1)
        handleModalCall()
        socket.emit('escorts')
        console.log(data, 'transfercallserver')

      })

      // pickup call
      socket.on("bridge-enter-event", data => {
        localStorage.setItem("pickupCall", JSON.stringify(data))
        localStorage.setItem("onlineStatus", 2)
        localStorage.setItem("startCall", formatDateTime())
        socket.emit("call-all-campaigns")
        socket.emit("call-campaigns", {
          campaign_id: campaign_id
        })
        setOnlineStatus(2)
        handleModalCustomerDetail()
        handleModalClose()
        console.log("bridge-enter-event")
        socket.emit('escorts')
      })

      // user activity
      socket.on('total-escorts', data => {
        let escort = JSON.parse(data)
        escort.filter(i => i.id == userId).map(row => {
          localStorage.setItem('userActivityId', row.user_activity_id)
          setUserActivityId(row.user_activity_id)
        })
      })
    }

    if (isEmptyValue(onlineStatus)) {
      socket.emit("amount-all-campaigns")
      socket.emit("amount-campaigns", {
        campaign_id: campaign_id
      })
    }
    socket.emit('escorts')

    socketEvent()
  }, [socket, campaign_id, onlineStatus])

  useEffect(() => {
    if (onlineStatus == 1) return handleModalCall()
    if (onlineStatus == 2) return handleModalCustomerDetail()
    // handleModalCustomerDetail()
  }, [onlineStatus])

  return (
    <>
      <Modal show={modalCall.show} onHide={handleModalClose} backdrop="static" keyboard={false}>
        <Modal.Header>
          <Modal.Title>Incoming Call</Modal.Title>
        </Modal.Header>
        <IncomingCall handleModalClose={handleModalClose} />
      </Modal>

      <Modal show={modalCustomerDetail.show} onHide={handleModalCloseCustomerDetail} backdrop="static" keyboard={false} size="lg">
        <Modal.Header>
          <Modal.Title>Customer Detail</Modal.Title>
        </Modal.Header>
        <FormDetail
          handleModalClose={handleModalCloseCustomerDetail}
          handleModalCustomerStatus={handleModalCustomerStatus}
          dataId={incomingCall.customer_id}
          campaignId={incomingCall.campaign_id}
          handleScheduleCall={handleModalScheduleCall} />
      </Modal>

      <Modal show={modalCustomerStatus.show} onHide={handleModalCloseStatus} backdrop="static" keyboard={false} size="lg">
        <Modal.Header>
          <Modal.Title>Customer Status</Modal.Title>
        </Modal.Header>
        <CustomerStatus
          handleModalClose={handleModalCloseStatus}
          customerId={incomingCall.customer_id}
          handleModalScheduleCall={handleModalScheduleCall}
        />
      </Modal>

      <Modal show={modalScheduleCall.show} onHide={handleModalCloseSchedule} backdrop="static" keyboard={false} size="lg">
        <Modal.Header>
          <Modal.Title>Schedule Call</Modal.Title>
        </Modal.Header>
        <FormAdd
          handleModalClose={handleModalCloseSchedule}
          dataChange={() => { }}
          customerId={incomingCall.customer_id}
          campaignId={incomingCall.campaign_id}
          phoneNo={incomingCall.phone_no} />
      </Modal>
    </>
  )
}

const initialModalCall = {
  show: false,
  dataId: ""
}

const initialModalCustomerDetail = {
  show: false,
  dataId: ""
}

const initialModalScheduleCall = {
  show: false,
  dataId: ""
}

const initialModalCustomerStatus = {
  show: false,
  dataId: ""
}
