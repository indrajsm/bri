import React, { useEffect, useState } from 'react'
import { Button, Form, Row, Col } from 'react-bootstrap'
import { useForm } from 'react-hook-form'
import { yupResolver } from "@hookform/resolvers/yup"
import * as yup from "yup"
import classnames from "classnames"
import { useCampaignFields, useCustomers } from '../../utils/functions';
import { Notification } from '../../components'
import { generalService } from '../../utils/services';

const { isEmptyValue } = generalService

export const CustomerField = ({ CampaignId, Customer }) => {
    const { Get } = useCampaignFields()
    const { Update } = useCustomers()
    const [field, setField] = useState({})
    const [alert, setAlert] = useState(null)
    const { Success, Error } = Notification

    const { register, handleSubmit, clearErrors, reset, formState: { errors } } = useForm({
        // defaultValues: initialCustomer,
        resolver: validationSchemaCustomer
    })

    const onSubmitCustomer = async (data, e) => {
        e.preventDefault(e)
        setAlert(null)
        await Update(Customer.id, data).then((res) => {
            if (res.success) {
                setAlert(1)
            } else {
                setAlert(2)
            }
        }).catch((err) => { return })
    }

    const handleAlert = (value) => {
        return (
            value && value === 1 ?
                <Success message="Data has been updated." /> :
                <Error message="Failed to update data." />
        )
    }

    useEffect(() => {
        const fetchData = async () => {
            if (!isEmptyValue(CampaignId)) {
                await Get({
                    campaign_id: CampaignId,
                    limit: "0",
                    order: "field_name_display",
                    is_active: 1
                }).then((res) => {
                    if (!isEmptyValue(res.data)) {
                        setField(res.data)
                    }
                }).catch((err) => { return })
                clearErrors()
                // let default_field = field.map((item) => (
                //     item: isEmptyValue(Customer[item.name])
                // )


                // reset({
                //     ...initialCustomer,
                // })
            }
        }
        fetchData()
    }, [CampaignId])
    return (
        <>
            {/* <Card className="mb-3" >
                <Card.Header>Customer Field</Card.Header>
                <Card.Body> */}
            {
                alert && handleAlert(alert)
            }
            <Form onSubmit={handleSubmit(onSubmitCustomer)} >
                <Form.Group as={Row} className="mb-3 ml-1 mr-1" style={{ overflowY: "scroll", maxHeight: "10.8rem" }} >
                    {!isEmptyValue(field) && field.map((item, index) =>
                        <Col sm="6" key={index}>
                            <Form.Group className="mb-3">
                                <Form.Label>{item.field_display_name}</Form.Label>
                                <Form.Control type="text" size="sm" defaultValue={!isEmptyValue(Customer[item.field_name]) ? Customer[item.field_name] : ''} {...register(item.field_name)} />
                                <Form.Text
                                    className={classnames("text-danger", {
                                        "d-none": !errors[item.field_name]
                                    })}
                                >
                                    {errors[item.field_name] ?.message}
                                </Form.Text>
                            </Form.Group>
                        </Col>
                    )}
                </Form.Group >

                <div className="col-md-12 mb-4 text-center">
                    <Button variant="primary" type="submit" >Update</Button>
                </div>
            </Form>
            {/* </Card.Body>
            </Card> */}
        </>
    )
}

// const initialCustomer = {
//     fullname: '',
//     phone_1: '',
//     phone_2: '',
//     email: '',
//     card_number: '',
//     card_type: '',
//     limit: '',
//     card_since_year: '',
//     card_since_month: '',
//     card_exp_date: '',
//     card_emboss_name: '',
//     amount: '',
//     account_no: '',
//     bank_interest: '',
//     mother_name: '',
//     age: '',
//     gender: '',
//     birth_place: '',
//     birth_date: '',
//     merchant: '',
//     transaction_date: '',
//     home_address: '',
//     home_city: '',
//     home_zip: '',
//     office_address: '',
//     office_city: '',
//     office_zip: '',
//     income: '',
//     business_type: '',
//     occupation: '',
//     ktp: '',
//     npwp: '',
//     tenor: '',
// }

const validationSchemaCustomer = yupResolver(
    yup.object().shape({
        fullname: yup.string(),
        phone_1: yup.string(),
        phone_2: yup.string(),
        email: yup.string(),
        card_number: yup.string(),
        card_type: yup.string(),
        limit: yup.string(),
        card_since_year: yup.string(),
        card_since_month: yup.string(),
        card_exp_date: yup.string(),
        card_emboss_name: yup.string(),
        amount: yup.string(),
        account_no: yup.number().transform(cv => isNaN(cv) ? undefined : cv).positive().integer(),
        bank_interest: yup.string(),
        mother_name: yup.string(),
        age: yup.number().transform(cv => isNaN(cv) ? undefined : cv).positive().integer(),
        gender: yup.string(),
        birth_place: yup.string(),
        birth_date: yup.string(),
        merchant: yup.string(),
        transaction_date: yup.string(),
        home_address: yup.string(),
        home_city: yup.string(),
        home_zip: yup.string(),
        office_address: yup.string(),
        office_city: yup.string(),
        office_zip: yup.string(),
        income: yup.string(),
        business_type: yup.string(),
        occupation: yup.string(),
        ktp: yup.string(),
        npwp: yup.string(),
        tenor: yup.string(),
    })
)