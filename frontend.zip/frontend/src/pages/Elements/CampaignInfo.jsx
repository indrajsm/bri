import React, { useEffect, useState, useContext } from 'react'
import { useCampaignInfos } from '../../utils/functions';
import { Form } from 'react-bootstrap'
import ReactQuill from 'react-quill';
import Select from "react-select";
import { generalService } from '../../utils/services';

const { isEmptyValue } = generalService

export const CampaignInfo = ({ CampaignId, CurrentData, CurrentDataChange }) => {
    const { Get } = useCampaignInfos()
    const [info, setInfo] = useState({})
    const [detail, setDetail] = useState(null)

    const handleChange = async (id) => {

        await Get({ id: id }).then((res) => {
            if (!isEmptyValue(res.data)) {
                setDetail(res.data.info)
                CurrentDataChange({ campaign_info: id, detail: res.data.info })
            }
        }).catch((err) => { return })
    }

    useEffect(() => {
        const fetchData = async () => {

            await Get({
                campaign_id: CampaignId,
                limit: "100",
                order: "name",
                is_active: 1
            }).then((res) => {
                if (!isEmptyValue(res.data)) {
                    let infoOption = res.data.map((row) => {
                        return { value: row.id, label: row.name }
                    })
                    setInfo([
                        ...initialOption,
                        ...infoOption
                    ])
                }
            }).catch((err) => { return })
            CurrentData.detail && setDetail(CurrentData.detail)
        }
        fetchData()
    }, [CampaignId, CurrentData])
    return (
        <>
            {/* <Card className="mb-3" >
                <Card.Header>Campaign Info</Card.Header>
                <Card.Body> */}
            <Form.Group className="mb-3">
                <Form.Label>Name</Form.Label>
                <Select
                    options={info}
                    onChange={(selected) => handleChange(selected.value)}
                    value={!isEmptyValue(info) && info.filter((opt) => {
                        return opt.value === CurrentData.campaign_info;
                    })}
                />
            </Form.Group>
            <Form.Group  >
                <ReactQuill
                    theme="snow"
                    value={detail}
                />
            </Form.Group >
            {/* </Card.Body>
            </Card> */}
        </>
    )
}

const initialOption = [{
    value: "",
    label: "Choose..."
}]