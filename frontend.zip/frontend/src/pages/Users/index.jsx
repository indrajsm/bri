import { useState, useEffect } from 'react'
import { Button, Form, Modal, Spinner, Table } from 'react-bootstrap'
import { generalService } from './../../utils/services'
import { useDepartments, useUserLevels, useUsers } from './../../utils/functions'
import { Pagination, Notification, CustomSelect } from './../../components'
import { FormAdd } from './FormAdd'
import { FormDetail } from './FormDetail'

const { isEmptyValue } = generalService

export const Users = (props) => {
    const fnDepartments = useDepartments()
    const fnUserLevels = useUserLevels()
    const fnUsers = useUsers()
    const { Error, Success, Warning } = Notification

    const [loading, setLoading] = useState(true)
    const [notif, setNotif] = useState(initialNotif)
    const [tableData, setTableData] = useState({})
    const [modalAdd, setModalAdd] = useState(initialModal)
    const [modalDetail, setModalDetail] = useState(initialModal)
    const [formFilter, setFormFilter] = useState({
        department_id: "",
        user_level_id: "",
        username: ""
    })
    const [currentFilter, setCurrentFilter] = useState({
        page: 1,
        order: "username",
        ...formFilter
    })
    const [optionDepartment, setOptionDepartment] = useState([{
        value: "",
        label: "Choose..."
    }])
    const [optionUserLevel, setOptionUserLevel] = useState([{
        value: "",
        label: "Choose..."
    }])

    useEffect(() => {
        const fetchData = async () => {
            await fnUsers.Get(currentFilter).then((res) => {
                setTableData(res)
                setLoading(false)
            }).catch((err) => { return }) //do nothing, let it go back to login
        }

        if (loading) fetchData()
        return () => setLoading(false)
    }, [loading])

    useEffect(() => {
        const fetchData = async () => {
            await fnDepartments.Get({
                limit: 100,
                order: "name",
                is_active: 1
            }).then((res) => {
                if (!isEmptyValue(res.data)) {
                    let mapOption = res.data.map((row) => {
                        return { value: row.id, label: row.name }
                    })

                    setOptionDepartment([
                        ...optionDepartment,
                        ...mapOption
                    ])
                }
            }).catch((err) => { return }) //do nothing, let it go back to login
        }

        fetchData()
        return () => setOptionDepartment([{
            value: "",
            label: "Choose..."
        }])
    }, [])

    useEffect(() => {
        const fetchData = async () => {
            await fnUserLevels.Get({
                limit: 100,
                order: "name",
                is_active: 1
            }).then((res) => {
                if (!isEmptyValue(res.data)) {
                    let mapOption = res.data.map((row) => {
                        return { value: row.id, label: row.name }
                    })

                    setOptionUserLevel([
                        ...optionUserLevel,
                        ...mapOption
                    ])
                }
            }).catch((err) => { return }) //do nothing, let it go back to login
        }

        fetchData()
        return () => setOptionUserLevel([{
            value: "",
            label: "Choose..."
        }])
    }, [])

    const handleChangeFormFilter = (key, val) => {
        setFormFilter({ ...formFilter, [key]: val })
    }

    const handleSubmitFormFilter = (e) => {
        e.preventDefault()

        setCurrentFilter({
            ...currentFilter,
            ...formFilter,
            page: 1
        })
        setLoading(true)
    }

    const handleModalClose = () => {
        setModalAdd(initialModal)
        setModalDetail(initialModal)
    }

    const handleModalAdd = () => {
        setModalAdd({
            ...modalAdd,
            show: !modalAdd.show
        })
    }

    const handleModalDetail = (id) => {
        setModalDetail({
            ...modalDetail,
            show: !modalDetail.show,
            dataId: id
        })
    }

    return (
        <>
            <h1 className="mt-4">Setting Users</h1>
            <ol className="breadcrumb mb-4">
                <li className="breadcrumb-item">Settings</li>
                <li className="breadcrumb-item active">Users</li>
            </ol>
            {notif.show && notif.type === 'error' && <Error
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            {notif.show && notif.type === 'success' && <Success
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            {notif.show && notif.type === 'warning' && <Warning
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            <div className="card mb-4">
                <div className="card-header">
                    <i className="fas fa-table mr-1"></i> Filter Data
                </div>
                <div className="card-body">
                    <form onSubmit={handleSubmitFormFilter}>
                        <div className="form-row">
                            <Form.Group className="col-md-2" controlId="Department">
                                <Form.Label>Department</Form.Label>
                                <CustomSelect.SelectBox
                                    optionSelect={optionDepartment}
                                    onChangeValue={(value) => handleChangeFormFilter("department_id", value)}
                                    value={formFilter.department_id}
                                />
                            </Form.Group>
                            <Form.Group className="col-md-2" controlId="UserLevel">
                                <Form.Label>User Level</Form.Label>
                                <CustomSelect.SelectBox
                                    optionSelect={optionUserLevel}
                                    onChangeValue={(value) => handleChangeFormFilter("user_level_id", value)}
                                    value={formFilter.user_level_id}
                                />
                            </Form.Group>
                            <Form.Group className="col-md-2" controlId="Username">
                                <Form.Label>Username</Form.Label>
                                <Form.Control
                                    type="text"
                                    value={formFilter.username}
                                    onChange={e => handleChangeFormFilter("username", e.target.value)}
                                />
                            </Form.Group>
                        </div>
                        <div className="form-row">
                            <Form.Group className="col-md-12 mb-0">
                                <Button type="submit" variant="primary">Search</Button>
                            </Form.Group>
                        </div>
                    </form>
                </div>
            </div>
            <div className="card mb-4">
                <div className="card-body">
                    <Button variant="outline-primary" onClick={handleModalAdd}>Add Data</Button>
                    <hr />
                    <Table striped hover responsive width="100%" cellSpacing="0" cellPadding="0">
                        <thead className="thead-dark">
                            <tr>
                                <th className="text-nowrap">No.</th>
                                <th className="text-nowrap">Username</th>
                                <th className="text-nowrap">User Level</th>
                                <th className="text-nowrap">Department</th>
                                <th className="text-nowrap">Fullname</th>
                                <th className="text-nowrap">Email</th>
                                <th className="text-nowrap">Mobile Phone</th>
                                <th className="text-nowrap">Home Phone</th>
                                <th className="text-nowrap">Address</th>
                                <th className="text-nowrap">Active</th>
                                <th className="text-nowrap text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {loading &&
                                <tr>
                                    <td colSpan="9" className="text-center">
                                        <Spinner animation="border" size="sm" className="mr-1" />
                                        Loading data...
                                    </td>
                                </tr>
                            }
                            {!loading && isEmptyValue(tableData.data) &&
                                <tr>
                                    <td colSpan="9" className="text-center">
                                        <span className="text-danger">No data found</span>
                                    </td>
                                </tr>
                            }
                            {!loading && !isEmptyValue(tableData.data) &&
                                tableData.data.map((row, i) => (
                                    <tr key={ row.id }>
                                        <td>{ tableData.paging.index[i] }</td>
                                        <td>{ row.username }</td>
                                        <td>{ row.user_level }</td>
                                        <td>{ row.department }</td>
                                        <td>{ row.fullname }</td>
                                        <td>{ row.email }</td>
                                        <td>{ row.mobile }</td>
                                        <td>{ row.phone }</td>
                                        <td>{ row.address }</td>
                                        <td>{ row.is_active === 1 ? "Yes" : "No" }</td>
                                        <td className="text-center">
                                            <Button variant="warning" size="sm" className="m-1" title="Detail Data" onClick={(e) => { handleModalDetail(row.id) }}>
                                                <i className="fas fa-edit fa-fw"></i>
                                            </Button>
                                        </td>
                                    </tr>
                                ))
                            }
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>No.</th>
                                <th>Username</th>
                                <th>User Level</th>
                                <th>Department</th>
                                <th>Fullname</th>
                                <th>Email</th>
                                <th>Mobile Phone</th>
                                <th>Home Phone</th>
                                <th>Address</th>
                                <th>Active</th>
                                <th className="text-center">Action</th>
                            </tr>
                        </tfoot>
                    </Table>

                    {!loading && !isEmptyValue(tableData.paging) &&
                         <Pagination
                            total={tableData.total_data}
                            limit={tableData.limit}
                            paging={tableData.paging}
                            pageChange={(page) => {
                                setCurrentFilter({
                                    ...currentFilter,
                                    page: page
                                })
                                setLoading(true)
                            }}
                        />
                    }
                </div>
            </div>

            <Modal show={modalAdd.show} onHide={handleModalClose} backdrop="static" keyboard={false}>
                <FormAdd
                    modalChange={(params) => {
                        handleModalClose()
                    }}
                    notifChange={(params) => {
                        setNotif({
                            ...notif,
                            ...params
                        })
                    }}
                    dataChange={() => {
                        setLoading(true)
                    }}
                />
            </Modal>

            <Modal show={modalDetail.show} onHide={handleModalClose} backdrop="static" keyboard={false}>
                <FormDetail
                    modalChange={(params) => {
                        handleModalClose()
                    }}
                    notifChange={(params) => {
                        setNotif({
                            ...notif,
                            ...params
                        })
                    }}
                    dataChange={() => {
                        setLoading(true)
                    }}
                    dataId={modalDetail.dataId}
                />
            </Modal>
        </>
    )
}

const initialNotif = {
    title: "",
    message: "",
    show: false,
    type: null
}

const initialModal = {
    show: false,
    dataId: null
}