import { useState, useEffect } from 'react'
import { Button, Form, Modal, Spinner, Row } from 'react-bootstrap'
import { useForm, Controller } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import _ from 'lodash'
import { CustomSelect } from './../../components'
import { generalService } from './../../utils/services'
import { useDepartments, useUserLevels, useUsers } from './../../utils/functions'

const { isEmptyValue } = generalService

export const FormDetail = ({ modalChange, notifChange, dataChange, dataId }) => {
    const fnDepartments = useDepartments()
    const fnUserLevels = useUserLevels()
    const fnUsers = useUsers()
    const { handleSubmit, formState: { errors, isSubmitting }, control, register, reset, getValues } = useForm({
        defaultValues: initialData,
        resolver: validationSchema
    })
    const [optionDepartment, setOptionDepartment] = useState([{
        value: "",
        label: "Choose..."
    }])
    const [optionUserLevel, setOptionUserLevel] = useState([{
        value: "",
        label: "Choose..."
    }])

    useEffect(() => {
        const fetchData = async () => {
            await fnUsers.Get({id: dataId}).then((res) => {
                let mapOptionDepartment = optionDepartment.map((row) => {
                    return row.value
                })
                let mapOptionUserLevel = optionUserLevel.map((row) => {
                    return row.value
                })

                if (!isEmptyValue(res.data)) {
                    reset({
                        ...initialData,
                        username: res.data.username || "",
                        fullname: res.data.fullname || "",
                        user_level_id: (mapOptionUserLevel.includes(res.data.user_level_id)) ? res.data.user_level_id : "",
                        department_id: (mapOptionDepartment.includes(res.data.department_id)) ? res.data.department_id : "",
                        mobile: res.data.mobile || "",
                        phone: res.data.phone || "",
                        email: res.data.email || "",
                        address: res.data.address || "",
                        is_active: res.data.is_active === 1 ? "1" : false
                    }, {keepErrors: false})
                }
            }).catch((err) => { return }) //do nothing, let it go back to login
        }

        if (!isEmptyValue(dataId)) return fetchData()
    }, [dataId, optionDepartment, optionUserLevel])

    useEffect(() => {
        const fetchData = async () => {
            await fnDepartments.Get({
                limit: 100,
                order: "name",
                is_active: 1
            }).then((res) => {
                if (!isEmptyValue(res.data)) {
                    let mapOption = res.data.map((row) => {
                        return { value: row.id, label: row.name }
                    })

                    setOptionDepartment([
                        ...optionDepartment,
                        ...mapOption
                    ])
                }
            }).catch((err) => { return }) //do nothing, let it go back to login
        }

        fetchData()
        return () => setOptionDepartment([{
            value: "",
            label: "Choose..."
        }])
    }, [])

    useEffect(() => {
        const fetchData = async () => {
            await fnUserLevels.Get({
                limit: 100,
                order: "name",
                is_active: 1
            }).then((res) => {
                if (!isEmptyValue(res.data)) {
                    let mapOption = res.data.map((row) => {
                        return { value: row.id, label: row.name }
                    })

                    setOptionUserLevel([
                        ...optionUserLevel,
                        ...mapOption
                    ])
                }
            }).catch((err) => { return }) //do nothing, let it go back to login
        }

        fetchData()
        return () => setOptionUserLevel([{
            value: "",
            label: "Choose..."
        }])
    }, [])

    const onSubmitForm = async (data, e) => {
        e.preventDefault()

        Object.keys(data).forEach((key) => {
            if (['is_active'].includes(key) && data[key] === false) {
                data[key] = "0"
            }
        })

        await fnUsers.Update(dataId, data).then((res) => {
            if (res.success) {
                notifChange({
                    title: "Success",
                    message: "Data has been updated.",
                    show: true,
                    type: "success"
                })
                dataChange()
            } else {
                notifChange({
                    title: "Error",
                    message: "Failed to update data.",
                    show: true,
                    type: "error"
                })
            }

            return modalChange()
        }).catch((err) => { return }) //do nothing, let it go back to login
    }

    return (
        <>
            <Modal.Header closeButton={isSubmitting ? false : true}>
                <Modal.Title>Detail User</Modal.Title>
            </Modal.Header>
            <Form onSubmit={handleSubmit(onSubmitForm)}>
                <Modal.Body className="pb-1">
                    <Row>
                        <Form.Group className="col-md-5">
                            <Form.Label>Username <span className="text-danger">*</span></Form.Label>
                            <Form.Control
                                type="text"
                                size="sm"
                                isInvalid={!!errors.username}
                                {...register("username")}
                            />
                            <Form.Control.Feedback type="invalid">{errors.username?.message}</Form.Control.Feedback>
                        </Form.Group>
                        <Form.Group className="col-md-7">
                            <Form.Label>Fullname <span className="text-danger">*</span></Form.Label>
                            <Form.Control
                                type="text"
                                size="sm"
                                isInvalid={!!errors.fullname}
                                {...register("fullname")}
                            />
                            <Form.Control.Feedback type="invalid">{errors.fullname?.message}</Form.Control.Feedback>
                        </Form.Group>
                    </Row>
                    <Row>
                        <Form.Group className="col-md-6">
                            <Form.Label>Email</Form.Label>
                            <Form.Control
                                type="text"
                                size="sm"
                                isInvalid={!!errors.email}
                                {...register("email")}
                            />
                            <Form.Control.Feedback type="invalid">{errors.email?.message}</Form.Control.Feedback>
                        </Form.Group>
                        <Form.Group className="col-md-6">
                            <Form.Label>User Level <span className="text-danger">*</span></Form.Label>
                            <Controller
                                name={"user_level_id"}
                                control={control}
                                render={({ field: {value, onChange} }) => {
                                    return (
                                        <CustomSelect.SelectBox
                                            optionSelect={optionUserLevel}
                                            onChangeValue={(value) => onChange(value)}
                                            value={getValues('user_level_id')}
                                            isError={!!errors.user_level_id ? true : false}
                                            isSmall={true}
                                        />
                                    )
                                }}
                            />
                            <Form.Control.Feedback type="invalid">{errors.user_level_id?.message}</Form.Control.Feedback>
                        </Form.Group>
                    </Row>
                    <Form.Group>
                        <Form.Label>Department <span className="text-danger">*</span></Form.Label>
                        <Controller
                            name={"department_id"}
                            control={control}
                            render={({ field: {value, onChange} }) => {
                                return (
                                    <CustomSelect.SelectBox
                                        optionSelect={optionDepartment}
                                        onChangeValue={(value) => onChange(value)}
                                        value={getValues('department_id')}
                                        isError={!!errors.department_id ? true : false}
                                        isSmall={true}
                                    />
                                )
                            }}
                        />
                        <Form.Control.Feedback type="invalid">{errors.department_id?.message}</Form.Control.Feedback>
                    </Form.Group>
                    <Row>
                        <Form.Group className="col-md-6">
                            <Form.Label>Mobile Phone</Form.Label>
                            <Form.Control
                                type="text"
                                size="sm"
                                isInvalid={!!errors.mobile}
                                {...register("mobile")}
                            />
                            <Form.Control.Feedback type="invalid">{errors.mobile?.message}</Form.Control.Feedback>
                        </Form.Group>
                        <Form.Group className="col-md-6">
                            <Form.Label>Home Phone</Form.Label>
                            <Form.Control
                                type="text"
                                size="sm"
                                isInvalid={!!errors.phone}
                                {...register("phone")}
                            />
                            <Form.Control.Feedback type="invalid">{errors.phone?.message}</Form.Control.Feedback>
                        </Form.Group>
                    </Row>
                    <Form.Group>
                        <Form.Label>Address</Form.Label>
                        <Form.Control
                            as="textarea"
                            size="sm"
                            rows={2}
                            isInvalid={!!errors.address}
                            {...register("address")}
                        />
                        <Form.Control.Feedback type="invalid">{errors.address?.message}</Form.Control.Feedback>
                    </Form.Group>
                    <Form.Group controlId="IsActive">
                        <Form.Check
                            type="checkbox"
                            label="Active"
                            custom
                            value="1"
                            // isInvalid={!!errors.is_active}
                            // feedback={errors.is_active?.message}
                            {...register("is_active")}
                        />
                    </Form.Group>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="primary" type="submit" disabled={isSubmitting}>
                        {isSubmitting && <Spinner animation="border" size="sm" className="mr-1" />} Save
                    </Button>
                    <Button variant="light" disabled={isSubmitting} onClick={modalChange}>Close</Button>
                </Modal.Footer>
            </Form>
        </>
    )
}

const initialData = {
    username: "",
    fullname: "",
    user_level_id: "",
    department_id: "",
    mobile: "",
    phone: "",
    email: "",
    address: "",
    is_active: "1"
}

const validationSchema = yupResolver(yup.object().shape({
    username: yup.string()
        .required("This field is required.")
        .min(6, "This field must be at least 6 characters in length."),
    fullname: yup.string()
        .required("This field is required."),
    user_level_id: yup.string()
        .required("This field is required."),
    department_id: yup.string()
        .required("This field is required."),
    mobile: yup.string()
        // .required("This field is required.")
        .matches(/^[0-9]+$/, { message: "This field is invalid.", excludeEmptyString: true }),
    phone: yup.string()
        // .required("This field is required.")
        .matches(/^[0-9]+$/, { message: "This field is invalid.", excludeEmptyString: true }),
    email: yup.string()
        // .required("This field is required.")
        .email("This field must contain a valid email address."),
    // address: yup.string()
    //     .required("This field is required."),
    // is_active: yup.string().oneOf(["1"], "This checkbox is required.")
}))