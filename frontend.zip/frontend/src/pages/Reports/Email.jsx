import { useState, useEffect } from 'react'
import { Card, Button, Form, Table, Spinner, Modal } from 'react-bootstrap'
import _ from 'lodash'
import DatePicker from 'react-datepicker'
import { saveAs } from 'file-saver'
import { generalService } from './../../utils/services'
import { useCampaigns, useEmails, useExports } from './../../utils/functions'
import { Pagination, Notification, CustomSelect } from './../../components'
import { Markup } from 'interweave'

const { isEmptyValue, formatDate, sleep } = generalService

export const ReportEmail = (props) => {
    const fnCampaigns = useCampaigns()
    const fnEmails = useEmails()
    const fnExports = useExports()
    const { Error, Success, Warning } = Notification

    const [loading, setLoading] = useState(true)
    const [exporting, setExporting] = useState(false)
    const [notif, setNotif] = useState(initialNotif)
    const [tableData, setTableData] = useState({})
    const [formFilter, setFormFilter] = useState({
        campaign_id: "",
        start: formatDate(),
        end: formatDate(),
        disable_date: false
    })
    const [currentFilter, setCurrentFilter] = useState({
        page: 1,
        order: "mail_date",
        sort: "desc",
        ...formFilter
    })
    const [optionCampaign, setOptionCampaign] = useState(initialOption)
    const [modalViewContent, setModalViewContent] = useState({
        show: false,
        dataContent: null
    })

    useEffect(() => {
        const fetchData = async () => {
            await fnEmails.GetReportEmail(currentFilter).then((res) => {
                setTableData(res)
                setLoading(false)
            }).catch((err) => { return }) //do nothing, let it go back to login
        }

        if (loading) fetchData()
        return () => setLoading(false)
    }, [loading])

    useEffect(() => {
        const fetchData = async () => {
            await fnCampaigns.Get({
                limit: 100,
                order: "name"
            }).then((res) => {
                if (!isEmptyValue(res.data)) {
                    let mapOptionCampaigns = res.data.map((row) => {
                        return { value: row.id, label: row.name }
                    })

                    setOptionCampaign([
                        ...optionCampaign,
                        ...mapOptionCampaigns
                    ])
                }
            }).catch((err) => { return }) //do nothing, let it go back to login
        }

        fetchData()
        return () => setOptionCampaign(initialOption)
    }, [])

    const handleChangeFormFilter = (key, val) => {
        if (key === 'start' && new Date(val) > new Date(formFilter.end)) {
            setFormFilter({
                ...formFilter,
                start: val,
                end: val
            })
        } else {
            setFormFilter({ ...formFilter, [key]: val })
        }
    }

    const handleSubmitFormFilter = (e) => {
        e.preventDefault()

        setCurrentFilter({
            ...currentFilter,
            ...formFilter,
            page: 1
        })
        setLoading(true)
    }

    const handleExport = async (limitData = false) => {
        await fnExports.ReportEmail({
            ...currentFilter,
            limit: limitData || 20
        }).then(async (res) => {
            await sleep(5000)
            setExporting(false)

            if (res.success) {
                setNotif({
                    ...notif,
                    title: "Success",
                    message: "Export data success.",
                    show: true,
                    type: "success"
                })

                return saveAs(res.data.url, res.data.filename)
            }

            return setNotif({
                ...notif,
                title: "Error",
                message: "Failed to export data.",
                show: true,
                type: "error"
            })
        }).catch((err) => { return }) //do nothing, let it go back to login
    }

    const handlemodalViewContent = (content = null) => {
        setModalViewContent({
            ...modalViewContent,
            show: !modalViewContent.show,
            dataContent: content || null
        })
    }

    return (
        <>
            <h1 className="mt-4">Report Email</h1>
            <ol className="breadcrumb mb-4">
                <li className="breadcrumb-item">Reports</li>
                <li className="breadcrumb-item active">Email</li>
            </ol>
            {notif.show && notif.type === 'error' && <Error
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            {notif.show && notif.type === 'success' && <Success
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            {notif.show && notif.type === 'warning' && <Warning
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            <Card className="mb-4">
                <Card.Header>
                    <i className="fas fa-table mr-1"></i> Filter Data
                </Card.Header>
                <Card.Body>
                    <Form onSubmit={handleSubmitFormFilter}>
                        <Form.Row>
                            <Form.Group className="col-md-2" controlId="DisableDate">
                                <Form.Label>Disable Date</Form.Label>
                                <br />
                                <Button variant="outline-info" onClick={() => handleChangeFormFilter("disable_date", !formFilter.disable_date)}>
                                    <i className={`far ${formFilter.disable_date ? "fa-check-square" : "fa-square"}`} />
                                </Button>
                            </Form.Group>
                            <Form.Group className="col-md-2" controlId="StartDate">
                                <Form.Label>From Date</Form.Label>
                                <DatePicker
                                    className="form-control"
                                    dateFormat="yyyy-MM-dd"
                                    selected={new Date(formFilter.start)}
                                    disabledKeyboardNavigation
                                    onChange={(date) => handleChangeFormFilter("start", formatDate(date) === false ? formatDate() : formatDate(date))}
                                    highlightDates={[new Date(), new Date()]}
                                    disabled={formFilter.disable_date}
                                />
                            </Form.Group>
                            <Form.Group className="col-md-2" controlId="EndDate">
                                <Form.Label>To Date</Form.Label>
                                <DatePicker
                                    className="form-control"
                                    dateFormat="yyyy-MM-dd"
                                    disabledKeyboardNavigation
                                    selected={new Date(formFilter.end)}
                                    onChange={(date) => handleChangeFormFilter("end", formatDate(date) === false ? formFilter.start : formatDate(date))}
                                    highlightDates={[new Date(), new Date()]}
                                    minDate={new Date(formFilter.start)}
                                    disabled={formFilter.disable_date}
                                />
                            </Form.Group>
                            <Form.Group className="col-md-2" controlId="Campaign">
                                <Form.Label>Campaign</Form.Label>
                                <CustomSelect.SelectBox
                                    optionSelect={optionCampaign}
                                    onChangeValue={(value) => handleChangeFormFilter("campaign_id", value)}
                                    value={formFilter.campaign_id}
                                />
                            </Form.Group>
                        </Form.Row>
                        <Form.Row>
                            <Form.Group className="col-md-12 mb-0">
                                <Button type="submit" variant="primary">Search</Button>
                            </Form.Group>
                        </Form.Row>
                    </Form>
                </Card.Body>
            </Card>
            <Card className="mb-4">
                <Card.Body>
                    <Button variant="outline-secondary" onClick={() => {
                        setExporting(true)
                        handleExport(tableData.total_data)
                    }} disabled={!exporting && !loading && !isEmptyValue(tableData.data) ? false : true}>
                        {exporting && <Spinner animation="border" size="sm" className="mr-1" />} Export
                    </Button>
                    <hr />
                    <Table striped hover responsive width="100%">
                        <thead className="thead-dark">
                            <tr>
                                <th className="text-nowrap">No.</th>
                                <th className="text-nowrap">Sent Date</th>
                                <th className="text-nowrap">Email Status</th>
                                <th className="text-nowrap">Campaign Name</th>
                                <th className="text-nowrap">Recipient</th>
                                <th className="text-nowrap">Subject</th>
                                <th className="text-nowrap">Content</th>
                            </tr>
                        </thead>
                        <tbody>
                            {loading &&
                                <tr>
                                    <td colSpan="6" className="text-center">
                                        <Spinner animation="border" size="sm" className="mr-1" />
                                        Loading data...
                                    </td>
                                </tr>
                            }
                            {!loading && isEmptyValue(tableData.data) &&
                                <tr>
                                    <td colSpan="6" className="text-center">
                                        <span className="text-danger">No data found</span>
                                    </td>
                                </tr>
                            }
                            {!loading && !isEmptyValue(tableData.data) &&
                                tableData.data.map((row, i) => (
                                    <tr key={ i }>
                                        <td>{ tableData.paging.index[i] }</td>
                                        <td>{ row.sent_date }</td>
                                        <td>{ row.email_status }</td>
                                        <td>{ row.campaign_name }</td>
                                        <td>{ row.email_to }</td>
                                        <td>{ row.subject }</td>
                                        <td>
                                            <Button variant="info" size="sm" className="m-1" onClick={(e) => { handlemodalViewContent(row.content) }}>
                                                View
                                            </Button>
                                        </td>
                                    </tr>
                                ))
                            }
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>No.</th>
                                <th>Sent Date</th>
                                <th>Email Status</th>
                                <th>Campaign Name</th>
                                <th>Recipient</th>
                                <th>Subject</th>
                                <th>Content</th>
                            </tr>
                        </tfoot>
                    </Table>

                    {!loading && !isEmptyValue(tableData.paging) &&
                         <Pagination
                            total={tableData.total_data}
                            limit={tableData.limit}
                            paging={tableData.paging}
                            pageChange={(page) => {
                                setCurrentFilter({
                                    ...currentFilter,
                                    page: page
                                })
                                setLoading(true)
                            }}
                        />
                    }
                </Card.Body>
            </Card>

            <Modal show={modalViewContent.show} onHide={handlemodalViewContent} size="lg" scrollable>
                <Modal.Header closeButton>
                    <Modal.Title>Email Content</Modal.Title>
                </Modal.Header>
                <Modal.Body style={{background: "rgba(243, 243, 250, 0.8)", wordWrap: "break-word"}}>
                    <Markup content={modalViewContent.dataContent} className="blockquote" />
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="light" onClick={(e) => handlemodalViewContent()}>Close</Button>
                </Modal.Footer>
            </Modal>
        </>
    )
}

const initialNotif = {
    title: "",
    message: "",
    show: false,
    type: null
}

const initialOption = [{
    value: "",
    label: "Choose..."
}]