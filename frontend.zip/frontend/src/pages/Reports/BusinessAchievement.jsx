import { useState, useEffect } from 'react'
import { Card, Button, Form, Table, Spinner } from 'react-bootstrap'
import _ from 'lodash'
import { saveAs } from 'file-saver'
import { generalService } from './../../utils/services'
import { useCalls, useCampaigns, useExports, useUsers } from './../../utils/functions'
import { Pagination, Notification, CustomSelect } from './../../components'

const { isEmptyValue, sleep } = generalService

export const ReportBusinessAchievement = (props) => {
    const fnCalls = useCalls()
    const fnCampaigns = useCampaigns()
    const fnExports = useExports()
    const fnUsers = useUsers()
    const { Error, Success, Warning } = Notification

    const [loading, setLoading] = useState(true)
    const [exporting, setExporting] = useState(false)
    const [notif, setNotif] = useState(initialNotif)
    const [tableData, setTableData] = useState({})
    const [formFilter, setFormFilter] = useState({
        user_id: "",
        campaign_id: ""
    })
    const [currentFilter, setCurrentFilter] = useState({
        page: 1,
        ...formFilter
    })
    const [optionAgent, setOptionAgent] = useState([{
        value: "",
        label: "Choose..."
    }])
    const [optionCampaign, setOptionCampaign] = useState([{
        value: "",
        label: "Choose..."
    }])

    useEffect(() => {
        const fetchData = async () => {
            await fnCalls.GetReportBusinessAchievement(currentFilter).then((res) => {
                setTableData(res)
                setLoading(false)
            }).catch((err) => { return }) //do nothing, let it go back to login
        }

        if (loading) fetchData()
        return () => setLoading(false)
    }, [loading])

    useEffect(() => {
        const fetchData = async () => {
            await fnUsers.Get({
                limit: 100,
                order: "username",
                is_active: 1
            }).then((res) => {
                if (!isEmptyValue(res.data)) {
                    let mapOption = res.data.map((row) => {
                        return { value: row.id, label: row.username }
                    })

                    setOptionAgent([
                        ...optionAgent,
                        ...mapOption
                    ])
                }
            }).catch((err) => { return }) //do nothing, let it go back to login
        }

        fetchData()
        return () => setOptionAgent([{
            value: "",
            label: "Choose..."
        }])
    }, [])

    useEffect(() => {
        const fetchData = async () => {
            await fnCampaigns.Get({
                limit: 100,
                order: "name"
            }).then((res) => {
                if (!isEmptyValue(res.data)) {
                    let mapOption = res.data.map((row) => {
                        return { value: row.id, label: row.name }
                    })

                    setOptionCampaign([
                        ...optionCampaign,
                        ...mapOption
                    ])
                }
            }).catch((err) => { return }) //do nothing, let it go back to login
        }

        fetchData()
        return () => setOptionCampaign([{
            value: "",
            label: "Choose..."
        }])
    }, [])

    const handleChangeFormFilter = (key, val) => {
        setFormFilter({ ...formFilter, [key]: val })
    }

    const handleSubmitFormFilter = (e) => {
        e.preventDefault()

        setCurrentFilter({
            ...currentFilter,
            ...formFilter,
            page: 1
        })
        setLoading(true)
    }

    const handleExport = async (limitData = false) => {
        await fnExports.ReportBusinessAchievement({
            ...currentFilter,
            limit: limitData || 20
        }).then(async (res) => {
            await sleep(5000)
            setExporting(false)

            if (res.success) {
                setNotif({
                    ...notif,
                    title: "Success",
                    message: "Export data success.",
                    show: true,
                    type: "success"
                })

                return saveAs(res.data.url, res.data.filename)
            }

            return setNotif({
                ...notif,
                title: "Error",
                message: "Failed to export data.",
                show: true,
                type: "error"
            })
        }).catch((err) => { return }) //do nothing, let it go back to login
    }

    return (
        <>
            <h1 className="mt-4">Report Business Achievement</h1>
            <ol className="breadcrumb mb-4">
                <li className="breadcrumb-item">Reports</li>
                <li className="breadcrumb-item active">Business Achievement</li>
            </ol>
            {notif.show && notif.type === 'error' && <Error
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            {notif.show && notif.type === 'success' && <Success
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            {notif.show && notif.type === 'warning' && <Warning
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            <Card className="mb-4">
                <Card.Header>
                    <i className="fas fa-table mr-1"></i> Filter Data
                </Card.Header>
                <Card.Body>
                    <Form onSubmit={handleSubmitFormFilter}>
                        <Form.Row>
                            <Form.Group className="col-md-2" controlId="Agent">
                                <Form.Label>Agent</Form.Label>
                                <CustomSelect.SelectBox
                                    optionSelect={optionAgent}
                                    onChangeValue={(value) => handleChangeFormFilter("user_id", value)}
                                    value={formFilter.user_id}
                                />
                            </Form.Group>
                            <Form.Group className="col-md-2" controlId="Campaign">
                                <Form.Label>Campaign</Form.Label>
                                <CustomSelect.SelectBox
                                    optionSelect={optionCampaign}
                                    onChangeValue={(value) => handleChangeFormFilter("campaign_id", value)}
                                    value={formFilter.campaign_id}
                                />
                            </Form.Group>
                        </Form.Row>
                        <Form.Row>
                            <Form.Group className="col-md-12 mb-0">
                                <Button type="submit" variant="primary">Search</Button>
                            </Form.Group>
                        </Form.Row>
                    </Form>
                </Card.Body>
            </Card>
            <Card className="mb-4">
                <Card.Body>
                    <Button variant="outline-secondary" onClick={() => {
                        setExporting(true)
                        handleExport(tableData.total_data)
                    }} disabled={!exporting && !loading && !isEmptyValue(tableData.data) ? false : true}>
                        {exporting && <Spinner animation="border" size="sm" className="mr-1" />} Export
                    </Button>
                    <hr />
                    <Table striped hover responsive width="100%">
                        <thead className="thead-dark">
                            <tr>
                                <th className="text-nowrap">No.</th>
                                <th className="text-nowrap">Agent</th>
                                <th className="text-nowrap">Campaign Name</th>
                                <th className="text-nowrap">Number Customer Approved</th>
                                <th className="text-nowrap">Nominal</th>
                                <th className="text-nowrap">Average Customer Nominal Approved</th>
                            </tr>
                        </thead>
                        <tbody>
                            {loading &&
                                <tr>
                                    <td colSpan="6" className="text-center">
                                        <Spinner animation="border" size="sm" className="mr-1" />
                                        Loading data...
                                    </td>
                                </tr>
                            }
                            {!loading && isEmptyValue(tableData.data) &&
                                <tr>
                                    <td colSpan="6" className="text-center">
                                        <span className="text-danger">No data found</span>
                                    </td>
                                </tr>
                            }
                            {!loading && !isEmptyValue(tableData.data) &&
                                tableData.data.map((row, i) => (
                                    <tr key={ i }>
                                        <td>{ tableData.paging.index[i] }</td>
                                        <td>{ row.username }</td>
                                        <td>{ row.campaign_name }</td>
                                        <td>{ row.number_customer_approved }</td>
                                        <td>{ row.nominal }</td>
                                        <td>{ row.average_customer_nominal_approved }</td>
                                    </tr>
                                ))
                            }
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>No.</th>
                                <th>Agent</th>
                                <th>Campaign Name</th>
                                <th>Number Customer Approved</th>
                                <th>Nominal</th>
                                <th>Average Customer Nominal Approved</th>
                            </tr>
                        </tfoot>
                    </Table>

                    {!loading && !isEmptyValue(tableData.paging) &&
                         <Pagination
                            total={tableData.total_data}
                            limit={tableData.limit}
                            paging={tableData.paging}
                            pageChange={(page) => {
                                setCurrentFilter({
                                    ...currentFilter,
                                    page: page
                                })
                                setLoading(true)
                            }}
                        />
                    }
                </Card.Body>
            </Card>
        </>
    )
}

const initialNotif = {
    title: "",
    message: "",
    show: false,
    type: null
}