import { useState, useEffect } from 'react'
import { Card, Button, Form, Table, Spinner } from 'react-bootstrap'
import _ from 'lodash'
import DatePicker from 'react-datepicker'
import { saveAs } from 'file-saver'
import { generalService } from './../../utils/services'
import { useCalls, useExports, useUsers } from './../../utils/functions'
import { Pagination, Notification, CustomSelect } from './../../components'

const { isEmptyValue, formatDate, sleep } = generalService

export const ReportCallActivity = (props) => {
    const fnCalls = useCalls()
    const fnExports = useExports()
    const fnUsers = useUsers()
    const { Error, Success, Warning } = Notification

    const [loading, setLoading] = useState(true)
    const [exporting, setExporting] = useState(false)
    const [notif, setNotif] = useState(initialNotif)
    const [tableData, setTableData] = useState({})
    const [formFilter, setFormFilter] = useState({
        user_id: "",
        date: formatDate(),
    })
    const [currentFilter, setCurrentFilter] = useState({
        page: 1,
        order: "login_time",
        sort: "desc",
        ...formFilter
    })
    const [optionAgent, setOptionAgent] = useState([{
        value: "",
        label: "Choose..."
    }])

    useEffect(() => {
        const fetchData = async () => {
            await fnCalls.GetReportCallActivity(currentFilter).then((res) => {
                setTableData(res)
                setLoading(false)
            }).catch((err) => { return }) //do nothing, let it go back to login
        }

        if (loading) fetchData()
        return () => setLoading(false)
    }, [loading])

    useEffect(() => {
        const fetchData = async () => {
            await fnUsers.Get({
                limit: 100,
                order: "username",
                is_active: 1
            }).then((res) => {
                if (!isEmptyValue(res.data)) {
                    let mapOptionAgent = res.data.map((row) => {
                        return { value: row.id, label: row.username }
                    })

                    setOptionAgent([
                        ...optionAgent,
                        ...mapOptionAgent
                    ])
                }
            }).catch((err) => { return }) //do nothing, let it go back to login
        }

        fetchData()
        return () => setOptionAgent([{
            value: "",
            label: "Choose..."
        }])
    }, [])

    const handleChangeFormFilter = (key, val) => {
        setFormFilter({ ...formFilter, [key]: val })
    }

    const handleSubmitFormFilter = (e) => {
        e.preventDefault()

        setCurrentFilter({
            ...currentFilter,
            ...formFilter,
            page: 1
        })
        setLoading(true)
    }

    const handleExport = async (limitData = false) => {
        await fnExports.ReportCallActivity({
            ...currentFilter,
            limit: limitData || 20
        }).then(async (res) => {
            await sleep(5000)
            setExporting(false)

            if (res.success) {
                setNotif({
                    ...notif,
                    title: "Success",
                    message: "Export data success.",
                    show: true,
                    type: "success"
                })

                return saveAs(res.data.url, res.data.filename)
            }

            return setNotif({
                ...notif,
                title: "Error",
                message: "Failed to export data.",
                show: true,
                type: "error"
            })
        }).catch((err) => { return }) //do nothing, let it go back to login
    }

    return (
        <>
            <h1 className="mt-4">Report Call Activity</h1>
            <ol className="breadcrumb mb-4">
                <li className="breadcrumb-item">Reports</li>
                <li className="breadcrumb-item active">Call Activity</li>
            </ol>
            {notif.show && notif.type === 'error' && <Error
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            {notif.show && notif.type === 'success' && <Success
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            {notif.show && notif.type === 'warning' && <Warning
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            <Card className="mb-4">
                <Card.Header>
                    <i className="fas fa-table mr-1"></i> Filter Data
                </Card.Header>
                <Card.Body>
                    <Form onSubmit={handleSubmitFormFilter}>
                        <Form.Row>
                            <Form.Group className="col-md-2" controlId="LoginDate">
                                <Form.Label>Login Date</Form.Label>
                                <DatePicker
                                    className="form-control"
                                    dateFormat="yyyy-MM-dd"
                                    selected={new Date(formFilter.date)}
                                    disabledKeyboardNavigation
                                    onChange={(date) => handleChangeFormFilter("date", formatDate(date) === false ? formatDate() : formatDate(date))}
                                    highlightDates={[new Date(), new Date()]}
                                />
                            </Form.Group>
                            <Form.Group className="col-md-2" controlId="Agent">
                                <Form.Label>Agent</Form.Label>
                                <CustomSelect.SelectBox
                                    optionSelect={optionAgent}
                                    onChangeValue={(value) => handleChangeFormFilter("user_id", value)}
                                    value={formFilter.user_id}
                                />
                            </Form.Group>
                        </Form.Row>
                        <Form.Row>
                            <Form.Group className="col-md-12 mb-0">
                                <Button type="submit" variant="primary">Search</Button>
                            </Form.Group>
                        </Form.Row>
                    </Form>
                </Card.Body>
            </Card>
            <Card className="mb-4">
                <Card.Body>
                    <Button variant="outline-secondary" onClick={() => {
                        setExporting(true)
                        handleExport(tableData.total_data)
                    }} disabled={!exporting && !loading && !isEmptyValue(tableData.data) ? false : true}>
                        {exporting && <Spinner animation="border" size="sm" className="mr-1" />} Export
                    </Button>
                    <hr />
                    <Table striped hover responsive width="100%">
                        <thead className="thead-dark">
                            <tr>
                                <th style={{whiteSpace: "nowrap", paddingTop: "0.3em", paddingBottom: "0.3em"}} rowSpan="2">No.</th>
                                <th style={{whiteSpace: "nowrap", paddingTop: "0.3em", paddingBottom: "0.3em"}} rowSpan="2">Name</th>
                                <th style={{whiteSpace: "nowrap", paddingTop: "0.3em", paddingBottom: "0.3em"}} rowSpan="2">ID</th>
                                <th style={{whiteSpace: "nowrap", paddingTop: "0.3em", paddingBottom: "0.3em"}} rowSpan="2">Login Time</th>
                                <th style={{whiteSpace: "nowrap", paddingTop: "0.3em", paddingBottom: "0.3em"}} rowSpan="2">Logout Time</th>
                                <th style={{whiteSpace: "nowrap", paddingTop: "0.3em", paddingBottom: "0.3em"}} rowSpan="2">Available Time</th>
                                <th style={{whiteSpace: "nowrap", paddingTop: "0.3em", paddingBottom: "0.3em"}} rowSpan="2">Talk Time</th>
                                <th style={{whiteSpace: "nowrap", paddingTop: "0.3em", paddingBottom: "0.3em", textAlign: "center", borderBottom: "1px solid #fff"}} colSpan="4">Aux Time</th>
                            </tr>
                            <tr>
                                <th style={{whiteSpace: "nowrap", paddingTop: "0.3em", paddingBottom: "0.3em"}}>Rest Room</th>
                                <th style={{whiteSpace: "nowrap", paddingTop: "0.3em", paddingBottom: "0.3em"}}>Pray Time</th>
                                <th style={{whiteSpace: "nowrap", paddingTop: "0.3em", paddingBottom: "0.3em"}}>Coaching Time</th>
                                <th style={{whiteSpace: "nowrap", paddingTop: "0.3em", paddingBottom: "0.3em"}}>Break Time</th>
                            </tr>
                        </thead>
                        <tbody>
                            {loading &&
                                <tr>
                                    <td colSpan="11" className="text-center">
                                        <Spinner animation="border" size="sm" className="mr-1" />
                                        Loading data...
                                    </td>
                                </tr>
                            }
                            {!loading && isEmptyValue(tableData.data) &&
                                <tr>
                                    <td colSpan="11" className="text-center">
                                        <span className="text-danger">No data found</span>
                                    </td>
                                </tr>
                            }
                            {!loading && !isEmptyValue(tableData.data) &&
                                tableData.data.map((row, i) => (
                                    <tr key={ i }>
                                        <td>{ tableData.paging.index[i] }</td>
                                        <td>{ row.username }</td>
                                        <td>{ row.user_id }</td>
                                        <td className="text-nowrap">{ row.login_time }</td>
                                        <td className="text-nowrap">{ row.logout_time }</td>
                                        <td>{ row.available_duration }</td>
                                        <td>{ row.talk_time }</td>
                                        <td>{ row.rest_room }</td>
                                        <td>{ row.pray_time }</td>
                                        <td>{ row.coaching_time }</td>
                                        <td>{ row.break_time }</td>
                                    </tr>
                                ))
                            }
                        </tbody>
                        <tfoot>
                            <tr>
                                <th style={{whiteSpace: "nowrap", paddingTop: "0.3em", paddingBottom: "0.3em"}} rowSpan="2">No.</th>
                                <th style={{whiteSpace: "nowrap", paddingTop: "0.3em", paddingBottom: "0.3em"}} rowSpan="2">Name</th>
                                <th style={{whiteSpace: "nowrap", paddingTop: "0.3em", paddingBottom: "0.3em"}} rowSpan="2">ID</th>
                                <th style={{whiteSpace: "nowrap", paddingTop: "0.3em", paddingBottom: "0.3em"}} rowSpan="2">Login Time</th>
                                <th style={{whiteSpace: "nowrap", paddingTop: "0.3em", paddingBottom: "0.3em"}} rowSpan="2">Logout Time</th>
                                <th style={{whiteSpace: "nowrap", paddingTop: "0.3em", paddingBottom: "0.3em"}} rowSpan="2">Available Time</th>
                                <th style={{whiteSpace: "nowrap", paddingTop: "0.3em", paddingBottom: "0.3em"}} rowSpan="2">Talk Time</th>
                                <th style={{whiteSpace: "nowrap", paddingTop: "0.3em", paddingBottom: "0.3em"}}>Rest Room</th>
                                <th style={{whiteSpace: "nowrap", paddingTop: "0.3em", paddingBottom: "0.3em"}}>Pray Time</th>
                                <th style={{whiteSpace: "nowrap", paddingTop: "0.3em", paddingBottom: "0.3em"}}>Coaching Time</th>
                                <th style={{whiteSpace: "nowrap", paddingTop: "0.3em", paddingBottom: "0.3em"}}>Break Time</th>
                            </tr>
                            <tr>
                                <th style={{whiteSpace: "nowrap", paddingTop: "0.3em", paddingBottom: "0.3em", textAlign: "center", borderTop: "1px solid #000"}} colSpan="4">Aux Time</th>
                            </tr>
                        </tfoot>
                    </Table>

                    {!loading && !isEmptyValue(tableData.paging) &&
                         <Pagination
                            total={tableData.total_data}
                            limit={tableData.limit}
                            paging={tableData.paging}
                            pageChange={(page) => {
                                setCurrentFilter({
                                    ...currentFilter,
                                    page: page
                                })
                                setLoading(true)
                            }}
                        />
                    }
                </Card.Body>
            </Card>
        </>
    )
}

const initialNotif = {
    title: "",
    message: "",
    show: false,
    type: null
}