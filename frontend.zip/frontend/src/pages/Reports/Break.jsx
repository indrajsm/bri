import { useState, useEffect } from 'react'
import { Card, Button, Form, Table, Spinner } from 'react-bootstrap'
import _ from 'lodash'
import DatePicker from 'react-datepicker'
import { saveAs } from 'file-saver'
import { generalService } from './../../utils/services'
import { useBreakHistories, useBreakReasons, useExports, useUsers } from './../../utils/functions'
import { Pagination, Notification, CustomSelect } from './../../components'

const { isEmptyValue, formatDate, sleep } = generalService

export const ReportBreak = (props) => {
    const fnBreakHistories = useBreakHistories()
    const fnBreakReasons = useBreakReasons()
    const fnExports = useExports()
    const fnUsers = useUsers()
    const { Error, Success, Warning } = Notification

    const [loading, setLoading] = useState(true)
    const [exporting, setExporting] = useState(false)
    const [notif, setNotif] = useState(initialNotif)
    const [tableData, setTableData] = useState({})
    const [formFilter, setFormFilter] = useState({
        user_id: "",
        break_reason_id: "",
        start: formatDate(),
        end: formatDate(),
        disable_date: false
    })
    const [currentFilter, setCurrentFilter] = useState({
        page: 1,
        ...formFilter
    })
    const [optionAgent, setOptionAgent] = useState([{
        value: "",
        label: "Choose..."
    }])
    const [optionReason, setOptionReason] = useState([{
        value: "",
        label: "Choose..."
    }])

    useEffect(() => {
        const fetchData = async () => {
            await fnBreakHistories.GetReportBreak(currentFilter).then((res) => {
                setTableData(res)
                setLoading(false)
            }).catch((err) => { return }) //do nothing, let it go back to login
        }

        if (loading) fetchData()
        return () => setLoading(false)
    }, [loading])

    useEffect(() => {
        const fetchData = async () => {
            await fnUsers.Get({
                limit: 100,
                order: "username",
                is_active: 1
            }).then((res) => {
                if (!isEmptyValue(res.data)) {
                    let mapOptionAgent = res.data.map((row) => {
                        return { value: row.id, label: row.username }
                    })

                    setOptionAgent([
                        ...optionAgent,
                        ...mapOptionAgent
                    ])
                }
            }).catch((err) => { return }) //do nothing, let it go back to login

            await fnBreakReasons.Get({
                limit: 100,
                order: "name",
                is_active: 1
            }).then((res) => {
                if (!isEmptyValue(res.data)) {
                    let mapOptionReason = res.data.map((row) => {
                        return { value: row.id, label: row.name }
                    })

                    setOptionReason([
                        ...optionReason,
                        ...mapOptionReason
                    ])
                }
            }).catch((err) => { return }) //do nothing, let it go back to login
        }

        fetchData()
        return () => {
            setOptionAgent([{
                value: "",
                label: "Choose..."
            }])
            setOptionReason([{
                value: "",
                label: "Choose..."
            }])
        }
    }, [])

    const handleChangeFormFilter = (key, val) => {
        if (key === 'start' && new Date(val) > new Date(formFilter.end)) {
            setFormFilter({
                ...formFilter,
                start: val,
                end: val
            })
        } else {
            setFormFilter({ ...formFilter, [key]: val })
        }
    }

    const handleSubmitFormFilter = (e) => {
        e.preventDefault()

        setCurrentFilter({
            ...currentFilter,
            ...formFilter,
            page: 1
        })
        setLoading(true)
    }

    const handleExport = async (limitData = false) => {
        await fnExports.ReportBreak({
            ...currentFilter,
            limit: limitData || 20
        }).then(async (res) => {
            await sleep(5000)
            setExporting(false)

            if (res.success) {
                setNotif({
                    ...notif,
                    title: "Success",
                    message: "Export data success.",
                    show: true,
                    type: "success"
                })

                return saveAs(res.data.url, res.data.filename)
            }

            return setNotif({
                ...notif,
                title: "Error",
                message: "Failed to export data.",
                show: true,
                type: "error"
            })
        }).catch((err) => { return }) //do nothing, let it go back to login
    }

    return (
        <>
            <h1 className="mt-4">Report Break</h1>
            <ol className="breadcrumb mb-4">
                <li className="breadcrumb-item">Reports</li>
                <li className="breadcrumb-item active">Break</li>
            </ol>
            {notif.show && notif.type === 'error' && <Error
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            {notif.show && notif.type === 'success' && <Success
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            {notif.show && notif.type === 'warning' && <Warning
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            <Card className="mb-4">
                <Card.Header>
                    <i className="fas fa-table mr-1"></i> Filter Data
                </Card.Header>
                <Card.Body>
                    <Form onSubmit={handleSubmitFormFilter}>
                        <Form.Row>
                        <Form.Group className="col-md-2" controlId="DisableDate">
                                <Form.Label>Disable Date</Form.Label>
                                <br />
                                <Button variant="outline-info" onClick={() => handleChangeFormFilter("disable_date", !formFilter.disable_date)}>
                                    <i className={`far ${formFilter.disable_date ? "fa-check-square" : "fa-square"}`} />
                                </Button>
                            </Form.Group>
                            <Form.Group className="col-md-2" controlId="StartDate">
                                <Form.Label>From Date</Form.Label>
                                <DatePicker
                                    className="form-control"
                                    dateFormat="yyyy-MM-dd"
                                    selected={new Date(formFilter.start)}
                                    disabledKeyboardNavigation
                                    onChange={(date) => handleChangeFormFilter("start", formatDate(date) === false ? formatDate() : formatDate(date))}
                                    highlightDates={[new Date(), new Date()]}
                                    disabled={formFilter.disable_date}
                                />
                            </Form.Group>
                            <Form.Group className="col-md-2" controlId="EndDate">
                                <Form.Label>To Date</Form.Label>
                                <DatePicker
                                    className="form-control"
                                    dateFormat="yyyy-MM-dd"
                                    disabledKeyboardNavigation
                                    selected={new Date(formFilter.end)}
                                    onChange={(date) => handleChangeFormFilter("end", formatDate(date) === false ? formFilter.start : formatDate(date))}
                                    highlightDates={[new Date(), new Date()]}
                                    minDate={new Date(formFilter.start)}
                                    disabled={formFilter.disable_date}
                                />
                            </Form.Group>
                            <Form.Group className="col-md-2" controlId="Agent">
                                <Form.Label>Agent</Form.Label>
                                <CustomSelect.SelectBox
                                    optionSelect={optionAgent}
                                    onChangeValue={(value) => handleChangeFormFilter("user_id", value)}
                                    value={formFilter.user_id}
                                />
                            </Form.Group>
                            <Form.Group className="col-md-2" controlId="BreakReason">
                                <Form.Label>Break Reason</Form.Label>
                                <CustomSelect.SelectBox
                                    optionSelect={optionReason}
                                    onChangeValue={(value) => handleChangeFormFilter("break_reason_id", value)}
                                    value={formFilter.break_reason_id}
                                />
                            </Form.Group>
                        </Form.Row>
                        <Form.Row>
                            <Form.Group className="col-md-12 mb-0">
                                <Button type="submit" variant="primary">Search</Button>
                            </Form.Group>
                        </Form.Row>
                    </Form>
                </Card.Body>
            </Card>
            <Card className="mb-4">
                <Card.Body>
                    <Button variant="outline-secondary" onClick={() => {
                        setExporting(true)
                        handleExport(tableData.total_data)
                    }} disabled={!exporting && !loading && !isEmptyValue(tableData.data) ? false : true}>
                        {exporting && <Spinner animation="border" size="sm" className="mr-1" />} Export
                    </Button>
                    <hr />
                    <Table striped hover responsive width="100%">
                        <thead className="thead-dark">
                            <tr>
                                <th className="text-nowrap">No.</th>
                                <th className="text-nowrap">Record ID</th>
                                <th className="text-nowrap">Break Date</th>
                                <th className="text-nowrap">Break Start</th>
                                <th className="text-nowrap">Username</th>
                                <th className="text-nowrap">Break Reason</th>
                                <th className="text-nowrap">Resume Date</th>
                                <th className="text-nowrap">Resume Time</th>
                                <th className="text-nowrap">Duration</th>
                                <th className="text-nowrap">Total Break</th>
                            </tr>
                        </thead>
                        <tbody>
                            {loading &&
                                <tr>
                                    <td colSpan="37" className="text-center">
                                        <Spinner animation="border" size="sm" className="mr-1" />
                                        Loading data...
                                    </td>
                                </tr>
                            }
                            {!loading && isEmptyValue(tableData.data) &&
                                <tr>
                                    <td colSpan="37" className="text-center">
                                        <span className="text-danger">No data found</span>
                                    </td>
                                </tr>
                            }
                            {!loading && !isEmptyValue(tableData.data) &&
                                tableData.data.map((row, i) => (
                                    <tr key={ i }>
                                        <td>{ tableData.paging.index[i] }</td>
                                        <td>{ row.id }</td>
                                        <td>{ row.break_date }</td>
                                        <td>{ row.break_time }</td>
                                        <td>{ row.username }</td>
                                        <td>{ row.break_reason }</td>
                                        <td>{ row.resume_date }</td>
                                        <td>{ row.resume_time }</td>
                                        <td>{ row.duration }</td>
                                        <td>{ row.total_break }</td>
                                    </tr>
                                ))
                            }
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>No.</th>
                                <th>Record ID</th>
                                <th>Break Date</th>
                                <th>Break Start</th>
                                <th>Username</th>
                                <th>Break Reason</th>
                                <th>Resume Date</th>
                                <th>Resume Time</th>
                                <th>Duration</th>
                                <th>Total Break</th>
                            </tr>
                        </tfoot>
                    </Table>

                    {!loading && !isEmptyValue(tableData.paging) &&
                         <Pagination
                            total={tableData.total_data}
                            limit={tableData.limit}
                            paging={tableData.paging}
                            pageChange={(page) => {
                                setCurrentFilter({
                                    ...currentFilter,
                                    page: page
                                })
                                setLoading(true)
                            }}
                        />
                    }
                </Card.Body>
            </Card>
        </>
    )
}

const initialNotif = {
    title: "",
    message: "",
    show: false,
    type: null
}