import { useState, useEffect } from 'react'
import { Card, Button, Form, Table, Spinner, Modal } from 'react-bootstrap'
import _ from 'lodash'
import DatePicker from 'react-datepicker'
import { saveAs } from 'file-saver'
import { generalService } from './../../utils/services'
import { useCalls, useCampaigns, useExports, useUsers, useVoices } from './../../utils/functions'
import { Pagination, Notification, CustomSelect, CustomPlayer } from './../../components'

const { isEmptyValue, formatDate, sleep } = generalService

export const ReportCallDetail = (props) => {
    const fnCalls = useCalls()
    const fnCampaigns = useCampaigns()
    const fnExports = useExports()
    const fnUsers = useUsers()
    const fnVoices = useVoices()
    const { Error, Success, Warning } = Notification

    const [loading, setLoading] = useState(true)
    const [exporting, setExporting] = useState(false)
    const [notif, setNotif] = useState(initialNotif)
    const [tableData, setTableData] = useState({})
    const [formFilter, setFormFilter] = useState({
        user_id: "",
        campaign_id: "",
        customer_name: "",
        phone_number: "",
        start: formatDate(),
        end: formatDate(),
        disable_date: false
    })
    const [currentFilter, setCurrentFilter] = useState({
        page: 1,
        order: 'call_date',
        sort: 'desc',
        ...formFilter
    })
    const [optionAgent, setOptionAgent] = useState([{
        value: "",
        label: "Choose..."
    }])
    const [optionCampaign, setOptionCampaign] = useState([{
        value: "",
        label: "Choose..."
    }])
    const [showModal, setShowModal] = useState(false)
    const [voiceCall, setVoiceCall] = useState({
        url: null,
        loading: false
    })

    useEffect(() => {
        const fetchData = async () => {
            await fnCalls.GetReportCallDetail(currentFilter).then((res) => {
                setTableData(res)
                setLoading(false)
            }).catch((err) => { return }) //do nothing, let it go back to login
        }

        if (loading) fetchData()
        return () => setLoading(false)
    }, [loading])

    useEffect(() => {
        const fetchData = async () => {
            await fnUsers.Get({
                limit: 100,
                order: "username",
                is_active: 1
            }).then((res) => {
                if (!isEmptyValue(res.data)) {
                    let mapOptionAgent = res.data.map((row) => {
                        return { value: row.id, label: row.username }
                    })

                    setOptionAgent([
                        ...optionAgent,
                        ...mapOptionAgent
                    ])
                }
            }).catch((err) => { return }) //do nothing, let it go back to login

            await fnCampaigns.Get({
                limit: 100,
                order: "name"
            }).then((res) => {
                if (!isEmptyValue(res.data)) {
                    let mapOptionCampaign = res.data.map((row) => {
                        return { value: row.id, label: row.name }
                    })

                    setOptionCampaign([
                        ...optionCampaign,
                        ...mapOptionCampaign
                    ])
                }
            }).catch((err) => { return }) //do nothing, let it go back to login
        }

        fetchData()
        return () => {
            setOptionAgent([{
                value: "",
                label: "Choose..."
            }])
            setOptionCampaign([{
                value: "",
                label: "Choose..."
            }])
        }
    }, [])

    const handleChangeFormFilter = (key, val) => {
        if (key === 'start' && new Date(val) > new Date(formFilter.end)) {
            setFormFilter({
                ...formFilter,
                start: val,
                end: val
            })
        } else {
            setFormFilter({ ...formFilter, [key]: val })
        }
    }

    const handleSubmitFormFilter = (e) => {
        e.preventDefault()

        setCurrentFilter({
            ...currentFilter,
            ...formFilter,
            page: 1
        })
        setLoading(true)
    }

    const handleExport = async (limitData = false) => {
        await fnExports.ReportCallDetail({
            ...currentFilter,
            limit: limitData || 20
        }).then(async (res) => {
            await sleep(5000)
            setExporting(false)

            if (res.success) {
                setNotif({
                    ...notif,
                    title: "Success",
                    message: "Export data success.",
                    show: true,
                    type: "success"
                })

                return saveAs(res.data.url, res.data.filename)
            }

            return setNotif({
                ...notif,
                title: "Error",
                message: "Failed to export data.",
                show: true,
                type: "error"
            })
        }).catch((err) => { return }) //do nothing, let it go back to login
    }

    const handleVoiceCall = async (data = null) => {
        setShowModal(true)
        setVoiceCall({
            ...voiceCall,
            loading: true
        })

        let audioUrl = false

        if (!isEmptyValue(data) && _.isObject(data)) {
            if (data.hasOwnProperty('filename') && data.hasOwnProperty('filedate')) {
                let { filename, filedate } = data

                await fnVoices.Get({ filename, filedate }).then((res) => {
                    if (!isEmptyValue(res.data)) {
                        audioUrl = res.data.url
                    }
                }).catch((err) => { return }) //do nothing, let it go back to login
            }
        }

        if (audioUrl) {
            setVoiceCall({
                ...voiceCall,
                url: audioUrl,
                loading: false
            })
        } else {
            handleModalClose()
            setNotif({
                ...notif,
                title: "Error",
                message: "Failed to load audio call.",
                show: true,
                type: "error"
            })
        }
    }

    const handleModalClose = () => {
        setShowModal(false)
        setVoiceCall({
            ...voiceCall,
            url: null,
            loading: false
        })
    }

    return (
        <>
            <h1 className="mt-4">Report Call Detail</h1>
            <ol className="breadcrumb mb-4">
                <li className="breadcrumb-item">Reports</li>
                <li className="breadcrumb-item active">Call Detail</li>
            </ol>
            {notif.show && notif.type === 'error' && <Error
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            {notif.show && notif.type === 'success' && <Success
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            {notif.show && notif.type === 'warning' && <Warning
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            <Card className="mb-4">
                <Card.Header>
                    <i className="fas fa-table mr-1"></i> Filter Data
                </Card.Header>
                <Card.Body>
                    <Form onSubmit={handleSubmitFormFilter}>
                        <Form.Row>
                            <Form.Group className="col-md-2" controlId="DisableDate">
                                <Form.Label>Disable Date</Form.Label>
                                <br />
                                <Button variant="outline-info" onClick={() => handleChangeFormFilter("disable_date", !formFilter.disable_date)}>
                                    <i className={`far ${formFilter.disable_date ? "fa-check-square" : "fa-square"}`} />
                                </Button>
                            </Form.Group>
                            <Form.Group className="col-md-2" controlId="StartDate">
                                <Form.Label>From Date</Form.Label>
                                <DatePicker
                                    className="form-control"
                                    dateFormat="yyyy-MM-dd"
                                    selected={new Date(formFilter.start)}
                                    disabledKeyboardNavigation
                                    onChange={(date) => handleChangeFormFilter("start", formatDate(date) === false ? formatDate() : formatDate(date))}
                                    highlightDates={[new Date(), new Date()]}
                                    disabled={formFilter.disable_date}
                                />
                            </Form.Group>
                            <Form.Group className="col-md-2" controlId="EndDate">
                                <Form.Label>To Date</Form.Label>
                                <DatePicker
                                    className="form-control"
                                    dateFormat="yyyy-MM-dd"
                                    disabledKeyboardNavigation
                                    selected={new Date(formFilter.end)}
                                    onChange={(date) => handleChangeFormFilter("end", formatDate(date) === false ? formFilter.start : formatDate(date))}
                                    highlightDates={[new Date(), new Date()]}
                                    minDate={new Date(formFilter.start)}
                                    disabled={formFilter.disable_date}
                                />
                            </Form.Group>
                        </Form.Row>
                        <Form.Row>
                            <Form.Group className="col-md-2" controlId="Agent">
                                <Form.Label>Agent</Form.Label>
                                <CustomSelect.SelectBox
                                    optionSelect={optionAgent}
                                    onChangeValue={(value) => handleChangeFormFilter("user_id", value)}
                                    value={formFilter.user_id}
                                />
                            </Form.Group>
                            <Form.Group className="col-md-2" controlId="Campaign">
                                <Form.Label>Campaign</Form.Label>
                                <CustomSelect.SelectBox
                                    optionSelect={optionCampaign}
                                    onChangeValue={(value) => handleChangeFormFilter("campaign_id", value)}
                                    value={formFilter.campaign_id}
                                />
                            </Form.Group>
                            <Form.Group className="col-md-2" controlId="CustomerName">
                                <Form.Label>Customer Name</Form.Label>
                                <Form.Control
                                    type="text"
                                    onChange={e => handleChangeFormFilter("customer_name", e.target.value)}
                                    value={formFilter.customer_name}
                                />
                            </Form.Group>
                            <Form.Group className="col-md-2" controlId="PhoneNumber">
                                <Form.Label>Phone Number</Form.Label>
                                <Form.Control
                                    type="text"
                                    onChange={e => handleChangeFormFilter("phone_number", e.target.value)}
                                    value={formFilter.phone_number}
                                />
                            </Form.Group>
                        </Form.Row>
                        <Form.Row>
                            <Form.Group className="col-md-12 mb-0">
                                <Button type="submit" variant="primary">Search</Button>
                            </Form.Group>
                        </Form.Row>
                    </Form>
                </Card.Body>
            </Card>
            <Card className="mb-4">
                <Card.Body>
                    <Button variant="outline-secondary" onClick={() => {
                        setExporting(true)
                        handleExport(tableData.total_data)
                    }} disabled={!exporting && !loading && !isEmptyValue(tableData.data) ? false : true}>
                        {exporting && <Spinner animation="border" size="sm" className="mr-1" />} Export
                    </Button>
                    <hr />
                    <Table striped hover responsive width="100%">
                        <thead className="thead-dark">
                            <tr>
                                <th className="text-nowrap">No.</th>
                                <th className="text-nowrap">Call Date</th>
                                <th className="text-nowrap">Agent</th>
                                <th className="text-nowrap">Agent Fullname</th>
                                <th className="text-nowrap">Campaign Name</th>
                                <th className="text-nowrap">Customer Name</th>
                                <th className="text-nowrap">Phone Number Type</th>
                                <th className="text-nowrap">Phone Number</th>
                                <th className="text-nowrap">Call Duration</th>
                                <th className="text-nowrap">Notes</th>
                                <th className="text-nowrap">Outbound Status</th>
                                <th className="text-nowrap">Outbound Category</th>
                                <th className="text-nowrap">Outbound Category Detail</th>
                                <th className="text-nowrap">File Name</th>
                                <th className="text-nowrap">Host Address</th>
                                <th className="text-nowrap">Voice Call</th>
                            </tr>
                        </thead>
                        <tbody>
                            {loading &&
                                <tr>
                                    <td colSpan="16" className="text-center">
                                        <Spinner animation="border" size="sm" className="mr-1" />
                                        Loading data...
                                    </td>
                                </tr>
                            }
                            {!loading && isEmptyValue(tableData.data) &&
                                <tr>
                                    <td colSpan="16" className="text-center">
                                        <span className="text-danger">No data found</span>
                                    </td>
                                </tr>
                            }
                            {!loading && !isEmptyValue(tableData.data) &&
                                tableData.data.map((row, i) => (
                                    <tr key={ i }>
                                        <td>{ tableData.paging.index[i] }</td>
                                        <td className="text-nowrap">{ row.call_date }</td>
                                        <td>{ row.agent }</td>
                                        <td>{ row.agent_fullname }</td>
                                        <td>{ row.campaign_name }</td>
                                        <td>{ row.customer_name }</td>
                                        <td>{ row.phone_number_type }</td>
                                        <td>{ row.phone_number }</td>
                                        <td>{ row.call_duration }</td>
                                        <td style={{minWidth: "10em"}}>{ row.notes }</td>
                                        <td>{ row.outbound_status }</td>
                                        <td>{ row.outbound_category }</td>
                                        <td>{ row.outbound_categoriy_detail }</td>
                                        <td>{ row.filename }</td>
                                        <td>{ row.host_address }</td>
                                        <td className="text-nowrap">
                                            <Button variant="info" size="sm" className="m-1" onClick={(e) => handleVoiceCall({
                                                filename: row.filename,
                                                filedate: row.filedate
                                            })} disabled={!isEmptyValue(row.filename) && !isEmptyValue(row.filedate) ? false : true}>
                                                <i className="fas fa-play fa-fw" /> Audio
                                            </Button>
                                        </td>
                                    </tr>
                                ))
                            }
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>No.</th>
                                <th>Call Date</th>
                                <th>Agent</th>
                                <th>Agent Fullname</th>
                                <th>Campaign Name</th>
                                <th>Customer Name</th>
                                <th>Phone Number Type</th>
                                <th>Phone Number</th>
                                <th>Call Duration</th>
                                <th>Notes</th>
                                <th>Outbound Status</th>
                                <th>Outbound Category</th>
                                <th>Outbound Category Detail</th>
                                <th>File Name</th>
                                <th>Host Address</th>
                                <th>Voice Call</th>
                            </tr>
                        </tfoot>
                    </Table>

                    {!loading && !isEmptyValue(tableData.paging) &&
                         <Pagination
                            total={tableData.total_data}
                            limit={tableData.limit}
                            paging={tableData.paging}
                            pageChange={(page) => {
                                setCurrentFilter({
                                    ...currentFilter,
                                    page: page
                                })
                                setLoading(true)
                            }}
                        />
                    }
                </Card.Body>
            </Card>

            <Modal show={showModal} onHide={handleModalClose}>
                <Modal.Header closeButton>
                    <Modal.Title>Play Voice Call</Modal.Title>
                </Modal.Header>
                <Modal.Body className="text-center">
                    <CustomPlayer.Audio url={voiceCall.url} loading={voiceCall.loading} autoplay={true} size="lg" />
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="light" onClick={handleModalClose}>Close</Button>
                </Modal.Footer>
            </Modal>
        </>
    )
}

const initialNotif = {
    title: "",
    message: "",
    show: false,
    type: null
}