import { useState, useEffect } from 'react'
import { Card, Button, Form, Table, Spinner } from 'react-bootstrap'
import _ from 'lodash'
import DatePicker from 'react-datepicker'
import { saveAs } from 'file-saver'
import { generalService, cookieService } from './../../utils/services'
import { useExports, useQualityAssuranceDetails, useUsers } from './../../utils/functions'
import { Pagination, Notification, CustomSelect } from './../../components'

const { isEmptyValue, formatDate, sleep } = generalService

export const ReportQualityAssuranceSummary = (props) => {
    const fnExports = useExports()
    const fnQualityAssuranceDetails = useQualityAssuranceDetails()
    const fnUsers = useUsers()
    const { Error, Success, Warning } = Notification

    const [loading, setLoading] = useState(true)
    const [exporting, setExporting] = useState(false)
    const [notif, setNotif] = useState(initialNotif)
    const [tableData, setTableData] = useState({})
    const [formFilter, setFormFilter] = useState({
        user_id: "",
        start: formatDate(),
        end: formatDate(),
        disable_date: false
    })
    const [currentFilter, setCurrentFilter] = useState({
        page: 1,
        ...formFilter
    })
    const [optionAgent, setOptionAgent] = useState([{
        value: "",
        label: "Choose..."
    }])

    useEffect(() => {
        const fetchData = async () => {
            await fnQualityAssuranceDetails.GetReportQaSummary(currentFilter).then((res) => {
                setTableData(res)
                setLoading(false)
            }).catch((err) => { return }) //do nothing, let it go back to login
        }

        if (loading) fetchData()
        return () => setLoading(false)
    }, [loading])

    useEffect(() => {
        const fetchData = async () => {
            await fnUsers.Get({
                limit: 100,
                order: "username",
                is_active: 1
            }).then((res) => {
                if (!isEmptyValue(res.data)) {
                    let mapOptionAgent = res.data.map((row) => {
                        return { value: row.id, label: row.username }
                    })

                    setOptionAgent([
                        ...optionAgent,
                        ...mapOptionAgent
                    ])
                }
            }).catch((err) => { return }) //do nothing, let it go back to login
        }

        fetchData()
        return () => setOptionAgent([{
            value: "",
            label: "Choose..."
        }])
    }, [])

    const handleChangeFormFilter = (key, val) => {
        if (key === 'start' && new Date(val) > new Date(formFilter.end)) {
            setFormFilter({
                ...formFilter,
                start: val,
                end: val
            })
        } else {
            setFormFilter({ ...formFilter, [key]: val })
        }
    }

    const handleSubmitFormFilter = (e) => {
        e.preventDefault()

        setCurrentFilter({
            ...currentFilter,
            ...formFilter,
            page: 1
        })
        setLoading(true)
    }

    const handleExport = async (limitData = false) => {
        await fnExports.ReportQualityAssuranceSummary({
            ...currentFilter,
            limit: limitData || 20
        }).then(async (res) => {
            await sleep(5000)
            setExporting(false)

            if (res.success) {
                setNotif({
                    ...notif,
                    title: "Success",
                    message: "Export data success.",
                    show: true,
                    type: "success"
                })

                return saveAs(res.data.url, res.data.filename)
            }

            return setNotif({
                ...notif,
                title: "Error",
                message: "Failed to export data.",
                show: true,
                type: "error"
            })
        }).catch((err) => { return }) //do nothing, let it go back to login
    }

    return (
        <>
            <h1 className="mt-4">Quality Assurance Report Summaries</h1>
            <ol className="breadcrumb mb-4">
                <li className="breadcrumb-item">Quality Assurance</li>
                <li className="breadcrumb-item active">Report Summaries</li>
            </ol>
            {notif.show && notif.type === 'error' && <Error
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            {notif.show && notif.type === 'success' && <Success
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            {notif.show && notif.type === 'warning' && <Warning
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            <Card className="mb-4">
                <Card.Header>
                    <i className="fas fa-table mr-1"></i> Filter Data
                </Card.Header>
                <Card.Body>
                    <Form onSubmit={handleSubmitFormFilter}>
                        <Form.Row>
                            <Form.Group className="col-md-2" controlId="DisableDate">
                                <Form.Label>Disable Date</Form.Label>
                                <br />
                                <Button variant="outline-info" onClick={() => handleChangeFormFilter("disable_date", !formFilter.disable_date)}>
                                    <i className={`far ${formFilter.disable_date ? "fa-check-square" : "fa-square"}`} />
                                </Button>
                            </Form.Group>
                            <Form.Group className="col-md-2" controlId="StartDate">
                                <Form.Label>From Date</Form.Label>
                                <DatePicker
                                    className="form-control"
                                    dateFormat="yyyy-MM-dd"
                                    selected={new Date(formFilter.start)}
                                    disabledKeyboardNavigation
                                    onChange={(date) => handleChangeFormFilter("start", formatDate(date) === false ? formatDate() : formatDate(date))}
                                    highlightDates={[new Date(), new Date()]}
                                    disabled={formFilter.disable_date}
                                />
                            </Form.Group>
                            <Form.Group className="col-md-2" controlId="EndDate">
                                <Form.Label>To Date</Form.Label>
                                <DatePicker
                                    className="form-control"
                                    dateFormat="yyyy-MM-dd"
                                    disabledKeyboardNavigation
                                    selected={new Date(formFilter.end)}
                                    onChange={(date) => handleChangeFormFilter("end", formatDate(date) === false ? formFilter.start : formatDate(date))}
                                    highlightDates={[new Date(), new Date()]}
                                    minDate={new Date(formFilter.start)}
                                    disabled={formFilter.disable_date}
                                />
                            </Form.Group>
                            <Form.Group className="col-md-2" controlId="Agent">
                                <Form.Label>Agent</Form.Label>
                                <CustomSelect.SelectBox
                                    optionSelect={optionAgent}
                                    onChangeValue={(value) => handleChangeFormFilter("user_id", value)}
                                    value={formFilter.user_id}
                                />
                            </Form.Group>
                        </Form.Row>
                        <Form.Row>
                            <Form.Group className="col-md-12 mb-0">
                                <Button type="submit" variant="primary">Search</Button>
                            </Form.Group>
                        </Form.Row>
                    </Form>
                </Card.Body>
            </Card>
            <Card className="mb-4">
                <Card.Body>
                    {['2','4','5'].includes(cookieService.Get('user_level_id')) && <>
                        <Button variant="outline-secondary" onClick={() => {
                            setExporting(true)
                            handleExport(tableData.total_data)
                        }} disabled={!exporting && !loading && !isEmptyValue(tableData.data) ? false : true}>
                            {exporting && <Spinner animation="border" size="sm" className="mr-1" />} Export
                        </Button>
                        <hr />
                    </>}
                    <Table striped hover responsive width="100%">
                        <thead className="thead-dark">
                            <tr>
                                <th className="text-nowrap">No.</th>
                                <th className="text-nowrap">Agent</th>
                                {(() => {
                                    let cellHead = []
                                    for (let x = 1; x <= 10; x++) {
                                        cellHead.push(<th className="text-nowrap">Periode {x}</th>)
                                    }
                                    return <>{ cellHead }</>
                                })()}
                            </tr>
                        </thead>
                        <tbody>
                            {loading &&
                                <tr>
                                    <td colSpan="12" className="text-center">
                                        <Spinner animation="border" size="sm" className="mr-1" />
                                        Loading data...
                                    </td>
                                </tr>
                            }
                            {!loading && isEmptyValue(tableData.data) &&
                                <tr>
                                    <td colSpan="12" className="text-center">
                                        <span className="text-danger">No data found</span>
                                    </td>
                                </tr>
                            }
                            {!loading && !isEmptyValue(tableData.data) &&
                                tableData.data.map((row, i) => (
                                    <tr key={ i }>
                                        <td>{ tableData.paging.index[i] }</td>
                                        <td>{ row.username }</td>
                                        {(() => {
                                            let cellBody = []
                                            for (let y = 1; y <= 10; y++) {
                                                cellBody.push(<td>{ row[`period_${y}`] }</td>)
                                            }
                                            return <>{ cellBody }</>
                                        })()}
                                    </tr>
                                ))
                            }
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>No.</th>
                                <th>Agent</th>
                                {(() => {
                                    let cellFoot = []
                                    for (let z = 1; z <= 10; z++) {
                                        cellFoot.push(<th>Periode {z}</th>)
                                    }
                                    return <>{ cellFoot }</>
                                })()}
                            </tr>
                        </tfoot>
                    </Table>

                    {!loading && !isEmptyValue(tableData.paging) &&
                         <Pagination
                            total={tableData.total_data}
                            limit={tableData.limit}
                            paging={tableData.paging}
                            pageChange={(page) => {
                                setCurrentFilter({
                                    ...currentFilter,
                                    page: page
                                })
                                setLoading(true)
                            }}
                        />
                    }
                </Card.Body>
            </Card>
        </>
    )
}

const initialNotif = {
    title: "",
    message: "",
    show: false,
    type: null
}