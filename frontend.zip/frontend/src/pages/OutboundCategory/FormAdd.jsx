import { useState, useEffect, useCallback, useContext } from 'react'
import { Button, Form, Modal, Spinner, Row, Col } from 'react-bootstrap'
import { useForm, Controller } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import _ from 'lodash'
import { generalService } from './../../utils/services'
import { useOutboundCategories } from './../../utils/functions'

const { isEmptyValue, formatDate, formatDateTime } = generalService

export const FormAdd = ({ modalChange, notifChange, dataChange }) => {
    const fnOutboundCategories = useOutboundCategories()
    const { handleSubmit, formState: { errors, isSubmitting }, register, clearErrors } = useForm({
        defaultValues: {
            name: "",
            is_active: "1"
        },
        resolver: yupResolver(yup.object().shape({
            name: yup.string()
                .required("This field is required.")
        }))
    })

    useEffect(() => {
        clearErrors()
    }, [])

    const onSubmitForm = async (data, e) => {
        e.preventDefault()

        await fnOutboundCategories.Create(data).then((res) => {
            if (res.success) {
                notifChange({
                    title: "Success",
                    message: "Data has been created.",
                    show: true,
                    type: "success"
                })
                dataChange()
            } else {
                notifChange({
                    title: "Error",
                    message: "Failed to create data.",
                    show: true,
                    type: "error"
                })
            }

            handleModalClose()
        }).catch((err) => { return }) //do nothing, let it go back to login
    }

    const handleModalClose = () => {
        return modalChange({
            show: false,
            dataId: null
        })
    }

    return (
        <>
            <Modal.Header closeButton={isSubmitting ? false : true}>
                <Modal.Title>Add New Outbound Category</Modal.Title>
            </Modal.Header>
            <Form onSubmit={handleSubmit(onSubmitForm)}>
                <Modal.Body className="py-1">
                    <Form.Group controlId="Name">
                        <Form.Label>Name <span className="text-danger">*</span></Form.Label>
                        <Form.Control
                            type="text"
                            size="sm"
                            isInvalid={!!errors.name}
                            {...register("name")}
                        />
                        <Form.Control.Feedback type="invalid">{errors.name?.message}</Form.Control.Feedback>
                    </Form.Group>
                    <Form.Group controlId="IsActive">
                        <Form.Check
                            type="checkbox"
                            label="Active"
                            custom
                            checked={true}
                            disabled={true}
                        />
                    </Form.Group>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="primary" type="submit" disabled={isSubmitting}>
                        {isSubmitting && <Spinner animation="border" size="sm" className="mr-1" />} Save
                    </Button>
                    <Button variant="light" disabled={isSubmitting} onClick={handleModalClose}>Close</Button>
                </Modal.Footer>
            </Form>
        </>
    )
}