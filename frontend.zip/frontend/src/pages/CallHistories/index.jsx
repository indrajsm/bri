import React, { useEffect, useState, useContext } from "react";
import { Button, Form, Modal, Spinner, Table, Row } from "react-bootstrap";
import _ from "lodash";
import { Pagination, Notification, CustomPlayer } from "./../../components";
import { useCalls, useVoices } from "../../utils/functions";
import { generalService } from "../../utils/services";
import { AuthContext } from "../../utils/context";

const { isEmptyValue, formatDate, sleep } = generalService

export const CallHistories = ({ CustomerId }) => {
  const { userLevelId } = useContext(AuthContext)
  const { Get } = useCalls();
  const fnVoices = useVoices()
  const { Error, Success, Warning } = Notification

  const [isLoading, setIsLoading] = useState(true);
  const [tableData, setTableData] = useState({});
  const [notif, setNotif] = useState(initialNotif)


  const [currentFilter, setCurrentFilter] = useState({
    customer_id: CustomerId,
    page: 1,
    order: "call_date",
    limit: 5
  });

  const [showModal, setShowModal] = useState(false)
  const [voiceCall, setVoiceCall] = useState({
    url: null,
    loading: false
  })

  const handleVoiceCall = async (data = null) => {
    setShowModal(true)
    setVoiceCall({
      ...voiceCall,
      loading: true
    })

    let audioUrl = false

    if (!isEmptyValue(data) && _.isObject(data)) {
      if (data.hasOwnProperty('filename') && data.hasOwnProperty('filedate')) {
        let { filename, filedate } = data

        await fnVoices.Get({ filename, filedate }).then((res) => {
          if (!isEmptyValue(res.data)) {
            audioUrl = res.data.url
          }
        }).catch((err) => { return }) //do nothing, let it go back to login
      }
    }

    if (audioUrl) {
      setVoiceCall({
        ...voiceCall,
        url: audioUrl,
        loading: false
      })
    } else {
      handleModalClose()
      setNotif({
        ...notif,
        title: "Error",
        message: "Failed to load audio call.",
        show: true,
        type: "error"
      })
    }
  }

  const handleModalClose = () => {
    setShowModal(false)
    setVoiceCall({
      ...voiceCall,
      url: null,
      loading: false
    })
  }

  useEffect(() => {
    const fetchData = async () => {
      await Get(currentFilter)
        .then(res => {
          setTableData(res);
          setIsLoading(false);
        })
        .catch(err => {
          return;
        });
    };
    fetchData();
  }, [isLoading, currentFilter]);

  console.log(tableData)

  return (
    <>
      {notif.show && notif.type === 'error' && <Error
        title={notif.title}
        message={notif.message}
        show={notif.show}
        showChange={() => { setNotif(initialNotif) }}
      />}
      {notif.show && notif.type === 'success' && <Success
        title={notif.title}
        message={notif.message}
        show={notif.show}
        showChange={() => { setNotif(initialNotif) }}
      />}
      {notif.show && notif.type === 'warning' && <Warning
        title={notif.title}
        message={notif.message}
        show={notif.show}
        showChange={() => { setNotif(initialNotif) }}
      />}
      <div className="card mb-4">
        <div className="card-body">
          <hr />
          <div className="table-responsive">
            <Table
              striped
              hover
              responsive
              width="100%"
              cellSpacing="0"
              cellPadding="0"
            >
              <thead className="thead-dark text-nowrap">
                <tr>
                  <th>Call Date</th>
                  <th>Campaing Name</th>
                  <th>Customer Name</th>
                  <th>Agent</th>
                  <th>Call Duration</th>
                  <th>Phone Number</th>
                  <th>Outbound Status</th>
                  <th>Outbound Category</th>
                  <th>Outbound Category Detail</th>
                  {
                    (userLevelId == 2 || userLevelId == 5) &&
                    <th>Voice Call</th>
                  }
                </tr>
              </thead>

              <tbody className="text-nowrap">
                {isLoading ? (
                  <tr>
                    <td colSpan="9" className="text-center">
                      <Spinner animation="border" size="sm" className="mr-1" />
                      Loading data...
                    </td>
                  </tr>
                ) : tableData.total_data > 0 ? (
                  tableData.data.map((item, i) => (
                    <tr key={item.id} className="text-center">
                      <td>{item.call_date}</td>
                      <td>{item.campaigns}</td>
                      <td width="500">{item.customer_name}</td>
                      <td>{item.pickup_by}</td>
                      <td>{item.call_duration}</td>
                      <td>{item.phone_number}</td>
                      <td>{item.outbound_status}</td>
                      <td>{item.outbound_categories}</td>
                      <td>{item.outbound_category_details}</td>
                      {
                        (userLevelId == 2 || userLevelId == 5) &&
                        <td className="text-nowrap">
                          <Button variant="info" size="sm" className="m-1" onClick={(e) => handleVoiceCall({
                            filename: item.filename,
                            filedate: item.filedate
                          })} disabled={!isEmptyValue(item.filename) && !isEmptyValue(item.filedate) ? false : true}>
                            <i className="fas fa-play fa-fw" /> Audio
                        </Button>
                        </td>}

                    </tr>
                  ))
                ) : (
                      <>
                        <tr>
                          <td colSpan="9" className="text-center">
                            <span className="text-danger">No data found</span>
                          </td>
                        </tr>
                      </>
                    )}
              </tbody>
            </Table>
          </div>
          {isLoading === false && !_.isEmpty(tableData) && (
            <Pagination
              total={tableData.total_data}
              limit={tableData.limit}
              paging={tableData.paging}
              pageChange={async pageNumber => {
                await setIsLoading(true);
                setCurrentFilter({
                  ...currentFilter,
                  page: pageNumber
                });
              }}
            />
          )}
        </div>
      </div>

      <Modal show={showModal} onHide={handleModalClose}>
        <Modal.Header closeButton>
          <Modal.Title>Play Voice Call</Modal.Title>
        </Modal.Header>
        <Modal.Body className="text-center">
          <CustomPlayer.Audio url={voiceCall.url} loading={voiceCall.loading} autoplay={true} size="lg" />
        </Modal.Body>
        <Modal.Footer>
          <Button variant="light" onClick={handleModalClose}>Close</Button>
        </Modal.Footer>
      </Modal>
    </>
  );
};

const initialNotif = {
  title: "",
  message: "",
  show: false,
  type: null
}
