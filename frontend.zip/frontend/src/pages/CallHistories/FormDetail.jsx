import React, { useEffect, useState } from 'react'
import { Form, Modal } from 'react-bootstrap'
import _ from 'lodash'
import { generalService } from '../../utils/services';
import { useEmails } from '../../utils/functions';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import '../../public/assets/styles/editor.css'

const { isEmptyValue } = generalService

export const FormDetail = ({ dataId }) => {
    const { Get } = useEmails()
    const [email, setEmail] = useState({
        email_to: "",
        email_cc: "",
        subject: "",
        content: ""
    })

    useEffect(() => {
        const fnAbort = new AbortController()
        const fetchData = async () => {
            await Get({ id: dataId }).then((res) => {
                if (!isEmptyValue(res.data)) {
                    setEmail({
                        email_to: `Send To: ${res.data.email_to}`,
                        email_cc: isEmptyValue(res.data.email_cc) ? 'CC To:' : `CC To: ${res.data.email_cc}`,
                        subject: `Subject: ${res.data.subject}`,
                        content: res.data.content
                    })
                }
            }).catch((err) => { return () => fnAbort.abort() }) //do nothing, let it go back to login
        }
        fetchData()
        return () => fnAbort.abort()
    }, [])

    return (
        <>
            <Form>
                <Modal.Body>
                    <Form.Group className="mb-3">
                        <Form.Control type="text" defaultValue={email.email_to} />
                    </Form.Group>
                    <Form.Group className="mb-3">
                        <Form.Control type="text" defaultValue={email.email_cc} />
                    </Form.Group>
                    <Form.Group className="mb-3">
                        <Form.Control type="text" defaultValue={email.subject} />
                    </Form.Group>

                    <Form.Group className="mb-3">
                        <ReactQuill
                            theme="snow"
                            value={email.content}
                        />
                    </Form.Group>

                </Modal.Body>
                {/* <Modal.Footer>
                    <Button variant="primary" type="submit">{isLoading ? <Spinner animation="border" size="sm" className="mr-1" /> : 'Update'}</Button>
                </Modal.Footer> */}
            </Form>
        </>
    )
}


