import React, { useEffect, useState, useContext, useCallback } from "react"
import { Button, Form, Modal, Row, Col, Card, Collapse, Nav } from "react-bootstrap"
import { useForm, Controller } from "react-hook-form"
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import { useStopwatch } from "react-timer-hook"
import classnames from 'classnames'
import "react-quill/dist/quill.snow.css"
import "../../public/assets/styles/editor.css"
import { generalService } from "../../utils/services"
import { CallContext, AuthContext } from "../../utils/context"
import _ from "lodash"
import { useCustomers, useOutboundCategories, useHangUp, useOutboundCategoryDetails, useMute, useCalls } from "../../utils/functions"
import { CallHistories } from "../CallHistories"
import { CustomerField } from "../Elements/CustomerField"
import { CampaignInfo } from "../Elements/CampaignInfo"
import Select from 'react-select'

const { isEmptyValue, formatDateTime, diffDate } = generalService

export const FormDetail = ({ handleModalClose, dataId, campaignId, handleScheduleCall, handleChecking }) => {
  const { incomingCall, pickUpCall } = useContext(CallContext)
  const { userId, setUserActivityId, userLevelId } = useContext(AuthContext)
  const { channel } = pickUpCall
  const { phone_no, call_id } = incomingCall
  const [tab, setTab] = useState(1)
  const { Get } = useCustomers()
  const { Update } = useCalls()
  const { HangUp } = useHangUp()
  const { Mute } = useMute()
  const fnOutboundCategories = useOutboundCategories()
  const fnOutboundCategoryDetails = useOutboundCategoryDetails()
  const [outboundCategory, setOutboundCategory] = useState(initialOption)
  const [outboundCategoryDetail, setOutboundCategoryDetail] = useState(initialOption)
  const [customer, setCustomer] = useState({})
  const [campaignInfo, setCampaignInfo] = useState({ campaign_info: '' })
  const [mute, setMute] = useState(false)
  const start_call = localStorage.getItem("startCall")
  const diff = diffDate(formatDateTime(), start_call) / 700

  const { handleSubmit, formState: { errors }, register, control, reset, clearErrors, watch } = useForm({
    defaultValues: initialCall,
    resolver: validationSchemaCall
  })

  const outbound_category_id = watch("outbound_category_id")
  const outbound_category_detail_id = watch("outbound_category_detail_id")

  const stopwatchOffset = new Date()
  const { seconds, minutes, hours, start } = useStopwatch({
    autoStart: false,
    offsetTimestamp: stopwatchOffset.setSeconds(
      stopwatchOffset.getSeconds() + diff
    )
  })

  const hourTime = hours < 10 ? `0${hours}` : `${hours}`
  const minuteTime = minutes < 10 ? `0${minutes}` : `${minutes}`
  const secondTime = seconds < 10 ? `0${seconds}` : `${seconds}`

  const onSubmit = async (data, e) => {
    e.preventDefault(e)
    const data_hangup = {
      channel: channel
    }

    await HangUp(data_hangup)
      .then(async res => {
        // console.log(res)
        if (res.success) {
          await Update(call_id, {
            ...data,
            dropcall_date: formatDateTime(),
            updated_at: formatDateTime(),
            updated_by: userId
          }).then(async res => {
            if (res.success) {
              // localStorage.setItem('userActivityId', 2)
              // setUserActivityId(2)
              handleModalClose()
            }
          })
        }
      })
      .catch(err => {
        return
      })
  }

  const handleMute = async () => {
    const data = {
      channel: channel,
      direction: "all",
      state: "on"
    }
    await Mute(data)
      .then(async res => {
        if (res.success) {
          setMute(true)
        }
      })
      .catch(err => {
        return
      })
  }

  const handleUnMute = async () => {
    const data = {
      channel: channel,
      direction: "all",
      state: "off"
    }
    await Mute(data)
      .then(async res => {
        if (res.success) {
          setMute(false)
        }
      })
      .catch(err => {
        return
      })
  }

  useEffect(() => {
    const fetchData = async () => {
      await Get({ id: dataId })
        .then(res => {
          if (!isEmptyValue(res.data)) {
            setCustomer(res.data)
          }
        })
        .catch(err => {
          return
        })
      await fnOutboundCategories
        .Get()
        .then(res => {
          if (!isEmptyValue(res.data)) {
            let outboundOption = res.data.map(row => {
              return { value: row.id, label: row.name }
            })

            setOutboundCategory([...initialOption, ...outboundOption])
          } else {
            setOutboundCategory(initialOption)
          }
        })
        .catch(err => {
          return
        })
    }
    if (!isEmptyValue(channel)) {
      start()
    }
    fetchData()
  }, [])

  useEffect(() => {
    if (outbound_category_id) {
      const fetchDataDetail = async () => {
        await fnOutboundCategoryDetails
          .Get({ outbound_category_id: outbound_category_id })
          .then(res => {
            if (!isEmptyValue(res.data)) {
              let outboundDetailOption = res.data.map(row => {
                return { value: row.id, label: row.name }
              })

              setOutboundCategoryDetail([
                ...initialOption,
                ...outboundDetailOption
              ])
            } else {
              setOutboundCategoryDetail(initialOption)
            }
          })
          .catch(err => {
            return
          })
      }
      fetchDataDetail()
    }
  }, [outbound_category_id])

  return (
    <>
      <Modal.Body>
        <Card>
          <Card.Body>
            <NavTab setTab={setTab} tab={tab} channel={channel} />
            {tab === 1 && (
              <Row>
                <Col sm="12">
                  <Card className="mb-3">
                    {/* <Card.Header>Customer Detail</Card.Header> */}
                    <Form onSubmit={handleSubmit(onSubmit)}>
                      <Card.Body>
                        <Form.Group as={Row}>
                          <Col sm="6">
                            <Form.Group className="mb-3">
                              <Form.Label>Customer Name</Form.Label>
                              <Form.Control
                                type="text"
                                size="sm"
                                value={customer.fullname}
                                disabled
                              />
                            </Form.Group>
                          </Col>
                          <Col sm="6">
                            <Form.Group className="mb-3">
                              <Form.Label>Campaign</Form.Label>
                              <Form.Control
                                type="text"
                                size="sm"
                                value={customer.campaign_name}
                                disabled
                              />
                            </Form.Group>
                          </Col>
                          <Col sm="6">
                            <Form.Group className="mb-3">
                              <Form.Label>Dial Phone No</Form.Label>
                              <Form.Control
                                type="text"
                                size="sm"
                                value={phone_no}
                                disabled
                              />
                            </Form.Group>
                          </Col>

                          <Col sm="6">
                            <Form.Group className="mb-3">
                              <Form.Label>Duration</Form.Label>
                              <Form.Control
                                type="text"
                                size="sm"
                                disabled
                                value={
                                  !isEmptyValue(channel)
                                    ? `${hourTime}:${minuteTime}:${secondTime}`
                                    : ""
                                }
                              />
                            </Form.Group>
                          </Col>
                          <Col sm="12">
                            {!isEmptyValue(channel) ? (
                              <>
                                <Form.Group className="mb-3">
                                  <Form.Label>Note</Form.Label>
                                  <Form.Control
                                    as="textarea"
                                    rows={3}
                                    size="sm"
                                    {...register("note")}
                                  />
                                </Form.Group>
                                <Form.Text
                                  className={classnames("text-danger", {
                                    "d-none": !errors.note
                                  })}
                                >
                                  {errors.note ?.message}
                                </Form.Text>
                              </>
                            ) : (
                                <>
                                  <Form.Group className="mb-3">
                                    <Form.Label>Note</Form.Label>
                                    <Form.Control
                                      as="textarea"
                                      rows={3}
                                      size="sm"
                                      value={customer.note}
                                    />
                                  </Form.Group>
                                </>
                              )}
                          </Col>

                          <Col sm="6">
                            <Form.Group className="mb-3">
                              <Form.Label>Outbound Category</Form.Label>
                              {!isEmptyValue(channel) ? (
                                <Controller
                                  name={"outbound_category_id"}
                                  control={control}
                                  render={({ field: { value, onChange } }) => {
                                    return (
                                      <Select
                                        options={outboundCategory}
                                        onChange={val => {
                                          onChange(val.value)
                                        }}
                                        value={!isEmptyValue(outboundCategory) && outboundCategory.filter((opt) => {
                                          return opt.value === outbound_category_id;
                                        })}
                                      />
                                    )
                                  }}
                                />) : (
                                  <Form.Control
                                    type="text"
                                    size="sm"
                                    value={customer.outbound_category_name}
                                    disabled
                                  />
                                )}

                            </Form.Group>
                            <Form.Text
                              className={classnames("text-danger", {
                                "d-none": !errors.outbound_category_id
                              })}
                            >
                              {errors.outbound_category_id ?.message}
                            </Form.Text>
                          </Col>
                          <Col sm="6">
                            <Form.Group className="mb-3">
                              <Form.Label>Outbound Category Detail</Form.Label>
                              {!isEmptyValue(channel) ? (
                                <Controller
                                  name={"outbound_category_detail_id"}
                                  control={control}
                                  render={({ field: { value, onChange } }) => {
                                    return (
                                      <Select
                                        options={outboundCategoryDetail}
                                        onChange={
                                          val =>
                                            onChange(val.value)
                                        }
                                        value={!isEmptyValue(outboundCategoryDetail) && outboundCategoryDetail.filter((opt) => {
                                          return opt.value === outbound_category_detail_id;
                                        })}
                                      />
                                    )
                                  }}
                                />
                              ) : (
                                  <Form.Control
                                    type="text"
                                    size="sm"
                                    value={customer.outbound_category_detail_name}
                                    disabled
                                  />
                                )}
                            </Form.Group>
                            <Form.Text
                              className={classnames("text-danger", {
                                "d-none": !errors.outbound_category_detail_id
                              })}
                            >
                              {errors.outbound_category_detail_id ?.message}
                            </Form.Text>
                          </Col>
                        </Form.Group>
                      </Card.Body>
                      <Modal.Footer>
                        {!isEmptyValue(channel) && (
                          <>
                            {mute ? (
                              <Button
                                variant="success"
                                onClick={handleUnMute}
                              >
                                Unmute
                                </Button>
                            ) : (
                                <Button variant="warning" onClick={handleMute}>
                                  Mute
                                </Button>
                              )}
                            <Button variant="danger" type="submit">
                              Hang Up
                              </Button>
                          </>
                        )}
                      </Modal.Footer>
                    </Form>
                  </Card>
                </Col>
              </Row>
            )}
            {tab === 2 && (
              <CustomerField CampaignId={campaignId} Customer={customer} />
            )}
            {tab === 3 && <CampaignInfo CampaignId={campaignId} CurrentData={campaignInfo} CurrentDataChange={setCampaignInfo} />}
            {tab === 4 && <CallHistories CustomerId={dataId} />}
          </Card.Body>
        </Card>

        {/* <Collapse in={schedule}>
          <Card>
            <Card.Body> */}
        {/* customer status muncul ketika online, ketika klik detail customer hanya ada schedule call */}
        {/* {customerStatus ? (
                <CustomerStatus handleModalClose={handleModalClose} customerId={dataId} setCustomerStatus={setCustomerStatus} />
              ) : (
                  <FormAdd customerId={dataId} campaignId={campaignId} phoneNo={phone_no} afterEffect={handleModalClose} />
                )}
            </Card.Body>
          </Card>
        </Collapse> */}
      </Modal.Body>

      {/* <Row> */}

      {isEmptyValue(channel) && (
        <>
          <Modal.Footer>
            {(customer.customer_status_id == 4 && (userLevelId == 2 || userLevelId == 5)) && (
              <Button variant="info" onClick={handleChecking}>
                Checking
            </Button>
            )}
            {( userLevelId == 1) && (
            <Button variant="warning" onClick={handleScheduleCall}>
              Schedule Call
            </Button>
            )}
          </Modal.Footer>
        </>
      )}
      {/* </Row> */}
    </>
  )
}

const NavTab = ({ setTab, tab, channel }) => {
  return (
    <Nav variant="tabs" defaultActiveKey={`link-${tab}`} className="mb-3">
      <Nav.Item>
        <Nav.Link eventKey="link-1" onClick={() => setTab(1)}>
          Call
        </Nav.Link>
      </Nav.Item>
      <Nav.Item>
        <Nav.Link eventKey="link-2" onClick={() => setTab(2)}>
          Customer
        </Nav.Link>
      </Nav.Item>
      <Nav.Item>
        <Nav.Link eventKey="link-3" onClick={() => setTab(3)}>
          Campain Info
        </Nav.Link>
      </Nav.Item>
      <Nav.Item>
        <Nav.Link eventKey="link-4" onClick={() => setTab(4)}>
          Call Histories
        </Nav.Link>
      </Nav.Item>
    </Nav>
  )
}


const initialOption = [
  {
    value: "",
    label: "Choose..."
  }
]

const initialCall = {
  note: "",
  outbound_category_id: "",
  outbound_category_detail_id: ""
}

const validationSchemaCall = yupResolver(
  yup.object().shape({
    note: yup.string().required("This field is required."),
    outbound_category_id: yup.string().required("This field is required."),
    outbound_category_detail_id: yup.string().required("This field is required."),
  })
)