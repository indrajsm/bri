import { Button, Form, Modal, Spinner, Table } from 'react-bootstrap'
import React, { useEffect, useState, useContext } from 'react'
import { useParams, Link } from 'react-router-dom';
import Select from 'react-select'
import _ from 'lodash'
import { Pagination, Notification } from './../../components'
import { FormAdd } from './FormAdd';
import { FormDetail } from './FormDetail';
import { FormAdd as ScheduleCall } from '../Callback/FormAdd';
import { useOutboundCategories, useOutboundCategoryDetails, useCustomers, useCustomerStatuses } from '../../utils/functions';
import { generalService } from '../../utils/services';
import { Checking } from '../Elements/Checking';
import { AuthContext } from '../../utils/context';

const { isEmptyValue } = generalService

export const CustomerCalls = (props) => {
    const { Get, Update } = useCustomers()
    const fnOutboundCategories = useOutboundCategories()
    const fnOutboundCategoryDetails = useOutboundCategoryDetails()
    const fnCustomerStatuses = useCustomerStatuses()
    const { userLevelId } = useContext(AuthContext)
    const { Error, Success, Warning } = Notification
    const [isLoading, setIsLoading] = useState(true)
    const [notif, setNotif] = useState(initialNotif)
    const [modalAdd, setModalAdd] = useState(initialModal)
    const [modalDetail, setModalDetail] = useState(initialModal)
    const [modalScheduleCall, setModalScheduleCall] = useState(initialModalScheduleCall)
    const [modalChecking, setModalChecking] = useState(initialModalChecking)
    const [modalConfirm, setModalConfirm] = useState(initialModal)
    const [tableData, setTableData] = useState({})
    const [outboundCategory, setOutboundCategory] = useState({})
    const [customerStatus, setCustomerStatus] = useState({})
    const [outboundCategoryDetail, setOutboundCategoryDetail] = useState({})
    const [alert, setAlert] = useState(null)
    const { campaignId } = useParams();

    const [formFilter, setFormFilter] = useState({
        fullname: "",
        phone_1: "",
        outbound_category_id: "",
        outbound_category_detail_id: "",
        customer_status_id: "",
        is_active: 1,
        campaign_id: campaignId
    })
    const [currentFilter, setCurrentFilter] = useState({
        page: 1,
        ...formFilter
    })

    const handleModalAdd = () => {
        setModalAdd({
            ...modalAdd,
            show: !modalAdd.show,
            dataId: campaignId
        })
    }

    const handleModalDetail = (id) => {
        setModalDetail({
            ...modalDetail,
            show: !modalDetail.show,
            dataId: id
        })
    }

    const handleModalScheduleCall = () => {
        setModalScheduleCall({
            ...modalScheduleCall,
            show: !modalScheduleCall.show
        })
    }

    const handleModalChecking = () => {
        setModalChecking({
            ...modalChecking,
            show: !modalChecking.show
        })
    }

    const handleChangeFormFilter = (key, val) => {
        setFormFilter({ ...formFilter, [key]: val })
    }

    const handleSubmitFormFilter = async (e) => {
        e.preventDefault()
        await setIsLoading(true)
        setCurrentFilter({
            page: 1,
            ...formFilter
        })
    }

    const handleModalClose = async () => {
        setModalAdd(initialModal)
        setModalDetail(initialModal)
        setModalConfirm(initialModal)
    }

    const handleModalCloseSchedule = () => {
        setModalScheduleCall(initialModalScheduleCall)
    }

    const handleModalCloseChecking = () => {
        setModalChecking(initialModalChecking)
    }

    const handleModalConfirm = async (id) => {
        setModalConfirm({
            ...modalConfirm,
            show: !modalConfirm.show,
            dataId: id
        })
    }

    const handleModalRevoke = async (id) => {
        setAlert(null)
        await Update(id, { is_active: 0 })
            .then(async res => {
                console.log(res)
                if (res.success) {
                    setAlert(1)
                    setIsLoading(true)
                } else {
                    setAlert(2)
                }
            })
            .catch(err => {
                return
            })
        handleModalClose()
        setIsLoading(true)
    }

    const handleAlert = (value) => {
        return (
            value && value === 1 ?
                <Success message="Revoke successed." /> :
                <Error message="Failed to revoke this customer." />
        )
    }

    const fnAbort = new AbortController()

    useEffect(() => {
        const fetchData = async () => {
            await Get(currentFilter).then(res => {
                setTableData(res)
                setIsLoading(false)
            }).catch((err) => { return () => fnAbort.abort() })
        }
        fetchData()
    }, [isLoading, currentFilter])

    useEffect(() => {
        if (formFilter.outbound_category_id) {
            const fetchDataDetail = async () => {
                await fnOutboundCategoryDetails.Get({ outbound_category_id: formFilter.outbound_category_id }).then(res => {
                    if (!isEmptyValue(res.data)) {
                        let outboundDetailOption = res.data.map((row) => {
                            return { value: row.id, label: row.name }
                        })

                        setOutboundCategoryDetail([
                            ...initialOption,
                            ...outboundDetailOption
                        ])
                    } else {
                        setOutboundCategoryDetail(initialOption)
                    }
                }).catch((err) => { return () => fnAbort.abort() })
            }
            fetchDataDetail()
        }
    }, [formFilter])

    useEffect(() => {
        const fnAbort = new AbortController()
        const fetchData = async () => {
            await fnOutboundCategories.Get().then(res => {
                if (!isEmptyValue(res.data)) {
                    let outboundOption = res.data.map((row) => {
                        return { value: row.id, label: row.name }
                    })

                    setOutboundCategory([
                        ...initialOption,
                        ...outboundOption
                    ])
                } else {
                    setOutboundCategory(initialOption)
                }
            }).catch((err) => { return })

        }
        const fetchDataStatus = async () => {
            await fnCustomerStatuses.Get().then(res => {
                if (!isEmptyValue(res.data)) {
                    let statusOption = res.data.map((row) => {
                        return { value: row.id, label: row.name }
                    })

                    setCustomerStatus([
                        ...initialOption,
                        ...statusOption
                    ])
                } else {
                    setCustomerStatus(initialOption)
                }
            }).catch((err) => { return })

        }
        fetchData()
        fetchDataStatus()
    }, [])

    return (
        <>
            <h1 className="mt-4">Customer Call</h1>
            <ol className="breadcrumb mb-4">
                <li className="breadcrumb-item"><Link to="/campaign-calls">Campaign Call</Link></li>
                <li className="breadcrumb-item active">Customer Call</li>
            </ol>
            {notif.show && notif.type === 'error' && <Error
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            {notif.show && notif.type === 'success' && <Success
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            {notif.show && notif.type === 'warning' && <Warning
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            <div className="card mb-4">
                <div className="card-header">
                    <i className="fas fa-table mr-1"></i> Filter Data
                </div>
                <div className="card-body">
                    <form onSubmit={handleSubmitFormFilter}>
                        <div className="form-row">
                            <div className="form-group col-md-3">
                                <label htmlFor="inputState">Name</label>
                                <input type="text" id="inputState" className="form-control" onChange={e => handleChangeFormFilter("fullname", e.target.value)} />
                            </div>
                            <div className="form-group col-md-3">
                                <label htmlFor="inputState">Phone Number 1</label>
                                <input type="text" id="inputState" className="form-control" onChange={e => handleChangeFormFilter("phone_1", e.target.value)} />
                            </div>
                            <div className="form-group col-md-3">
                                <label htmlFor="inputState">Customer Status</label>
                                <Select
                                    options={customerStatus}
                                    onChange={(selected) => handleChangeFormFilter("customer_status_id", selected.value)}
                                    value={!isEmptyValue(customerStatus) && customerStatus.filter((opt) => {
                                        return opt.value === formFilter.customer_status_id;
                                    })}
                                />
                            </div>
                        </div>
                        <div className="form-row">
                            <div className="form-group col-md-3">
                                <label htmlFor="inputState">Outbound Category</label>
                                <Select
                                    options={outboundCategory}
                                    onChange={(selected) => handleChangeFormFilter("outbound_category_id", selected.value)}
                                    value={!isEmptyValue(outboundCategory) && outboundCategory.filter((opt) => {
                                        return opt.value === formFilter.outbound_category_id;
                                    })}
                                />
                            </div>
                            <div className="form-group col-md-3">
                                <label htmlFor="inputState">Outbound Category Detail</label>
                                <Select
                                    options={outboundCategoryDetail}
                                    onChange={(selected) => handleChangeFormFilter("outbound_category_detail_id", selected.value)}
                                    value={!isEmptyValue(outboundCategoryDetail) && outboundCategoryDetail.filter((opt) => {
                                        return opt.value === formFilter.outbound_category_detail_id;
                                    })}
                                />
                            </div>
                        </div>
                        <div className="form-row">
                        </div>
                        <button type="submit" className="btn btn-primary">Search</button>
                    </form>
                </div>
            </div>
            <div className="card mb-4">
                <div className="card-body">
                    {/* <ExportToExcel rawData={exportData} fileName="user-data" />&nbsp; */}
                    {
                        alert && handleAlert(alert)
                    }
                    {(userLevelId == 2 || userLevelId == 5) &&

                        <Button variant="outline-primary" onClick={handleModalAdd}>Upload Customer</Button>
                    }
                    <hr />
                    <div className="table-responsive">
                        <Table striped hover responsive width="100%" cellSpacing="0" cellPadding="0">
                            <thead className="thead-dark text-nowrap">
                                <tr className="text-center">
                                    <th>No.</th>
                                    <th >Customer Name</th>
                                    <th>Phone 1</th>
                                    <th>Attempt Call</th>
                                    <th>Last Call Date</th>
                                    <th>Outbound Category</th>
                                    <th>Outbound Category Detail</th>
                                    <th>Status Customer</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr className="text-center">
                                    <th>No.</th>
                                    <th>Customer Name</th>
                                    <th>Phone 1</th>
                                    <th>Attempt Call</th>
                                    <th>Last Call Date</th>
                                    <th>Outbound Category</th>
                                    <th>Outbound Category Detail</th>
                                    <th>Status Customer</th>
                                    <th>Action</th>
                                </tr>
                            </tfoot>
                            <tbody className=" text-nowrap">
                                {isLoading ? (
                                    <tr>
                                        <td colSpan="9" className="text-center">
                                            <Spinner animation="border" size="sm" className="mr-1" />
                                            Loading data...
                                        </td>
                                    </tr>
                                ) : (
                                        tableData.total_data > 0 ? (
                                            tableData.data.map((item, i) => (
                                                <tr key={item.id} className="text-center">
                                                    <td>{tableData.paging.index[i]}</td>
                                                    <td>{item.fullname}</td>
                                                    <td>{item.phone_1}</td>
                                                    <td>{item.total_call_attempt}</td>
                                                    <td>{item.last_call_date && item.last_call_date.substring(0, 10)}</td>
                                                    <td>{item.outbound_category_name}</td>
                                                    <td>{item.outbound_category_detail_name}</td>
                                                    <td>{item.customer_status_name}</td>
                                                    <td>
                                                        {(userLevelId == 2 || userLevelId == 5 || userLevelId == 1) &&
                                                            <Button variant="warning" size="sm" className="m-1" data-toggle="modal" onClick={(e) => { handleModalDetail(item.id) }}>
                                                                <i className="fas fa-search fa-fw"></i>
                                                            </Button>
                                                        }
                                                        {(userLevelId == 2 || userLevelId == 5) &&
                                                            <Button variant="danger" size="sm" className="m-1" data-toggle="modal" title="Revoke" onClick={(e) => { handleModalConfirm(item.id, item.name) }}>
                                                                <i className="fas fa-undo fa-fw"></i>
                                                            </Button>
                                                        }
                                                    </td>
                                                </tr>
                                            ))
                                        ) : (
                                                <>
                                                    <tr>
                                                        <td colSpan="8" className="text-center"><span className="text-danger">No data found</span></td>
                                                    </tr>
                                                </>
                                            )
                                    )}
                            </tbody>
                        </Table>
                    </div>
                    {isLoading === false && !_.isEmpty(tableData) &&
                        <Pagination
                            total={tableData.total_data}
                            limit={tableData.limit}
                            paging={tableData.paging}
                            pageChange={async (pageNumber) => {
                                await setIsLoading(true)
                                setCurrentFilter({
                                    ...currentFilter,
                                    page: pageNumber
                                })
                            }}
                        />
                    }
                </div>
            </div>
            <Modal show={modalAdd.show} onHide={handleModalClose} backdrop="static" keyboard={false} >
                <Modal.Header closeButton>
                    <Modal.Title>Import Campaign</Modal.Title>
                </Modal.Header>
                <FormAdd
                    dataId={modalAdd.dataId}

                    modalChange={(params) => {
                        setModalAdd({
                            ...modalAdd,
                            ...params
                        })
                    }}
                    notifChange={(value) => {
                        setNotif(value)
                    }}
                    dataChange={async () => {
                        await setIsLoading(true)
                    }}
                    isLoading={isLoading}
                    setIsLoading={setIsLoading}
                />
            </Modal>
            <Modal show={modalDetail.show} onHide={handleModalClose} backdrop="static" keyboard={false} size="lg">
                <Modal.Header closeButton>
                    <Modal.Title>Customer Detail</Modal.Title>
                </Modal.Header>
                <FormDetail
                    dataId={modalDetail.dataId}
                    campaignId={campaignId}
                    modalChange={(params) => {
                        setModalDetail({
                            ...modalDetail,
                            ...params
                        })
                    }}
                    notifChange={(value) => {
                        setNotif(value)
                    }}
                    dataChange={async () => {
                        await setIsLoading(true)
                    }}
                    handleModalClose={handleModalClose}
                    handleScheduleCall={handleModalScheduleCall}
                    handleChecking={handleModalChecking}
                />
            </Modal>

            <Modal show={modalScheduleCall.show} onHide={handleModalCloseSchedule} backdrop="static" keyboard={false}>
                <Modal.Header closeButton>
                    <Modal.Title>Schedule Call</Modal.Title>
                </Modal.Header>
                <ScheduleCall
                    handleModalClose={handleModalCloseSchedule}
                    dataChange={() => { }}
                    customerId={modalDetail.dataId}
                    campaignId={campaignId}
                    phoneNo={''} />
            </Modal>

            <Modal show={modalChecking.show} onHide={handleModalCloseChecking} backdrop="static" keyboard={false}>
                <Modal.Header closeButton>
                    <Modal.Title>Checking</Modal.Title>
                </Modal.Header>
                <Checking
                    handleModalClose={handleModalCloseChecking}
                    customerId={modalDetail.dataId}
                />
            </Modal>

            <Modal show={modalConfirm.show} onHide={handleModalClose} backdrop="static" keyboard={false} >
                <Modal.Header closeButton>
                    <Modal.Title>Confirm Revoke</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    Are you sure want to revoke this customer?
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="danger" onClick={handleModalClose}>No</Button>
                    <Button variant="primary" onClick={e => { handleModalRevoke(modalConfirm.dataId) }}>
                        Yes
                    </Button>
                </Modal.Footer>
            </Modal>
        </>
    )
}

const initialNotif = {
    title: "",
    message: "",
    show: false,
    type: null
}

const initialModal = {
    show: false,
    dataId: null
}

const initialModalScheduleCall = {
    show: false,
    dataId: ""
}

const initialModalChecking = {
    show: false,
    dataId: ""
}


const initialOption = [{
    value: "",
    label: "Choose..."
}]
