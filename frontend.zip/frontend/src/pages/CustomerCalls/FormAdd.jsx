import React, { useEffect, useState, useCallback } from 'react'
import { Button, Form, Modal, InputGroup, Collapse, Spinner, Row, Col, Card } from 'react-bootstrap'
import { useForm } from 'react-hook-form'
import Select from "react-select";
import { Notification } from '../../components'
import { campaignController, campaignFieldController } from '../../utils/controllers';
import { useCampaigns, useCampaignFields, useCustomerFields } from '../../utils/functions';
import { generalService } from '../../utils/services';

const { isEmptyValue } = generalService

export const FormAdd = ({ modalChange, notifChange, dataChange, dataId }) => {
    const { Upload, ImportCampaignCall } = useCampaigns()
    const { Get } = useCampaignFields()
    const { register, handleSubmit } = useForm();
    const { register: register2, handleSubmit: handleSubmit2 } = useForm();
    const [processUpload, setProcessUpload] = useState(false)
    const [process, setProcess] = useState(false)
    const [field, setField] = useState({})
    const [column, setColumn] = useState({})
    const [mapping, setMapping] = useState(false)
    const [uploadId, setUploadId] = useState('')
    const [alert, setAlert] = useState(null)
    const { Success, Error } = Notification

    const handleModalClose = useCallback(() => {
        modalChange({
            show: false,
            dataId: ''
        })
    }, [modalChange])

    const handleAlert = (value) => {
        return (
            value && value === 1 ?
                <Success message="File has been uploaded." /> :
                <Error message="Failed to upload file or File Duplicated." />
        )
    }

    // add upload excel
    const onSubmit = async (data) => {
        const formData = new FormData()
        formData.append("file", data.file[0])
        setProcessUpload(true)
        setAlert(null)
        await Upload(dataId, formData).then((res) => {
            if (res.success) {
                setUploadId(res.data.id)
                setMapping(true)
                setColumn(res)
                setProcessUpload(false)
                setAlert(1)
            } else {
                setProcessUpload(false)
                setAlert(2)
            }
        }).catch((err) => { return })

    }

    const onSubmitMapping = async (data) => {
        setProcess(true)

        await ImportCampaignCall(dataId, { ...data, file_upload_id: uploadId }).then((res) => {
            if (res.success) {
                notifChange({
                    title: "Success",
                    message: "Data has been added.",
                    show: true,
                    type: "success"
                })
                dataChange()
                setProcess(false)
            } else {
                setProcess(false)
                notifChange({
                    title: "Error",
                    message: "Failed to mapping data.",
                    show: true,
                    type: "error"
                })
            }
            handleModalClose()
        }).catch((err) => { return })


    }

    useEffect(() => {
        if (mapping) {
            const fnAbort = new AbortController()
            const fetchData = async () => {
                await Get({
                    limit: "100",
                    order: "field_name_display",
                    campaign_id: dataId,
                    is_active: 1
                }).then((res) => {
                    if (!isEmptyValue(res.data)) {
                        setField(res)
                    }
                }).catch((err) => { return () => fnAbort.abort() })
            }
            fetchData()
        }
    }, [mapping])

    return (
        <>
            <Modal.Body>
                {
                    alert && handleAlert(alert)
                }
                <Card className="mb-3">
                    <Card.Header>Import Customer</Card.Header>
                    <Card.Body>
                        <Form className="mb-3" onSubmit={handleSubmit(onSubmit)}>
                            <label className="btn btn-default">
                                <input type="file" {...register("file")} required />
                            </label>

                            <button
                                className="btn btn-info"
                            >
                                {processUpload ? <Spinner animation="border" size="sm" className="mr-1" /> : 'Upload'}
                            </button>
                        </Form>
                    </Card.Body>
                </Card>
                <Collapse in={mapping}>
                    <Card>
                        <Card.Header>Mapping Column</Card.Header>
                        <Card.Body>
                            <Form onSubmit={handleSubmit2(onSubmitMapping)}>
                                <Form.Group as={Row} className="mb-3 ml-1 mr-1" style={{ overflowY: "scroll", maxHeight: "20rem" }}>
                                    {
                                        field.total_data > 0 && field.data.map((item, index) =>
                                            <>
                                                <Col sm="6" key={index}>
                                                    <InputGroup className="mb-3">
                                                        <InputGroup.Text id="basic-addon2" style={{ width: '11rem' }}>
                                                            {item.field_display_name}
                                                        </InputGroup.Text>
                                                        <select className="form-control"  {...register2(item.field_name)} >
                                                            <option value="">Select Field</option>
                                                            {column.total_data > 0 && column.data.header.map(item => (
                                                                <option key={item.index} value={item.index}>
                                                                    {item.field}
                                                                </option>
                                                            ))}
                                                        </select>
                                                    </InputGroup>
                                                </Col>
                                            </>
                                        )
                                    }
                                </Form.Group >
                                <Form.Group as={Row} className="mb-3 mr-4 float-right" >
                                    <Button type="submit" variant="primary">{process ? <Spinner animation="border" size="sm" className="mr-1" /> : 'Save'}</Button>
                                </Form.Group >
                            </Form>
                        </Card.Body>
                    </Card>
                </Collapse>
            </Modal.Body>
            {/* <Modal.Footer>
            </Modal.Footer> */}
        </>
    )
}

