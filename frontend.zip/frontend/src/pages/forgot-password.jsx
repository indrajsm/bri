import React, { useEffect, useState, useContext } from 'react'
import { useForm } from 'react-hook-form'
import { publicApi } from '../utils/services/'
import { Notification } from '../components';
import { useHistory, Redirect, Link } from 'react-router-dom'
import { AuthContext } from '../utils/context';
import '../public/assets/styles/login.css'
import { BriLogo } from '../public/assets';

export const ForgotPassword = () => {
    const [showNotif, setShowNotif] = useState(false)
    const { register, handleSubmit, formState: { errors } } = useForm()
    const history = useHistory()
    const { user, setUser, isAuth, setIsAuth } = useContext(AuthContext)
    const onSubmit = async (data) => {
        console.log(data)
        const body = {
            username: data.username,
            password: data.password,
            extension: data.extension
        }
        try {
            const login = await publicApi('post', '/token', body)

            if (login.data.token) {
                localStorage.setItem('user', body.username)
                localStorage.setItem('isAuth', true)
                setUser(body.username)
                setIsAuth(true)
            }

        } catch (error) {
            setShowNotif(true)
            setTimeout(() => {
                setShowNotif(false)
            }, 5000);
        }
    }

    return (
        <div className="login-container">
            <h1>forgot Password</h1>
            {/* <div className="row">
                <div class="col-md-6 login-form-2">
                    <img src={BriLogo} />
                </div>
                <div className="col-md-6 login-form-1">
                    <h3>Forgot</h3>
                    {showNotif && <Notification.Error title="" message="Your username or password is incorrect." />}
                    <form onSubmit={handleSubmit(onSubmit)}>
                        <div className="form-group">
                            <input type="email" className="form-control" placeholder="Email" {...register("email", { required: true })} />
                            {errors.username && <span className="text-white">*Email is required</span>}
                        </div>
                        <div className="form-group">
                            <button type="submit" className="btnSubmit">Submit</button>
                        </div>
                        <div className="form-group">
                            <Link to="/login" className="ForgetPwd" value="Forgot">Already have an account? Login!</Link>
                        </div>
                    </form>
                </div>

            </div> */}
        </div>
    )
}
