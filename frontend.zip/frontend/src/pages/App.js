import React, { useContext } from 'react'

import { Routes } from '../config';
import { AuthProvider, ModalFormProvider, SocketProvider, CallProvider, UserActivityProvider } from '../utils/context';

const App = () => {
  return (
    <>
      <AuthProvider>
        <UserActivityProvider>
          <SocketProvider>
            <CallProvider>
              <ModalFormProvider>
                <Routes />
              </ModalFormProvider>
            </CallProvider>
          </SocketProvider>
        </UserActivityProvider>
      </AuthProvider>
    </>
  )
}

export default App

