import { useState, useEffect, useContext } from 'react'
import { Button, Form, Modal, Spinner, Table } from 'react-bootstrap'
import _ from 'lodash'
import { generalService } from './../../utils/services'
import { useQualityAssurances } from './../../utils/functions'
import { Pagination, Notification } from './../../components'
import { FormAdd } from './FormAdd'
import { FormDetail } from './FormDetail'

const { isEmptyValue } = generalService

export const QualityAssurance = (props) => {
    const { Get, Delete } = useQualityAssurances()
    const { Error, Success, Warning} = Notification

    const [loading, setLoading] = useState(true)
    const [notif, setNotif] = useState(initialNotif)
    const [tableData, setTableData] = useState({})
    const [modalAdd, setModalAdd] = useState(initialModal)
    const [modalDetail, setModalDetail] = useState(initialModal)
    const [modalDelete, setModalDelete] = useState(initialModal)
    const [formFilter, setFormFilter] = useState({
        name: ""
    })
    const [currentFilter, setCurrentFilter] = useState({
        page: 1,
        is_active: 1,
        order: "name",
        ...formFilter
    })
    const [submittingDelete, setSubmittingDelete] = useState(false)

    useEffect(() => {
        const fetchData = async () => {
            await Get(currentFilter).then((res) => {
                setTableData(res)
                setLoading(false)
            }).catch((err) => { return }) //do nothing, let it go back to login
        }

        if (loading) fetchData()
        return () => setLoading(false)
    }, [loading])

    const handleChangeFormFilter = (key, val) => {
        setFormFilter({ ...formFilter, [key]: val })
    }

    const handleSubmitFormFilter = (e) => {
        e.preventDefault()

        setCurrentFilter({
            ...currentFilter,
            ...formFilter,
            page: 1
        })
        setLoading(true)
    }

    const handleModalClose = () => {
        setModalAdd(initialModal)
        setModalDetail(initialModal)
        setModalDelete(initialModal)
    }

    const handleModalAdd = () => {
        setModalAdd({
            ...modalAdd,
            show: !modalAdd.show
        })
    }

    const handleModalDetail = (id) => {
        setModalDetail({
            ...modalDetail,
            show: !modalDetail.show,
            dataId: id
        })
    }

    const handleModalDelete = (id) => {
        setModalDelete({
            ...modalDelete,
            show: !modalDelete.show,
            dataId: id
        })
    }

    const handleSubmitFormDelete = async (e) => {
        e.preventDefault()
        setSubmittingDelete(true)

        await Delete(modalDelete.dataId).then((res) => {
            if (res.success) {
                setNotif({
                    ...notif,
                    title: "Success",
                    message: "Data has been deleted.",
                    show: true,
                    type: "success"
                })
                setLoading(true)
            } else {
                setNotif({
                    ...notif,
                    title: "Error",
                    message: "Failed to delete data.",
                    show: true,
                    type: "error"
                })
            }

            setSubmittingDelete(false)
            handleModalClose()
        }).catch((err) => { return }) //do nothing, let it go back to login
    }

    return (
        <>
            <h1 className="mt-4">Quality Assurance</h1>
            <ol className="breadcrumb mb-4">
                <li className="breadcrumb-item">Quality Assurance</li>
                <li className="breadcrumb-item active">List</li>
            </ol>
            {notif.show && notif.type === 'error' && <Error
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            {notif.show && notif.type === 'success' && <Success
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            {notif.show && notif.type === 'warning' && <Warning
                title={notif.title}
                message={notif.message}
                show={notif.show}
                showChange={() => { setNotif(initialNotif) }}
            />}
            <div className="card mb-4">
                <div className="card-header">
                    <i className="fas fa-table mr-1"></i> Filter Data
                </div>
                <div className="card-body">
                    <form onSubmit={handleSubmitFormFilter}>
                        <div className="form-row">
                            <Form.Group className="col-md-2" controlId="name">
                                <Form.Label>Name</Form.Label>
                                <Form.Control
                                    type="text"
                                    value={formFilter.name}
                                    onChange={e => handleChangeFormFilter("name", e.target.value)}
                                />
                            </Form.Group>
                        </div>
                        <div className="form-row">
                            <Form.Group className="col-md-12 mb-0">
                                <Button type="submit" variant="primary">Search</Button>
                            </Form.Group>
                        </div>
                    </form>
                </div>
            </div>
            <div className="card mb-4">
                <div className="card-body">
                    <Button variant="outline-primary" onClick={handleModalAdd}>Add Data</Button>
                    <hr />
                    <Table striped hover responsive width="100%" cellSpacing="0" cellPadding="0">
                        <thead className="thead-dark">
                            <tr>
                                <th width="8%">No.</th>
                                <th width="">QA Type</th>
                                <th width="12%" className="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {loading &&
                                <tr>
                                    <td colSpan="3" className="text-center">
                                        <Spinner animation="border" size="sm" className="mr-1" />
                                        Loading data...
                                    </td>
                                </tr>
                            }
                            {!loading && isEmptyValue(tableData.data) &&
                                <tr>
                                    <td colSpan="3" className="text-center">
                                        <span className="text-danger">No data found</span>
                                    </td>
                                </tr>
                            }
                            {!loading && !isEmptyValue(tableData.data) &&
                                tableData.data.map((row, i) => (
                                    <tr key={ row.id }>
                                        <td>{ tableData.paging.index[i] }</td>
                                        <td>{ row.name }</td>
                                        <td className="text-center">
                                            <Button variant="warning" size="sm" className="m-1" title="Detail Data" onClick={(e) => { handleModalDetail(row.id) }}>
                                                <i className="fas fa-edit fa-fw"></i>
                                            </Button>
                                            <Button variant="danger" size="sm" className="m-1" title="Delete Data" onClick={(e) => { handleModalDelete(row.id) }}>
                                                <i className="fas fa-trash-alt fa-fw"></i>
                                            </Button>
                                        </td>
                                    </tr>
                                ))
                            }
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>No.</th>
                                <th>QA Type</th>
                                <th>Action</th>
                            </tr>
                        </tfoot>
                    </Table>

                    {!loading && !isEmptyValue(tableData.paging) &&
                         <Pagination
                            total={tableData.total_data}
                            limit={tableData.limit}
                            paging={tableData.paging}
                            pageChange={(page) => {
                                setCurrentFilter({
                                    ...currentFilter,
                                    page: page
                                })
                                setLoading(true)
                            }}
                        />
                    }
                </div>
            </div>

            <Modal show={modalAdd.show} onHide={handleModalClose} backdrop="static" keyboard={false}>
                <FormAdd
                    modalChange={(params) => {
                        handleModalClose()
                    }}
                    notifChange={(params) => {
                        setNotif({
                            ...notif,
                            ...params
                        })
                    }}
                    dataChange={() => {
                        setLoading(true)
                    }}
                />
            </Modal>

            <Modal show={modalDetail.show} onHide={handleModalClose} backdrop="static" keyboard={false}>
                <FormDetail
                    modalChange={(params) => {
                        handleModalClose()
                    }}
                    notifChange={(params) => {
                        setNotif({
                            ...notif,
                            ...params
                        })
                    }}
                    dataChange={() => {
                        setLoading(true)
                    }}
                    dataId={modalDetail.dataId}
                />
            </Modal>

            <Modal show={modalDelete.show} onHide={handleModalClose} backdrop="static" keyboard={false}>
                <Modal.Header closeButton={submittingDelete ? false : true}>
                    <Modal.Title>Delete QA</Modal.Title>
                </Modal.Header>
                <Form onSubmit={handleSubmitFormDelete}>
                    <Modal.Body className="text-center">
                        <i className="fas fa-exclamation-triangle fa-3x d-block text-danger"></i>
                        <h5 className="mt-2 mb-0">Are you sure delete this data?</h5>
                        <span className="text-muted">This action cannot be undone.</span>
                    </Modal.Body>
                    <Modal.Footer>
                        <Button variant="danger" type="submit" disabled={submittingDelete}>
                            {submittingDelete && <Spinner animation="border" size="sm" className="mr-1" />} Delete
                        </Button>
                        <Button variant="light" disabled={submittingDelete} onClick={handleModalClose}>Cancel</Button>
                    </Modal.Footer>
                </Form>
            </Modal>
        </>
    )
}

const initialNotif = {
    title: "",
    message: "",
    show: false,
    type: null
}

const initialModal = {
    show: false,
    dataId: null
}