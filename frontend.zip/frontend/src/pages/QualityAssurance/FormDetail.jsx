import { useState, useEffect, useCallback, useContext } from 'react'
import { Button, Form, Modal, Spinner, Row, Table, Collapse } from 'react-bootstrap'
import { useForm, Controller } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import _ from 'lodash'
import classnames from 'classnames'
import { generalService } from './../../utils/services'
import { useQualityAssurances, useQualityAssuranceAspects } from '../../utils/functions'

const { isEmptyValue, formatDate, formatDateTime } = generalService

export const FormDetail = ({ dataChange, modalChange, notifChange, dataId }) => {
    const fnQualityAssurances = useQualityAssurances()
    const { handleSubmit, formState: { errors, isSubmitting }, register, reset } = useForm({
        defaultValues: initialData,
        resolver: validationSchema
    })
    const [loading, setLoading] = useState(true)
    const [toggle, setToggle] = useState({
        showFormData: false,
        showTableData: true,
        isDisabled: false,
        qualityAssuranceAspectId: ""
    })

    useEffect(() => {
        const fetchData = async () => {
            await fnQualityAssurances.Get({id: dataId}).then((res) => {
                if (!isEmptyValue(res.data)) {
                    reset({
                        ...initialData,
                        name: res.data.name || ""
                    }, {keepErrors: false})
                }
            }).catch((err) => { return }) //do nothing, let it go back to login
        }

        if (dataId) return fetchData()
    }, [dataId])

    const onSubmitForm = async (data, e) => {
        e.preventDefault()

        await fnQualityAssurances.Update(dataId, data).then((res) => {
            if (res.success) {
                notifChange({
                    title: "Success",
                    message: "Data has been updated.",
                    show: true,
                    type: "success"
                })
                dataChange()
            } else {
                notifChange({
                    title: "Error",
                    message: "Failed to update data.",
                    show: true,
                    type: "error"
                })
            }

            handleModalClose()
        }).catch((err) => { return }) //do nothing, let it go back to login
    }

    const handleModalClose = () => {
        return modalChange({
            show: false,
            dataId: null
        })
    }

    const handleToggle = (id) => {
        setToggle({
            ...toggle,
            showFormData: !toggle.showFormData,
            showTableData: !toggle.showTableData,
            isDisabled: !toggle.isDisabled,
            qualityAssuranceAspectId: !isEmptyValue(id) ? id : ""
        })
    }

    return (
        <>
            <Modal.Header closeButton={isSubmitting ? false : true}>
                <Modal.Title>Detail QA</Modal.Title>
            </Modal.Header>
            <Form onSubmit={handleSubmit(onSubmitForm)}>
                <Modal.Body className="py-1">
                    <Form.Group controlId="QaName">
                        <Form.Label>QA Type <span className="text-danger">*</span></Form.Label>
                        <Form.Control
                            type="text"
                            size="sm"
                            isInvalid={!!errors.name}
                            disabled={toggle.isDisabled}
                            {...register("name")}
                        />
                        <Form.Control.Feedback type="invalid">{errors.name?.message}</Form.Control.Feedback>
                    </Form.Group>
                </Modal.Body>
                <Collapse in={toggle.showTableData} unmountOnExit={false} mountOnEnter={true}>
                    <div className="collapse-wrapper">
                        <Modal.Body className="py-0">
                            <div className="mb-2 text-right">
                                <Button variant="success" size="sm" onClick={() => handleToggle()}>New Aspect</Button>
                            </div>
                            <TableDataAspect
                                loading={loading}
                                loadingChange={() => {
                                    setLoading(!loading)
                                }}
                                toggleChange={(params) => {
                                    setToggle({
                                        ...toggle,
                                        ...params
                                    })
                                }}
                                qualityAssuranceId={dataId}
                            />
                        </Modal.Body>
                        <Modal.Footer>
                            <Button variant="primary" type="submit" disabled={isSubmitting}>
                                {isSubmitting && <Spinner animation="border" size="sm" className="mr-1" />} Save
                            </Button>
                            <Button variant="light" disabled={isSubmitting} onClick={handleModalClose}>Close</Button>
                        </Modal.Footer>
                    </div>
                </Collapse>
            </Form>
            <FormDataAspect
                showFormData={toggle.showFormData}
                loadingChange={() => {
                    setLoading(!loading)
                }}
                toggleChange={(params) => {
                    setToggle({
                        ...toggle,
                        ...params
                    })
                }}
                qualityAssuranceId={dataId}
                qualityAssuranceAspectId={toggle.qualityAssuranceAspectId}
            />
        </>
    )
}

const TableDataAspect = ({ loading, loadingChange, toggleChange, qualityAssuranceId }) => {
    const fnQualityAssuranceAspects = useQualityAssuranceAspects()
    const [tableData, setTableData] = useState({})
    const [currentFilter, setCurrentFilter] = useState({
        page: 1,
        limit: 5,
        is_active: 1,
        order: "name",
        quality_assurance_id: qualityAssuranceId
    })

    useEffect(() => {
        const fetchData = async () => {
            await fnQualityAssuranceAspects.Get(currentFilter).then((res) => {
                setTableData(res)
                loadingChange()
            }).catch((err) => { return }) //do nothing, let it go back to login
        }

        if (loading) fetchData()
        return () => loadingChange()
    }, [loading])

    const handleDeleteData = async (id) => {
        await fnQualityAssuranceAspects.Delete(id).then((res) => {
            if (res.success) {
                loadingChange()
            }
        }).catch((err) => { return }) //do nothing, let it go back to login
    }

    const handleToggleChange = useCallback((id) => {
        toggleChange({
            showFormData: true,
            showTableData: false,
            isDisabled: !isEmptyValue(id) ? true : false,
            qualityAssuranceAspectId: !isEmptyValue(id) ? id : ""
        })
    }, [toggleChange])

    return (
        <>
            <Table striped bordered hover responsive width="100%" className="mb-2" size="sm">
                <thead className="thead-dark">
                    <tr>
                        <th width="50%">Aspect</th>
                        <th width="25%">Bobot</th>
                        <th width="25%" className="text-center">Action</th>
                    </tr>
                </thead>
                <tbody>
                    {loading &&
                        <tr>
                            <td colSpan="3" className="text-center">
                                <Spinner animation="border" size="sm" className="mr-1" />
                                Loading data...
                            </td>
                        </tr>
                    }
                    {!loading && isEmptyValue(tableData.data) &&
                        <tr>
                            <td colSpan="3" className="text-center">
                                <span className="text-danger">No data found</span>
                            </td>
                        </tr>
                    }
                    {!loading && !isEmptyValue(tableData.data) &&
                        tableData.data.map((row, i) => (
                            <tr key={ row.id }>
                                <td>{ row.aspect_name }</td>
                                <td>{ row.bobot }</td>
                                <td className="text-center">
                                    <Button variant="warning" className="m-1" title="Detail Data" size="sm" onClick={(e) => { handleToggleChange(row.id) }}>
                                        <i className="fas fa-edit fa-fw"></i>
                                    </Button>
                                    <Button variant="danger" className="m-1" title="Delete Data" size="sm" onClick={(e) => { handleDeleteData(row.id) }}>
                                        <i className="fas fa-trash-alt fa-fw"></i>
                                    </Button>
                                </td>
                            </tr>
                        ))
                    }
                </tbody>
            </Table>
            {!loading && !isEmptyValue(tableData.paging) &&
                <div className="d-flex justify-content-between pb-2">
                    <Button variant="info" size="sm" onClick={() => {
                        setCurrentFilter({
                            ...currentFilter,
                            page: tableData.paging.previuos
                        })
                        loadingChange()
                    }} className={classnames('mr-auto', {
                        'd-none': tableData.paging.current === tableData.paging.previuos
                    })}>Prev</Button>
                    <Button variant="info" size="sm" onClick={() => {
                        setCurrentFilter({
                            ...currentFilter,
                            page: tableData.paging.next
                        })
                        loadingChange()
                    }} className={classnames('ml-auto', {
                        'd-none': tableData.paging.current === tableData.paging.next
                    })}>Next</Button>
                </div>
            }
        </>
    )
}

const FormDataAspect = ({ showFormData, loadingChange, toggleChange, qualityAssuranceId, qualityAssuranceAspectId }) => {
    const fnQualityAssuranceAspects = useQualityAssuranceAspects()
    const { handleSubmit, formState: { errors, isSubmitting }, register, reset } = useForm({
        defaultValues: initialDataAspect,
        resolver: validationSchemaAspect
    })

    useEffect(() => {
        const fetchData = async () => {
            if (isEmptyValue(qualityAssuranceAspectId)) {
                return reset({
                    ...initialDataAspect,
                    quality_assurance_id: qualityAssuranceId
                }, {keepErrors: false})
            }

            await fnQualityAssuranceAspects.Get({id: qualityAssuranceAspectId}).then((res) => {
                if (!isEmptyValue(res.data)) {
                    reset({
                        ...initialDataAspect,
                        aspect_name: res.data.aspect_name || "",
                        bobot: res.data.bobot || "",
                        quality_assurance_id: res.data.quality_assurance_id || ""
                    }, {keepErrors: false})
                }
            }).catch((err) => { return }) //do nothing, let it go back to login
        }

        fetchData()
    }, [qualityAssuranceAspectId])

    const onSubmitFormAspect = async (data, e) => {
        e.preventDefault()

        if (isEmptyValue(qualityAssuranceAspectId)) {
            await fnQualityAssuranceAspects.Create(data).then((res) => {
                if (res.success) {
                    loadingChange()
                }
    
                handleToggleChange()
            }).catch((err) => { return }) //do nothing, let it go back to login
        } else {
            await fnQualityAssuranceAspects.Update(qualityAssuranceAspectId, data).then((res) => {
                if (res.success) {
                    loadingChange()
                }
    
                handleToggleChange()
            }).catch((err) => { return }) //do nothing, let it go back to login
        }
    }

    const handleToggleChange = useCallback(() => {
        toggleChange({
            showFormData: false,
            showTableData: true,
            isDisabled: false,
            qualityAssuranceAspectId: ""
        })
    }, [toggleChange])

    return (
        <>
            <Collapse in={showFormData} unmountOnExit={false} mountOnEnter={true}>
                <Form onSubmit={handleSubmit(onSubmitFormAspect)}>
                    <Modal.Body className="py-0">
                        <Row>
                            <Form.Group controlId="AspectName" className="col-md-8">
                                <Form.Label>Aspect <span className="text-danger">*</span></Form.Label>
                                <Form.Control
                                    type="text"
                                    size="sm"
                                    isInvalid={!!errors.aspect_name}
                                    {...register("aspect_name")}
                                />
                                <Form.Control.Feedback type="invalid">{errors.aspect_name?.message}</Form.Control.Feedback>
                            </Form.Group>
                            <Form.Group controlId="AspectBobot" className="col-md-4">
                                <Form.Label>Bobot <span className="text-danger">*</span></Form.Label>
                                <Form.Control
                                    type="text"
                                    size="sm"
                                    isInvalid={!!errors.bobot}
                                    {...register("bobot")}
                                />
                                <Form.Control.Feedback type="invalid">{errors.bobot?.message}</Form.Control.Feedback>
                            </Form.Group>
                        </Row>
                    </Modal.Body>
                    <Modal.Footer>
                        <Button variant="primary" type="submit" disabled={isSubmitting}>
                            {isSubmitting && <Spinner animation="border" size="sm" className="mr-1" />} Save Aspect
                        </Button>
                        <Button variant="light" onClick={handleToggleChange}>Cancel</Button>
                    </Modal.Footer>
                </Form>
            </Collapse>
        </>
    )
}

const initialData = {
    name: ""
}

const initialDataAspect = {
    quality_assurance_id: "",
    aspect_name: "",
    bobot: ""
}

const validationSchema = yupResolver(yup.object().shape({
    name: yup.string()
        .required("This field is required.")
}))

const validationSchemaAspect = yupResolver(yup.object().shape({
    aspect_name: yup.string()
        .required("This field is required."),
    bobot: yup.string()
        .required("This field is required.")
        .matches(/^[0-9]+$/, "This field must contain only numbers.")
        .matches(/^([1-9][0-9]{0,1}|100)$/, "This field must contain number from 1 to 100.")
}))