import React, { useContext, useEffect, useState } from 'react'
import { Button, Form, Modal, Spinner, Table, Row, Col, InputGroup } from 'react-bootstrap'
import Highcharts from 'highcharts'
import HighchartsExporting from 'highcharts/modules/exporting'
import HighchartsReact from 'highcharts-react-official'
import _ from 'lodash'
import io from 'socket.io-client'
import Select from 'react-select'
import { generalService } from '../utils/services'
import { cookieService } from '../utils/services'
import { campaignController } from '../utils/controllers/campaignController'

const { isEmptyValue } = generalService

if (typeof Highcharts === 'object') {
    HighchartsExporting(Highcharts)
}

export const Dashboard = () => {
    const { Get } = campaignController

    const [amountAllCampaigns, setAmountAllCampaigns] = useState([])
    const [callAllCampaigns, setCallAllCampaigns] = useState([])
    const [optionCampaign, setOptionCampaign] = useState([
        {
            value: "",
            label: "All Campaign"
        }
    ])
    const [selectedCampaign, setSelectedCampaign] = useState({
        value: "",
        label: "All Campaign"
    })

    useEffect(() => {
        // const socket = io.connect('http://192.168.3.98:8002', { query: { 
        // token: cookieService.Get('socketAuth')
        // }})
        const socket = io('http://localhost:8002', { query : {
            token: cookieService.Get('socketAuth')
        }})

        if (selectedCampaign.value === '') {
            socket.emit("call_all_campaigns")
            socket.emit("amount_all_campaigns")
        } else {
            socket.emit('call_campaigns', {campaign_id:selectedCampaign.value})
            socket.emit('amount_campaigns', {campaign_id:selectedCampaign.value})
        }

        socket.on("total-call_campaigns", (data) => {
            data = JSON.parse(data)
            let mapCallAllCampaigns = data.map((row) => {
                return {
                    name: row.username,
                    data: [row.total_call]
                }
            })
            setCallAllCampaigns(mapCallAllCampaigns)
        })

        socket.on("total_amount_campaigns", (data) => {
            data = JSON.parse(data)
            let mapAmountAllCampaigns = data.map((row) => {
                return {
                    name: row.username,
                    data: [row.amount]
                }
            })
            setAmountAllCampaigns(mapAmountAllCampaigns)
        })

        socket.on("total-amount_all_campaigns", (data) => {
            data = JSON.parse(data)
            let mapAmountAllCampaigns = data.map((row) => {
                return {
                    name: row.username,
                    data: [row.amount]
                }
            })
            setAmountAllCampaigns(mapAmountAllCampaigns)
        })

        socket.on("total-call_all_campaigns", (data) => {
            data = JSON.parse(data)
            let mapCallAllCampaigns = data.map((row) => {
                return {
                    name: row.username,
                    data: [row.total_call]
                }
            })
            setCallAllCampaigns(mapCallAllCampaigns)
        })
    }, [selectedCampaign])

    useEffect(async () => {
        await Get({is_active: 1}).then((res) => {
            if (!isEmptyValue(res.data)) {
                let mapOptionCampaign = res.data.map((row) => {
                    return { value: row.id, label: row.name }
                })

                setOptionCampaign([
                    ...optionCampaign,
                    ...mapOptionCampaign
                ])
            }
        })
    }, [])
    
    const handleOnChange = (selected) => {
        setSelectedCampaign({
            value: selected.value,
            label: selected.label
        })
    }

    const optAmountAllCampaigns = {
        chart: {
            type: 'column'
        },
        title: {
            text: 'Outgoing Call'
        },
        xAxis: {
            type: 'category'
        },
        yAxis: {
            min: 0,
            title: {
                text: 'Amount'
            }
        },
        credits: false,
        series: amountAllCampaigns,
    }

    const optCallAllCampaigns = {
        chart: {
            type: 'column'
        },
        title: {
            text: 'Nilai Transaksi'
        },
        xAxis: {
            type: 'category'
        },
        yAxis: {
            min: 0,
            title: {
                text: 'Total Call'
            }
        },
        credits: false,
        series: callAllCampaigns,
    }

    return (
        <>
            <h1 className="mt-4">Dashboard</h1>
            <ol className="breadcrumb mb-4">
                <li className="breadcrumb-item active">Dashboard</li>
            </ol>
            <div className="card mb-4">
                <div className="card-header">
                    <i className="fas fa-table mr-1"></i> Filter Data
                </div>
                <div className="card-body">
                    <Form>
                        <Form.Row>
                            <Col md="3">
                                <Form.Label srOnly>
                                    Campaign
                                </Form.Label>
                                <Select
                                    options={optionCampaign}
                                    onChange={handleOnChange}
                                    value={optionCampaign.filter((opt) => {
                                        return opt.value === selectedCampaign.value;
                                    })}
                                />
                            </Col>
                        </Form.Row>
                    </Form>
                </div>
            </div>
            <Row>
                <Col md="12">
                    <div className="card mb-4">
                        <div className="card-body">
                            <HighchartsReact
                                highcharts={Highcharts}
                                options={optAmountAllCampaigns}
                            />
                        </div>
                    </div>
                </Col>
            </Row>
            <Row>
                <Col md="12">
                    <div className="card mb-4">
                        <div className="card-body">
                            <HighchartsReact
                                highcharts={Highcharts}
                                options={optCallAllCampaigns}
                            />
                        </div>
                    </div>
                </Col>
            </Row>
        </>
    )
}