import { useContext } from 'react'
import { useHistory } from 'react-router-dom'
import { AuthContext } from '../context'
import { publicApi, generalService, cookieService } from '../services'
import _ from 'lodash'

export const useVoices = () => {
    let history = useHistory()
    const { setIsAuth } = useContext(AuthContext)
    const { isEmptyValue } = generalService
    const endpoint = '/voices'
    const initialResult = {
        success: false,
        data: null
    }
    const unauthorizedStatus = [401, 403]
    const unauthorized = () => {
        localStorage.clear()
        cookieService.Remove('ext')
        cookieService.Remove('user_level_id')
        cookieService.Remove('username')
        cookieService.Remove('ytoken')
        cookieService.Remove('socketAuth')
        setIsAuth(false)

        return history.push({
            pathname: "/login",
            state: {
                alert: {
                    show: true,
                    type: 'warning',
                    message: "Your session has expired, please re-login."
                }
            }
        })
    }

    const Get = async (params) => {
        let result = initialResult
        let paramArray = []

        if (!isEmptyValue(params) && _.isObject(params)) {
            if (params.hasOwnProperty('filename')) {
                paramArray.push(`filename=${params['filename']}`)
            }

            if (params.hasOwnProperty('filedate')) {
                paramArray.push(`filedate=${params['filedate']}`)
            }
        }

        if (!isEmptyValue(paramArray)) {
            const paramString = `${paramArray.join("&")}`

            await publicApi('get', `${endpoint}?${paramString}`).then((res) => {
                result = {
                    ...result,
                    success: res.success,
                    data: res.data
                }
            }).catch((err) => {
                if (err.response) {
                    let res = err.response.data
                    if (unauthorizedStatus.indexOf(res.response_code) >= 0) {
                        return unauthorized()
                    }
                }
            })
        }

        return result
    }

    return {
        Get
    }
}