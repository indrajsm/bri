import { useContext } from 'react'
import { useHistory } from 'react-router-dom'
import { AuthContext, CallContext } from '../context'
import { publicApi, paginationService, generalService, cookieService } from '../services'
import _ from 'lodash'

export const useHangUp = () => {
    let history = useHistory()
    const { setIsAuth } = useContext(AuthContext)
    const { setOnlineStatus } = useContext(CallContext)
    const { isEmptyValue } = generalService
    const { PaginationInfo } = paginationService
    const endpoint = '/hangup'
    const initialResult = {
        success: false,
        total_data: 0,
        data: null
    }
    const unauthorizedStatus = [401, 403]
    const unauthorized = () => {
        localStorage.clear()
        cookieService.Remove('ext')
        cookieService.Remove('user_level_id')
        cookieService.Remove('username')
        cookieService.Remove('ytoken')
        cookieService.Remove('socketAuth')
        setIsAuth(false)
        setOnlineStatus('')

        return history.push({
            pathname: "/login",
            state: {
                alert: {
                    show: true,
                    type: 'warning',
                    message: "Your session has expired, please re-login."
                }
            }
        })
    }

    const HangUp = async (data) => {
        let result = initialResult

        if (!isEmptyValue(data) && _.isObject(data)) {
            await publicApi('post', `${endpoint}`, data).then((res) => {
                result = {
                    ...result,
                    success: res.success,
                    total_data: res.total_data,
                    data: res.data
                }
                localStorage.removeItem('onlineStatus');
                localStorage.removeItem('incomingCall');
                localStorage.removeItem('pickupCall');
                localStorage.removeItem('startCall');
            }).catch((err) => {
                if (err.response) {
                    let res = err.response.data
                    if (unauthorizedStatus.indexOf(res.response_code) >= 0) {
                        return unauthorized()
                    }
                }
            })
        }

        return result
    }

    return {
        HangUp,
    }
}