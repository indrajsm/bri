import { useContext } from 'react'
import { useHistory } from 'react-router-dom'
import { AuthContext } from '../context'
import { publicApi, paginationService, generalService, cookieService } from '../services'
import _ from 'lodash'

export const useUsers = () => {
    let history = useHistory()
    const { setIsAuth } = useContext(AuthContext)
    const { isEmptyValue } = generalService
    const { PaginationInfo } = paginationService
    const endpoint = '/users'
    const initialResult = {
        success: false,
        total_data: 0,
        data: null
    }
    const unauthorizedStatus = [401, 403]
    const unauthorized = () => {
        localStorage.clear()
        cookieService.Remove('ext')
        cookieService.Remove('user_level_id')
        cookieService.Remove('username')
        cookieService.Remove('ytoken')
        cookieService.Remove('socketAuth')
        setIsAuth(false)

        return history.push({
            pathname: "/login",
            state: {
                alert: {
                    show: true,
                    type: 'warning',
                    message: "Your session has expired, please re-login."
                }
            }
        })
    }

    const Get = async (params) => {
        let result = initialResult
        let resultPaging = {}
        let paramString = ''
        let paramArray = []
        let paramObject = {
            limit: 20
        }

        if (!isEmptyValue(params) && _.isObject(params)) {
            if ('id' in params && !_.isNaN(params['id'])) {
                await publicApi('get', `${endpoint}/${params['id']}`).then((res) => {
                    result = {
                        ...result,
                        success: res.success,
                        total_data: res.total_data,
                        data: res.data
                    }
                }).catch((err) => {
                    if (err.response) {
                        let res = err.response.data
                        if (unauthorizedStatus.indexOf(res.response_code) >= 0) {
                            return unauthorized()
                        }
                    }
                })

                return result
            } else {
                paramObject = { ...paramObject, ...params }
            }
        }

        Object.keys(paramObject).forEach((item) => {
            if (!isEmptyValue(paramObject[item])) {
                paramArray.push(`${item}=${paramObject[item]}`)
            }
        })

        if (!isEmptyValue(paramArray)) {
            paramString = `${paramArray.join("&")}`
        }

        await publicApi('get', `${endpoint}?${paramString}`).then((res) => {
            if ('paging' in res) {
                let pagingInfo = PaginationInfo(res.total_data, paramObject.limit || 0, res.paging.current)
                resultPaging = {
                    ...res.paging,
                    index: pagingInfo.index
                }
            }

            result = {
                ...result,
                success: res.success,
                total_data: res.total_data,
                limit: paramObject.limit,
                data: res.data,
                paging: resultPaging
            }
        }).catch((err) => {
            if (err.response) {
                let res = err.response.data
                if (unauthorizedStatus.indexOf(res.response_code) >= 0) {
                    return unauthorized()
                }
            }
        })

        return result
    }

    const Create = async (data) => {
        let result = initialResult

        if (!isEmptyValue(data) && _.isObject(data)) {
            await publicApi('post', `${endpoint}`, data).then((res) => {
                result = {
                    ...result,
                    success: res.success,
                    total_data: res.total_data,
                    data: res.data
                }
            }).catch((err) => {
                if (err.response) {
                    let res = err.response.data
                    if (unauthorizedStatus.indexOf(res.response_code) >= 0) {
                        return unauthorized()
                    }
                }
            })
        }

        return result
    }

    const Update = async (id, data) => {
        let result = initialResult

        if (!isEmptyValue(data) && _.isObject(data) && !_.isNaN(id)) {
            await publicApi('put', `${endpoint}/${id}`, data).then((res) => {
                result = {
                    ...result,
                    success: res.success,
                    total_data: res.total_data,
                    data: res.data
                }
            }).catch((err) => {
                if (err.response) {
                    let res = err.response.data
                    if (unauthorizedStatus.indexOf(res.response_code) >= 0) {
                        return unauthorized()
                    }
                }
            })
        }

        return result
    }

    const Delete = async (id) => {
        let result = initialResult

        if (!_.isNaN(id)) {
            const data = { is_active: "0" }

            await publicApi('put', `${endpoint}/${id}`, data).then((res) => {
                result = {
                    ...result,
                    success: res.success,
                    total_data: res.total_data,
                    data: res.data
                }
            }).catch((err) => {
                if (err.response) {
                    let res = err.response.data
                    if (unauthorizedStatus.indexOf(res.response_code) >= 0) {
                        return unauthorized()
                    }
                }
            })
        }

        return result
    }

    const AuthLogin = async (data) => {
        let result = initialResult

        if (!isEmptyValue(data) && _.isObject(data)) {
            await publicApi('post', `${endpoint}/login`, data).then((res) => {
                result = {
                    ...result,
                    success: res.success,
                    total_data: res.total_data,
                    data: res.data
                }

                localStorage.setItem('isAuth', true)
                localStorage.setItem('userActivityId', 2)
                localStorage.setItem('passwordExpired', res.data['password_expired'])
                localStorage.setItem('userLevelId', res.data['user_level_id'])
                setIsAuth(true)
                // setUser(cookieService.Get('username'))
            }).catch((err) => {
                if (err.response) {
                    let res = err.response.data
                    if (unauthorizedStatus.indexOf(res.response_code) >= 0) {
                        return unauthorized()
                    }
                }
            })
        }

        return result
    }

    const AuthLogout = async (ext) => {
        let data = null
        let result = initialResult

        // if (!isEmptyValue(ext) && !_.isNaN(ext)) {
        //     data = {
        //         extension: ext
        //     }
        // }

        await publicApi('post', `${endpoint}/logout`).then((res) => {
            result = {
                ...result,
                success: res.success,
                total_data: res.total_data,
                data: res.data
            }
            localStorage.clear()
            cookieService.Remove('ext')
            cookieService.Remove('user_level_id')
            cookieService.Remove('username')
            cookieService.Remove('ytoken')

            return history.push({
                pathname: "/login",
                state: {
                    alert: {
                        show: true,
                        type: 'success',
                        message: "You are now logout."
                    }
                }
            })
        }).catch((err) => {
            return unauthorized()
        })

        return result

    }

    const StartBreak = async (id, data) => {
        let result = initialResult

        if (!isEmptyValue(data) && _.isObject(data) && !_.isNaN(id)) {
            await publicApi('put', `${endpoint}/break/${id}`, data).then((res) => {
                result = {
                    ...result,
                    success: res.success,
                    total_data: res.total_data,
                    data: res.data
                }
            }).catch((err) => {
                if (err.response) {
                    let res = err.response.data
                    if (unauthorizedStatus.indexOf(res.response_code) >= 0) {
                        return unauthorized()
                    }
                }
            })
        }

        return result
    }

    const EndBreak = async (id, data) => {
        let result = initialResult

        if (!isEmptyValue(data) && _.isObject(data) && !_.isNaN(id)) {
            await publicApi('put', `${endpoint}/unbreak/${id}`, data).then((res) => {
                result = {
                    ...result,
                    success: res.success,
                    total_data: res.total_data,
                    data: res.data
                }
            }).catch((err) => {
                if (err.response) {
                    let res = err.response.data
                    if (unauthorizedStatus.indexOf(res.response_code) >= 0) {
                        return unauthorized()
                    }
                }
            })
        }

        return result
    }

    return {
        Get,
        Create,
        Update,
        Delete,
        AuthLogin,
        AuthLogout,
        StartBreak,
        EndBreak
    }
}