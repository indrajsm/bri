import { useContext } from 'react'
import { useHistory } from 'react-router-dom'
import { AuthContext } from '../context'
import { publicApi, generalService, cookieService } from '../services'
import _ from 'lodash'

export const useExports = () => {
    let history = useHistory()
    const { setIsAuth } = useContext(AuthContext)
    const { isEmptyValue } = generalService
    const endpoint = '/generate'
    const initialResult = {
        success: false,
        data: null
    }
    const unauthorizedStatus = [401, 403]
    const unauthorized = () => {
        localStorage.clear()
        cookieService.Remove('ext')
        cookieService.Remove('user_level_id')
        cookieService.Remove('username')
        cookieService.Remove('ytoken')
        cookieService.Remove('socketAuth')
        setIsAuth(false)

        return history.push({
            pathname: "/login",
            state: {
                alert: {
                    show: true,
                    type: 'warning',
                    message: "Your session has expired, please re-login."
                }
            }
        })
    }

    const ReportBreak = async (params) => {
        let result = initialResult
        let paramString = ''
        let paramArray = []
        let paramObject = {
            limit: 20
        }

        if (!isEmptyValue(params) && _.isObject(params)) {
            paramObject = {...paramObject, ...params}
        }

        Object.keys(paramObject).forEach((item) => {
            if (paramObject.hasOwnProperty('disable_date')) {
                if (paramObject['disable_date'] === true) {
                    ['start', 'end'].forEach(item=> delete paramObject[item]);
                }

                delete paramObject['disable_date']
            }

            if (paramObject.hasOwnProperty('page')) {
                delete paramObject['page']
            }

            if (!isEmptyValue(paramObject[item])) {
                paramArray.push(`${item}=${paramObject[item]}`)
            }
        })

        if (!isEmptyValue(paramArray)) {
            paramString = `${paramArray.join("&")}`
        }

        await publicApi('get', `${endpoint}/report-break?${paramString}`).then((res) => {
            result = {
                ...result,
                success: res.success,
                data: res.data
            }
        }).catch((err) => {
            if (err.response) {
                let res = err.response.data
                if (unauthorizedStatus.indexOf(res.response_code) >= 0) {
                    return unauthorized()
                }
            }
        })

        return result
    }

    const ReportBusinessAchievement = async (params) => {
        let result = initialResult
        let paramString = ''
        let paramArray = []
        let paramObject = {
            limit: 20
        }

        if (!isEmptyValue(params) && _.isObject(params)) {
            paramObject = {...paramObject, ...params}
        }

        Object.keys(paramObject).forEach((item) => {
            if (paramObject.hasOwnProperty('disable_date')) {
                if (paramObject['disable_date'] === true) {
                    ['start', 'end'].forEach(item=> delete paramObject[item]);
                }

                delete paramObject['disable_date']
            }

            if (paramObject.hasOwnProperty('page')) {
                delete paramObject['page']
            }

            if (!isEmptyValue(paramObject[item])) {
                paramArray.push(`${item}=${paramObject[item]}`)
            }
        })

        if (!isEmptyValue(paramArray)) {
            paramString = `${paramArray.join("&")}`
        }

        await publicApi('get', `${endpoint}/report-bussiness-achivement?${paramString}`).then((res) => {
            result = {
                ...result,
                success: res.success,
                data: res.data
            }
        }).catch((err) => {
            if (err.response) {
                let res = err.response.data
                if (unauthorizedStatus.indexOf(res.response_code) >= 0) {
                    return unauthorized()
                }
            }
        })

        return result
    }

    const ReportCallActivity = async (params) => {
        let result = initialResult
        let paramString = ''
        let paramArray = []
        let paramObject = {
            limit: 20
        }

        if (!isEmptyValue(params) && _.isObject(params)) {
            paramObject = {...paramObject, ...params}
        }

        Object.keys(paramObject).forEach((item) => {
            if (paramObject.hasOwnProperty('disable_date')) {
                if (paramObject['disable_date'] === true) {
                    ['start', 'end'].forEach(item=> delete paramObject[item]);
                }

                delete paramObject['disable_date']
            }

            if (paramObject.hasOwnProperty('page')) {
                delete paramObject['page']
            }

            if (!isEmptyValue(paramObject[item])) {
                paramArray.push(`${item}=${paramObject[item]}`)
            }
        })

        if (!isEmptyValue(paramArray)) {
            paramString = `${paramArray.join("&")}`
        }

        await publicApi('get', `${endpoint}/report-call-activity?${paramString}`).then((res) => {
            result = {
                ...result,
                success: res.success,
                data: res.data
            }
        }).catch((err) => {
            if (err.response) {
                let res = err.response.data
                if (unauthorizedStatus.indexOf(res.response_code) >= 0) {
                    return unauthorized()
                }
            }
        })

        return result
    }

    const ReportCallCustomer = async (params) => {
        let result = initialResult
        let paramString = ''
        let paramArray = []
        let paramObject = {
            limit: 20
        }

        if (!isEmptyValue(params) && _.isObject(params)) {
            paramObject = {...paramObject, ...params}
        }

        Object.keys(paramObject).forEach((item) => {
            if (paramObject.hasOwnProperty('disable_date')) {
                if (paramObject['disable_date'] === true) {
                    ['start', 'end'].forEach(item=> delete paramObject[item]);
                }

                delete paramObject['disable_date']
            }

            if (paramObject.hasOwnProperty('page')) {
                delete paramObject['page']
            }

            if (!isEmptyValue(paramObject[item])) {
                paramArray.push(`${item}=${paramObject[item]}`)
            }
        })

        if (!isEmptyValue(paramArray)) {
            paramString = `${paramArray.join("&")}`
        }

        await publicApi('get', `${endpoint}/report-call-customer?${paramString}`).then((res) => {
            result = {
                ...result,
                success: res.success,
                data: res.data
            }
        }).catch((err) => {
            if (err.response) {
                let res = err.response.data
                if (unauthorizedStatus.indexOf(res.response_code) >= 0) {
                    return unauthorized()
                }
            }
        })

        return result
    }

    const ReportCallDetail = async (params) => {
        let result = initialResult
        let paramString = ''
        let paramArray = []
        let paramObject = {
            limit: 20
        }

        if (!isEmptyValue(params) && _.isObject(params)) {
            paramObject = {...paramObject, ...params}
        }

        Object.keys(paramObject).forEach((item) => {
            if (paramObject.hasOwnProperty('disable_date')) {
                if (paramObject['disable_date'] === true) {
                    ['start', 'end'].forEach(item=> delete paramObject[item]);
                }

                delete paramObject['disable_date']
            }

            if (paramObject.hasOwnProperty('page')) {
                delete paramObject['page']
            }

            if (!isEmptyValue(paramObject[item])) {
                paramArray.push(`${item}=${paramObject[item]}`)
            }
        })

        if (!isEmptyValue(paramArray)) {
            paramString = `${paramArray.join("&")}`
        }

        await publicApi('get', `${endpoint}/report-call-details?${paramString}`).then((res) => {
            result = {
                ...result,
                success: res.success,
                data: res.data
            }
        }).catch((err) => {
            if (err.response) {
                let res = err.response.data
                if (unauthorizedStatus.indexOf(res.response_code) >= 0) {
                    return unauthorized()
                }
            }
        })

        return result
    }

    const ReportChecker = async (params) => {
        let result = initialResult
        let paramString = ''
        let paramArray = []
        let paramObject = {
            limit: 20
        }

        if (!isEmptyValue(params) && _.isObject(params)) {
            paramObject = {...paramObject, ...params}
        }

        Object.keys(paramObject).forEach((item) => {
            if (paramObject.hasOwnProperty('disable_date')) {
                if (paramObject['disable_date'] === true) {
                    ['start', 'end'].forEach(item=> delete paramObject[item]);
                }

                delete paramObject['disable_date']
            }

            if (paramObject.hasOwnProperty('page')) {
                delete paramObject['page']
            }

            if (!isEmptyValue(paramObject[item])) {
                paramArray.push(`${item}=${paramObject[item]}`)
            }
        })

        if (!isEmptyValue(paramArray)) {
            paramString = `${paramArray.join("&")}`
        }

        await publicApi('get', `${endpoint}/report-checker?${paramString}`).then((res) => {
            result = {
                ...result,
                success: res.success,
                data: res.data
            }
        }).catch((err) => {
            if (err.response) {
                let res = err.response.data
                if (unauthorizedStatus.indexOf(res.response_code) >= 0) {
                    return unauthorized()
                }
            }
        })

        return result
    }

    const ReportCostViewer = async (params) => {
        let result = initialResult
        let paramString = ''
        let paramArray = []
        let paramObject = {
            limit: 20
        }

        if (!isEmptyValue(params) && _.isObject(params)) {
            paramObject = {...paramObject, ...params}
        }

        Object.keys(paramObject).forEach((item) => {
            if (paramObject.hasOwnProperty('disable_date')) {
                if (paramObject['disable_date'] === true) {
                    ['start', 'end'].forEach(item=> delete paramObject[item]);
                }

                delete paramObject['disable_date']
            }

            if (paramObject.hasOwnProperty('page')) {
                delete paramObject['page']
            }

            if (!isEmptyValue(paramObject[item])) {
                paramArray.push(`${item}=${paramObject[item]}`)
            }
        })

        if (!isEmptyValue(paramArray)) {
            paramString = `${paramArray.join("&")}`
        }

        await publicApi('get', `${endpoint}/report-cost-viewer?${paramString}`).then((res) => {
            result = {
                ...result,
                success: res.success,
                data: res.data
            }
        }).catch((err) => {
            if (err.response) {
                let res = err.response.data
                if (unauthorizedStatus.indexOf(res.response_code) >= 0) {
                    return unauthorized()
                }
            }
        })

        return result
    }

    const ReportEmail = async (params) => {
        let result = initialResult
        let paramString = ''
        let paramArray = []
        let paramObject = {
            limit: 20
        }

        if (!isEmptyValue(params) && _.isObject(params)) {
            paramObject = {...paramObject, ...params}
        }

        Object.keys(paramObject).forEach((item) => {
            if (paramObject.hasOwnProperty('disable_date')) {
                if (paramObject['disable_date'] === true) {
                    ['start', 'end'].forEach(item=> delete paramObject[item]);
                }

                delete paramObject['disable_date']
            }

            if (paramObject.hasOwnProperty('page')) {
                delete paramObject['page']
            }

            if (!isEmptyValue(paramObject[item])) {
                paramArray.push(`${item}=${paramObject[item]}`)
            }
        })

        if (!isEmptyValue(paramArray)) {
            paramString = `${paramArray.join("&")}`
        }

        await publicApi('get', `${endpoint}/report-emails?${paramString}`).then((res) => {
            result = {
                ...result,
                success: res.success,
                data: res.data
            }
        }).catch((err) => {
            if (err.response) {
                let res = err.response.data
                if (unauthorizedStatus.indexOf(res.response_code) >= 0) {
                    return unauthorized()
                }
            }
        })

        return result
    }

    const ReportPerformanceAgent = async (params) => {
        let result = initialResult
        let paramString = ''
        let paramArray = []
        let paramObject = {
            limit: 20
        }

        if (!isEmptyValue(params) && _.isObject(params)) {
            paramObject = {...paramObject, ...params}
        }

        Object.keys(paramObject).forEach((item) => {
            if (paramObject.hasOwnProperty('disable_date')) {
                if (paramObject['disable_date'] === true) {
                    ['start', 'end'].forEach(item=> delete paramObject[item]);
                }

                delete paramObject['disable_date']
            }

            if (paramObject.hasOwnProperty('page')) {
                delete paramObject['page']
            }

            if (!isEmptyValue(paramObject[item])) {
                paramArray.push(`${item}=${paramObject[item]}`)
            }
        })

        if (!isEmptyValue(paramArray)) {
            paramString = `${paramArray.join("&")}`
        }

        await publicApi('get', `${endpoint}/report-performance?${paramString}`).then((res) => {
            result = {
                ...result,
                success: res.success,
                data: res.data
            }
        }).catch((err) => {
            if (err.response) {
                let res = err.response.data
                if (unauthorizedStatus.indexOf(res.response_code) >= 0) {
                    return unauthorized()
                }
            }
        })

        return result
    }

    const ReportQualityAssuranceDetail = async (params) => {
        let result = initialResult
        let paramArray = []

        if (!isEmptyValue(params) && _.isObject(params)) {
            if (params.hasOwnProperty('quality_assurance_user_id') && !_.isNaN(params['quality_assurance_user_id'])) {
                paramArray.push(`quality_assurance_user_id=${params['quality_assurance_user_id']}`)
            }
        }

        if (!isEmptyValue(paramArray)) {
            const paramString = `${paramArray.join("&")}`

            await publicApi('get', `${endpoint}/export-qa-details?${paramString}`).then((res) => {
                result = {
                    ...result,
                    success: res.success,
                    data: res.data
                }
            }).catch((err) => {
                if (err.response) {
                    let res = err.response.data
                    if (unauthorizedStatus.indexOf(res.response_code) >= 0) {
                        return unauthorized()
                    }
                }
            })
        }

        return result
    }

    const ReportQualityAssuranceSummary = async (params) => {
        let result = initialResult
        let paramString = ''
        let paramArray = []
        let paramObject = {
            limit: 20
        }

        if (!isEmptyValue(params) && _.isObject(params)) {
            paramObject = {...paramObject, ...params}
        }

        Object.keys(paramObject).forEach((item) => {
            if (paramObject.hasOwnProperty('disable_date')) {
                if (paramObject['disable_date'] === true) {
                    ['start', 'end'].forEach(item=> delete paramObject[item]);
                }

                delete paramObject['disable_date']
            }

            if (paramObject.hasOwnProperty('page')) {
                delete paramObject['page']
            }

            if (!isEmptyValue(paramObject[item])) {
                paramArray.push(`${item}=${paramObject[item]}`)
            }
        })

        if (!isEmptyValue(paramArray)) {
            paramString = `${paramArray.join("&")}`
        }

        await publicApi('get', `${endpoint}/report-qa-summaries?${paramString}`).then((res) => {
            result = {
                ...result,
                success: res.success,
                data: res.data
            }
        }).catch((err) => {
            if (err.response) {
                let res = err.response.data
                if (unauthorizedStatus.indexOf(res.response_code) >= 0) {
                    return unauthorized()
                }
            }
        })

        return result
    }

    return {
        ReportBreak,
        ReportBusinessAchievement,
        ReportCallActivity,
        ReportCallCustomer,
        ReportCallDetail,
        ReportChecker,
        ReportCostViewer,
        ReportEmail,
        ReportPerformanceAgent,
        ReportQualityAssuranceDetail,
        ReportQualityAssuranceSummary
    }
}