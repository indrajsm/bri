import { useContext } from 'react'
import { useHistory } from 'react-router-dom'
import { AuthContext } from '../context'
import { publicApi, paginationService, generalService, cookieService } from '../services'
import _ from 'lodash'

export const useCalls = () => {
    let history = useHistory()
    const { setIsAuth } = useContext(AuthContext)
    const { isEmptyValue } = generalService
    const { PaginationInfo } = paginationService
    const endpoint = '/calls'
    const initialResult = {
        success: false,
        total_data: 0,
        data: null
    }
    const unauthorizedStatus = [401, 403]
    const unauthorized = () => {
        localStorage.clear()
        cookieService.Remove('ext')
        cookieService.Remove('user_level_id')
        cookieService.Remove('username')
        cookieService.Remove('ytoken')
        cookieService.Remove('socketAuth')
        setIsAuth(false)

        return history.push({
            pathname: "/login",
            state: {
                alert: {
                    show: true,
                    type: 'warning',
                    message: "Your session has expired, please re-login."
                }
            }
        })
    }

    const Get = async (params) => {
        let result = initialResult
        let resultPaging = {}
        let paramString = ''
        let paramArray = []
        let paramObject = {
            limit: 20
        }

        if (!isEmptyValue(params) && _.isObject(params)) {
            if ('id' in params && !_.isNaN(params['id'])) {
                await publicApi('get', `${endpoint}/${params['id']}`).then((res) => {
                    result = {
                        ...result,
                        success: res.success,
                        total_data: res.total_data,
                        data: res.data
                    }
                }).catch((err) => {
                    if (err.response) {
                        let res = err.response.data
                        if (unauthorizedStatus.indexOf(res.response_code) >= 0) {
                            return unauthorized()
                        }
                    }
                })

                return result
            } else {
                paramObject = { ...paramObject, ...params }
            }
        }

        Object.keys(paramObject).forEach((item) => {
            if (paramObject.disable_date) {
                ['disable_date', 'end', 'start'].forEach(e => delete paramObject[e]);
            }
            if (!isEmptyValue(paramObject[item])) {
                paramArray.push(`${item}=${paramObject[item]}`)
            }
        })

        if (!isEmptyValue(paramArray)) {
            paramString = `${paramArray.join("&")}`
        }

        await publicApi('get', `${endpoint}?${paramString}`).then((res) => {
            if ('paging' in res) {
                let pagingInfo = PaginationInfo(res.total_data, paramObject.limit || 0, res.paging.current)
                resultPaging = {
                    ...res.paging,
                    index: pagingInfo.index
                }
            }

            result = {
                ...result,
                success: res.success,
                total_data: res.total_data,
                limit: paramObject.limit,
                data: res.data,
                paging: resultPaging
            }
        }).catch((err) => {
            if (err.response) {
                let res = err.response.data
                if (unauthorizedStatus.indexOf(res.response_code) >= 0) {
                    return unauthorized()
                }
            }
        })

        return result
    }

    const GetQA = async (params) => {
        let result = initialResult
        let resultPaging = {}
        let paramString = ''
        let paramArray = []
        let paramObject = {
            limit: 20,
            order: 'created_at',
            sort: 'desc'
        }

        if (!isEmptyValue(params) && _.isObject(params)) {
            paramObject = { ...paramObject, ...params }
        }

        Object.keys(paramObject).forEach((item) => {
            if ('disable_date' in paramObject) {
                if (paramObject['disable_date'] === true) {
                    ['start', 'end'].forEach(item => delete paramObject[item]);
                }

                delete paramObject['disable_date']
            }

            if (!isEmptyValue(paramObject[item])) {
                paramArray.push(`${item}=${paramObject[item]}`)
            }
        })

        if (!isEmptyValue(paramArray)) {
            paramString = `${paramArray.join("&")}`
        }

        await publicApi('get', `${endpoint}/qa_list?${paramString}`).then((res) => {
            if ('paging' in res) {
                let pagingInfo = PaginationInfo(res.total_data, paramObject.limit || 0, res.paging.current)
                resultPaging = {
                    ...res.paging,
                    index: pagingInfo.index
                }
            }

            result = {
                ...result,
                success: res.success,
                total_data: res.total_data,
                limit: paramObject.limit,
                data: res.data,
                paging: resultPaging
            }
        }).catch((err) => {
            if (err.response) {
                let res = err.response.data
                if (unauthorizedStatus.indexOf(res.response_code) >= 0) {
                    return unauthorized()
                }
            }
        })

        return result
    }

    const GetReportBusinessAchievement = async (params) => {
        let result = initialResult
        let resultPaging = {}
        let paramString = ''
        let paramArray = []
        let paramObject = {
            limit: 20
        }

        if (!isEmptyValue(params) && _.isObject(params)) {
            paramObject = { ...paramObject, ...params }
        }

        Object.keys(paramObject).forEach((item) => {
            if ('disable_date' in paramObject) {
                if (paramObject['disable_date'] === true) {
                    ['start', 'end'].forEach(item => delete paramObject[item]);
                }

                delete paramObject['disable_date']
            }

            if (!isEmptyValue(paramObject[item])) {
                paramArray.push(`${item}=${paramObject[item]}`)
            }
        })

        if (!isEmptyValue(paramArray)) {
            paramString = `${paramArray.join("&")}`
        }

        await publicApi('get', `${endpoint}/report-bussiness-achivement?${paramString}`).then((res) => {
            if ('paging' in res) {
                let pagingInfo = PaginationInfo(res.total_data, paramObject.limit || 0, res.paging.current)
                resultPaging = {
                    ...res.paging,
                    index: pagingInfo.index
                }
            }

            result = {
                ...result,
                success: res.success,
                total_data: res.total_data,
                limit: paramObject.limit,
                data: res.data,
                paging: resultPaging
            }
        }).catch((err) => {
            if (err.response) {
                let res = err.response.data
                if (unauthorizedStatus.indexOf(res.response_code) >= 0) {
                    return unauthorized()
                }
            }
        })

        return result
    }

    const GetReportCallActivity = async (params) => {
        let result = initialResult
        let resultPaging = {}
        let paramString = ''
        let paramArray = []
        let paramObject = {
            limit: 20
        }

        if (!isEmptyValue(params) && _.isObject(params)) {
            paramObject = { ...paramObject, ...params }
        }

        Object.keys(paramObject).forEach((item) => {
            if ('disable_date' in paramObject) {
                if (paramObject['disable_date'] === true) {
                    ['start', 'end'].forEach(item => delete paramObject[item]);
                }

                delete paramObject['disable_date']
            }

            if (!isEmptyValue(paramObject[item])) {
                paramArray.push(`${item}=${paramObject[item]}`)
            }
        })

        if (!isEmptyValue(paramArray)) {
            paramString = `${paramArray.join("&")}`
        }

        await publicApi('get', `${endpoint}/report-call-activity?${paramString}`).then((res) => {
            if ('paging' in res) {
                let pagingInfo = PaginationInfo(res.total_data, paramObject.limit || 0, res.paging.current)
                resultPaging = {
                    ...res.paging,
                    index: pagingInfo.index
                }
            }

            result = {
                ...result,
                success: res.success,
                total_data: res.total_data,
                limit: paramObject.limit,
                data: res.data,
                paging: resultPaging
            }
        }).catch((err) => {
            if (err.response) {
                let res = err.response.data
                if (unauthorizedStatus.indexOf(res.response_code) >= 0) {
                    return unauthorized()
                }
            }
        })

        return result
    }

    const GetReportCallCustomer = async (params) => {
        let result = initialResult
        let resultPaging = {}
        let paramString = ''
        let paramArray = []
        let paramObject = {
            limit: 20
        }

        if (!isEmptyValue(params) && _.isObject(params)) {
            paramObject = { ...paramObject, ...params }
        }

        Object.keys(paramObject).forEach((item) => {
            if ('disable_date' in paramObject) {
                if (paramObject['disable_date'] === true) {
                    ['start', 'end'].forEach(item => delete paramObject[item]);
                }

                delete paramObject['disable_date']
            }

            if (!isEmptyValue(paramObject[item])) {
                paramArray.push(`${item}=${paramObject[item]}`)
            }
        })

        if (!isEmptyValue(paramArray)) {
            paramString = `${paramArray.join("&")}`
        }

        await publicApi('get', `${endpoint}/report-call-customer?${paramString}`).then((res) => {
            if ('paging' in res) {
                let pagingInfo = PaginationInfo(res.total_data, paramObject.limit || 0, res.paging.current)
                resultPaging = {
                    ...res.paging,
                    index: pagingInfo.index
                }
            }

            result = {
                ...result,
                success: res.success,
                total_data: res.total_data,
                limit: paramObject.limit,
                data: res.data,
                paging: resultPaging
            }
        }).catch((err) => {
            if (err.response) {
                let res = err.response.data
                if (unauthorizedStatus.indexOf(res.response_code) >= 0) {
                    return unauthorized()
                }
            }
        })

        return result
    }

    const GetReportCallDetail = async (params) => {
        let result = initialResult
        let resultPaging = {}
        let paramString = ''
        let paramArray = []
        let paramObject = {
            limit: 20
        }

        if (!isEmptyValue(params) && _.isObject(params)) {
            paramObject = { ...paramObject, ...params }
        }

        Object.keys(paramObject).forEach((item) => {
            if ('disable_date' in paramObject) {
                if (paramObject['disable_date'] === true) {
                    ['start', 'end'].forEach(item => delete paramObject[item]);
                }

                delete paramObject['disable_date']
            }

            if (!isEmptyValue(paramObject[item])) {
                paramArray.push(`${item}=${paramObject[item]}`)
            }
        })

        if (!isEmptyValue(paramArray)) {
            paramString = `${paramArray.join("&")}`
        }

        await publicApi('get', `${endpoint}/report-call-details?${paramString}`).then((res) => {
            if ('paging' in res) {
                let pagingInfo = PaginationInfo(res.total_data, paramObject.limit || 0, res.paging.current)
                resultPaging = {
                    ...res.paging,
                    index: pagingInfo.index
                }
            }

            result = {
                ...result,
                success: res.success,
                total_data: res.total_data,
                limit: paramObject.limit,
                data: res.data,
                paging: resultPaging
            }
        }).catch((err) => {
            if (err.response) {
                let res = err.response.data
                if (unauthorizedStatus.indexOf(res.response_code) >= 0) {
                    return unauthorized()
                }
            }
        })

        return result
    }

    const GetReportChecker = async (params) => {
        let result = initialResult
        let resultPaging = {}
        let paramString = ''
        let paramArray = []
        let paramObject = {
            limit: 20
        }

        if (!isEmptyValue(params) && _.isObject(params)) {
            paramObject = { ...paramObject, ...params }
        }

        Object.keys(paramObject).forEach((item) => {
            if ('disable_date' in paramObject) {
                if (paramObject['disable_date'] === true) {
                    ['start', 'end'].forEach(item => delete paramObject[item]);
                }

                delete paramObject['disable_date']
            }

            if (!isEmptyValue(paramObject[item])) {
                paramArray.push(`${item}=${paramObject[item]}`)
            }
        })

        if (!isEmptyValue(paramArray)) {
            paramString = `${paramArray.join("&")}`
        }

        await publicApi('get', `${endpoint}/report-checker?${paramString}`).then((res) => {
            if ('paging' in res) {
                let pagingInfo = PaginationInfo(res.total_data, paramObject.limit || 0, res.paging.current)
                resultPaging = {
                    ...res.paging,
                    index: pagingInfo.index
                }
            }

            result = {
                ...result,
                success: res.success,
                total_data: res.total_data,
                limit: paramObject.limit,
                data: res.data,
                paging: resultPaging
            }
        }).catch((err) => {
            if (err.response) {
                let res = err.response.data
                if (unauthorizedStatus.indexOf(res.response_code) >= 0) {
                    return unauthorized()
                }
            }
        })

        return result
    }

    const GetReportCostViewer = async (params) => {
        let result = initialResult
        let resultPaging = {}
        let paramString = ''
        let paramArray = []
        let paramObject = {
            limit: 20
        }

        if (!isEmptyValue(params) && _.isObject(params)) {
            paramObject = { ...paramObject, ...params }
        }

        Object.keys(paramObject).forEach((item) => {
            if ('disable_date' in paramObject) {
                if (paramObject['disable_date'] === true) {
                    ['start', 'end'].forEach(item => delete paramObject[item]);
                }

                delete paramObject['disable_date']
            }

            if (!isEmptyValue(paramObject[item])) {
                paramArray.push(`${item}=${paramObject[item]}`)
            }
        })

        if (!isEmptyValue(paramArray)) {
            paramString = `${paramArray.join("&")}`
        }

        await publicApi('get', `${endpoint}/report-cost-viewer?${paramString}`).then((res) => {
            if ('paging' in res) {
                let pagingInfo = PaginationInfo(res.total_data, paramObject.limit || 0, res.paging.current)
                resultPaging = {
                    ...res.paging,
                    index: pagingInfo.index
                }
            }

            result = {
                ...result,
                success: res.success,
                total_data: res.total_data,
                limit: paramObject.limit,
                data: res.data,
                paging: resultPaging
            }
        }).catch((err) => {
            if (err.response) {
                let res = err.response.data
                if (unauthorizedStatus.indexOf(res.response_code) >= 0) {
                    return unauthorized()
                }
            }
        })

        return result
    }

    const GetReportPerformanceAgent = async (params) => {
        let result = initialResult
        let resultPaging = {}
        let paramString = ''
        let paramArray = []
        let paramObject = {
            limit: 20
        }

        if (!isEmptyValue(params) && _.isObject(params)) {
            paramObject = { ...paramObject, ...params }
        }

        Object.keys(paramObject).forEach((item) => {
            if ('disable_date' in paramObject) {
                if (paramObject['disable_date'] === true) {
                    ['start', 'end'].forEach(item => delete paramObject[item]);
                }

                delete paramObject['disable_date']
            }

            if (!isEmptyValue(paramObject[item])) {
                paramArray.push(`${item}=${paramObject[item]}`)
            }
        })

        if (!isEmptyValue(paramArray)) {
            paramString = `${paramArray.join("&")}`
        }

        await publicApi('get', `${endpoint}/report-performance?${paramString}`).then((res) => {
            if ('paging' in res) {
                let pagingInfo = PaginationInfo(res.total_data, paramObject.limit || 0, res.paging.current)
                resultPaging = {
                    ...res.paging,
                    index: pagingInfo.index
                }
            }

            result = {
                ...result,
                success: res.success,
                total_data: res.total_data,
                limit: paramObject.limit,
                data: res.data,
                paging: resultPaging
            }
        }).catch((err) => {
            if (err.response) {
                let res = err.response.data
                if (unauthorizedStatus.indexOf(res.response_code) >= 0) {
                    return unauthorized()
                }
            }
        })

        return result
    }

    const Create = async (data) => {
        let result = initialResult

        if (!isEmptyValue(data) && _.isObject(data)) {
            await publicApi('post', `${endpoint}`, data).then((res) => {
                result = {
                    ...result,
                    success: res.success,
                    total_data: res.total_data,
                    data: res.data
                }
            }).catch((err) => {
                if (err.response) {
                    let res = err.response.data
                    if (unauthorizedStatus.indexOf(res.response_code) >= 0) {
                        return unauthorized()
                    }
                }
            })
        }

        return result
    }

    const Update = async (id, data) => {
        let result = initialResult

        if (!isEmptyValue(data) && _.isObject(data) && !_.isNaN(id)) {
            await publicApi('put', `${endpoint}/${id}`, data).then((res) => {
                result = {
                    ...result,
                    success: res.success,
                    total_data: res.total_data,
                    data: res.data
                }
            }).catch((err) => {
                if (err.response) {
                    let res = err.response.data
                    if (unauthorizedStatus.indexOf(res.response_code) >= 0) {
                        return unauthorized()
                    }
                }
            })
        }

        return result
    }

    const Delete = async (id) => {
        let result = initialResult

        if (!_.isNaN(id)) {
            const data = { is_active: "0" }

            await publicApi('put', `${endpoint}/${id}`, data).then((res) => {
                result = {
                    ...result,
                    success: res.success,
                    total_data: res.total_data,
                    data: res.data
                }
            }).catch((err) => {
                if (err.response) {
                    let res = err.response.data
                    if (unauthorizedStatus.indexOf(res.response_code) >= 0) {
                        return unauthorized()
                    }
                }
            })
        }

        return result
    }

    const Listen = async (destination) => {
        let result = initialResult

        if (!isEmptyValue(destination) && !_.isNaN(destination)) {
            await publicApi('post', `listen`, { destination: destination }).then((res) => {
                result = {
                    ...result,
                    success: res.success,
                    total_data: res.total_data,
                    data: res.data
                }
            }).catch((err) => {
                if (err.response) {
                    let res = err.response.data
                    if (unauthorizedStatus.indexOf(res.response_code) >= 0) {
                        return unauthorized()
                    }
                }
            })
        }

        return result
    }

    const Unlisten = async (channel) => {
        let result = initialResult

        if (!isEmptyValue(channel)) {
            await publicApi('post', `listen/unlisten`, { channel: channel }).then((res) => {
                result = {
                    ...result,
                    success: res.success,
                    total_data: res.total_data,
                    data: res.data
                }
            }).catch((err) => {
                if (err.response) {
                    let res = err.response.data
                    if (unauthorizedStatus.indexOf(res.response_code) >= 0) {
                        return unauthorized()
                    }
                }
            })
        }

        return result
    }

    const Whisper = async (destination) => {
        let result = initialResult

        if (!isEmptyValue(destination) && !_.isNaN(destination)) {
            await publicApi('post', `whisper`, { destination: destination }).then((res) => {
                result = {
                    ...result,
                    success: res.success,
                    total_data: res.total_data,
                    data: res.data
                }
            }).catch((err) => {
                if (err.response) {
                    let res = err.response.data
                    if (unauthorizedStatus.indexOf(res.response_code) >= 0) {
                        return unauthorized()
                    }
                }
            })
        }

        return result
    }

    const Unwhisper = async (channel) => {
        let result = initialResult

        if (!isEmptyValue(channel)) {
            await publicApi('post', `whisper/unwhisper`, { channel: channel }).then((res) => {
                result = {
                    ...result,
                    success: res.success,
                    total_data: res.total_data,
                    data: res.data
                }
            }).catch((err) => {
                if (err.response) {
                    let res = err.response.data
                    if (unauthorizedStatus.indexOf(res.response_code) >= 0) {
                        return unauthorized()
                    }
                }
            })
        }

        return result
    }

    return {
        Get,
        GetQA,
        GetReportBusinessAchievement,
        GetReportCallActivity,
        GetReportCallCustomer,
        GetReportCallDetail,
        GetReportChecker,
        GetReportCostViewer,
        GetReportPerformanceAgent,
        Create,
        Update,
        Delete,
        Listen,
        Unlisten,
        Whisper,
        Unwhisper
    }
}