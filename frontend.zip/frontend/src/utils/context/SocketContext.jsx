
import { useEffect, useContext, createContext } from 'react'
import { AuthContext } from '.'
import { cookieService } from '../services'
import io from 'socket.io-client'

export const SocketContext = createContext()

export const SocketProvider = ({ children }) => {
    const { isAuth } = useContext(AuthContext)
    // const isAuth = localStorage.getItem('isAuth')
    const socketUrl = process.env.REACT_APP_MY_WEBSOCKET
    const socket = io(socketUrl)

    useEffect(() => {
        socket.on("disconnect", () => {
            console.log("socket disconnected")
            // if (isAuth) socketReconnect()
        })

        socket.on("connect", () => {
            console.log("socket connected")
        })

        if (isAuth) socketReconnect()

        return () => socket.io.close()
    }, [socket, isAuth])

    const socketReconnect = () => {
        socket.io.close()

        setTimeout(() => {
            socket.io.opts.query = {
                token: cookieService.Get("socketAuth"),
                user_id: cookieService.Get("user_id"),
                extension: cookieService.Get("ext"),
            }
            // socket.io.opts.query = `token=${cookieService.Get("socketAuth")}`
            socket.io.open((err) => {
                if (err) {
                    socketReconnect()
                }
            })
        }, 2000)
    }

    return (<SocketContext.Provider value={socket}>
        {children}
    </SocketContext.Provider>)
}