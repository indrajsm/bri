import { useState, useEffect, createContext } from 'react'
import { cookieService } from '../services'

export const AuthContext = createContext()

export const AuthProvider = (props) => {
    const [isAuth, setIsAuth] = useState(false)
    const [user, setUser] = useState(null)
    const [ext, setExt] = useState(null)
    const [userId, setUserId] = useState(null)
    const [userLevelId, setUserLevelId] = useState(null)
    const [userActivityId, setUserActivityId] = useState(null)
    // const [userActivity, setUserActivity] = useState(null)
    const [passwordExpired, setPasswordExpired] = useState(false)

    useEffect(() => {
        const getAuth = () => {
            let auth = localStorage.getItem('isAuth')
            auth = JSON.parse(auth)
            if (auth) setIsAuth(auth)
        }

        if (!isAuth) getAuth()
        return () => setIsAuth(false)
    }, [setIsAuth])

    useEffect(() => {
        const getUserData = () => {
            let username = cookieService.Get('username')
            let ext = cookieService.Get('ext')
            let user_id = cookieService.Get('user_id')
            // let user_level_id = cookieService.Get('user_level_id')
            let user_level_id = localStorage.getItem('userLevelId')
            // let user_activity_id = localStorage.getItem('userActivityId')
            let password_expired = localStorage.getItem('passwordExpired')
            setUser(username)
            setExt(ext)
            setUserId(user_id)
            setUserLevelId(user_level_id)
            // setUserActivityId(user_activity_id)
            // user_activity_id == 2 ? setUserActivity('Unavailable') : setUserActivity('Available')
            setPasswordExpired(JSON.parse(password_expired))
            // if (user_activity_id == 2) {
            //     setUserActivity(process.env.REACT_APP_USER_NOT_AVAILABLE)
            // } else if (user_activity_id == 8) {
            //     setUserActivity(process.env.REACT_APP_USER_AVAILABLE)
            // } else if (user_activity_id == 9) {
            //     setUserActivity(process.env.REACT_APP_USER_ONLINE)
            // } else {
            //     setUserActivity(process.env.REACT_APP_MY_USER_BREAK)
            // }
        }

        if (isAuth) getUserData()
        return () => {
            setUser(null)
            setExt(null)
            setUserId(null)
            setUserLevelId(null)
            // setUserActivityId(null)
            // setUserActivity(null)
        }
    }, [isAuth])

    // useEffect(() => {
    //     let user_activity_id = localStorage.getItem('userActivityId')

    //     if (user_activity_id == 2) {
    //         setUserActivity(process.env.REACT_APP_USER_NOT_AVAILABLE)
    //     } else if (user_activity_id == 8) {
    //         setUserActivity(process.env.REACT_APP_USER_AVAILABLE)
    //     } else if (user_activity_id == 9) {
    //         setUserActivity(process.env.REACT_APP_USER_ONLINE)
    //     } else {
    //         setUserActivity(process.env.REACT_APP_MY_USER_BREAK)
    //     }
    //     // return () => {
    //     //     cleanup
    //     // }
    // }, [userActivityId])

    return (
        <AuthContext.Provider value={{
            isAuth, setIsAuth,
            user, setUser,
            ext, setExt,
            userId, setUserId,
            userLevelId, setUserLevelId,
            passwordExpired, setPasswordExpired
        }}>
            {props.children}
        </AuthContext.Provider >
    )
}
