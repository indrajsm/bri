import { useState, useEffect, createContext } from 'react'
import { generalService } from '../services'

export const CallContext = createContext()
const { isEmptyValue } = generalService

export const CallProvider = (props) => {
    const [onlineStatus, setOnlineStatus] = useState('')
    const [incomingCall, setIncomingCall] = useState(initialIncomingCall)
    const [pickUpCall, setPickUpCall] = useState(initialPickupCall)

    useEffect(() => {
        const getOnlineStatus = () => {
            let online_status = localStorage.getItem('onlineStatus')
            if (online_status) setOnlineStatus(online_status)
        }
        if (isEmptyValue(onlineStatus)) getOnlineStatus()
        return () => setOnlineStatus('')
    }, [setOnlineStatus])

    useEffect(() => {
        const getCall = () => {
            let incoming_call = JSON.parse(localStorage.getItem('incomingCall'))
            let pickup_call = JSON.parse(localStorage.getItem('pickupCall'))

            setIncomingCall({ ...initialIncomingCall, ...incoming_call })
            setPickUpCall({ ...initialPickupCall, ...pickup_call })
        }

        if (!isEmptyValue(onlineStatus)) getCall()
        return () => {
            setIncomingCall(initialIncomingCall)
            setPickUpCall(initialPickupCall)
        }
    }, [onlineStatus])

    return (
        <CallContext.Provider value={{ onlineStatus, setOnlineStatus, incomingCall, setIncomingCall, pickUpCall, setPickUpCall }}>
            {props.children}
        </CallContext.Provider >
    )
}

const initialIncomingCall = {
    call_id: '',
    channel: '',
    customer_id: '',
    phone_no: '',
    campaign_id: '',
}

const initialPickupCall = {
    call_id: '',
    caller_id: '',
    channel: '',
    context: '',
    destchannel: '',
    event: '',
    event_time: '',
    extension: '',
    queue: '',
    socket_id: '',
    unique_id: '',
}
