import React, { useState } from 'react';

const ModalFormContext = React.createContext();

const ModalFormProvider = (props) => {
    const [state, setState] = useState(false);
    return (
        <ModalFormContext.Provider value={[state, setState]}>
            {props.children}
        </ModalFormContext.Provider>
    );
}

export { ModalFormContext, ModalFormProvider };