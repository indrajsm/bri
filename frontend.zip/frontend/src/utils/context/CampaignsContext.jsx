import React, { useState, createContext } from 'react'
import _ from 'lodash'
import { publicApi, paginationService, generalService } from '../services'

export const CampaignsContext = createContext()

export const CampaignsProvider = ({ children }) => {
    const { IsEmpty } = generalService
    const [data, setData] = useState({})
    const [dataPaging, setDataPaging] = useState({})
    const [dataIndex, setDataIndex] = useState([])
    const [dataDetail, setDataDetail] = useState({})
    const [field, setField] = useState({})
    const [user, setUser] = useState({})
    const [isLoadingData, setIsLoadingData] = useState(true)

    const getData = async (params) => {
        let paramString = ''
        let paramArray = []
        let paramObject = {
            limit: 20,
            order: 'name'
        }

        if (!_.isEmpty(params)) {
            paramObject = { ...paramObject, ...params }
        }

        Object.keys(paramObject).map((item, index) => {
            if (!IsEmpty(paramObject[item])) {
                paramArray.push(`${item}=${paramObject[item]}`)
            }
        })

        if (!IsEmpty(paramArray)) {
            paramString = `${paramArray.join("&")}`
        }

        const { PaginationInfo } = paginationService

        await publicApi('get', `/campaigns?${paramString}`).then((res) => {
            let paging = {}

            if ('paging' in res) {
                let pagingInfo = PaginationInfo(res.total_data, paramObject.limit || 0, res.paging.current)
                paging = { ...res.paging, ...pagingInfo }
            }

            setData({
                total_data: res.total_data || null,
                limit: paramObject.limit || 0,
                data: res.data || null,
                paging: paging
            })
            setIsLoadingData(false)
        }).catch((err) => {
            setIsLoadingData(false)
        })
    }

    const getDataDetail = async (id) => {
        if (!_.isNaN(id)) {
            await publicApi('get', `/campaigns/${id}`).then((res) => {
                setDataDetail(res.data)
                setIsLoadingData(false)
            }).catch((err) => {
                setIsLoadingData(false)
            })
        }
    }

    const updateData = async (id, data) => {
        if (!_.isNaN(id) && _.isObject(data)) {
            const res = await publicApi('put', `/campaigns/${id}`, data)
            return res
        }
    }

    const saveData = async (data) => {
        if (_.isObject(data)) {
            data = { ...data, media_id: 1 }
            const res = await publicApi('post', `/campaigns/`, data)
            return res
        }
    }

    const saveField = async (data) => {
        if (_.isObject(data)) {
            const res = await publicApi('post', `/campaign_fields/`, data)
            setIsLoadingData(false)
            return res
        }
    }

    const saveUser = async (data) => {
        if (_.isObject(data)) {
            const res = await publicApi('post', `/campaign_users/`, data)
            setIsLoadingData(false)
            return res
        }
    }

    const getCustomerFields = async () => {
        await publicApi('get', `/customer_fields`).then((res) => {
            setField(res.data)
            setIsLoadingData(false)
        }).catch((err) => {
            setIsLoadingData(false)
        })
    }

    const getUsers = async () => {
        await publicApi('get', `/users?user_level_id=1`).then((res) => {
            setUser(res.data)
            setIsLoadingData(false)
        }).catch((err) => {
            setIsLoadingData(false)
        })
    }


    return (<CampaignsContext.Provider value={{
        data,
        dataPaging,
        dataIndex,
        field,
        user,
        setField,
        getData,
        dataDetail,
        getDataDetail,
        getCustomerFields,
        getUsers,
        isLoadingData,
        setIsLoadingData,
        saveData,
        updateData,
        saveField,
        saveUser
    }}>
        {children}
    </CampaignsContext.Provider>)
}