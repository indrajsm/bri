import { useState, useEffect, createContext, useContext } from 'react'
import { cookieService } from '../services'
import { AuthContext } from '.';

export const UserActivityContext = createContext()

export const UserActivityProvider = (props) => {
    const { isAuth } = useContext(AuthContext)
    const [userActivity, setUserActivity] = useState(null)
    const [userActivityId, setUserActivityId] = useState(null)

    useEffect(() => {
        let user_activity_id = localStorage.getItem('userActivityId')

        if (user_activity_id == 2) {
            setUserActivity(process.env.REACT_APP_USER_NOT_AVAILABLE)
        } else if (user_activity_id == 8) {
            setUserActivity(process.env.REACT_APP_USER_AVAILABLE)
        } else if (user_activity_id == 9) {
            setUserActivity(process.env.REACT_APP_USER_ONLINE)
        } else {
            setUserActivity(process.env.REACT_APP_MY_USER_BREAK)
        }
        // return () => {
        //     cleanup
        // }
    }, [userActivityId, isAuth])

    return (
        <UserActivityContext.Provider value={{
            userActivityId, setUserActivityId,
            userActivity, setUserActivity,
        }}>
            {props.children}
        </UserActivityContext.Provider >
    )
}
