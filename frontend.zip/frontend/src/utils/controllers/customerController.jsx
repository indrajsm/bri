import React from 'react'
import _ from 'lodash'
import { publicApi, paginationService, generalService } from '../services'

const { isEmptyValue } = generalService

const { PaginationInfo } = paginationService

const initialResult = {
    success: false,
    total_data: 0,
    // limit: 1,
    data: null,
    // paging: null
}

const Get = async (params) => {
    let result = initialResult
    let resultPaging = {}
    let paramString = ''
    let paramArray = []
    let paramObject = {
        limit: 20,
        order: 'name',
        is_active: 1
    }

    if (!isEmptyValue(params) && _.isObject(params)) {
        if ('id' in params && !_.isNaN(params.id)) {
            await publicApi('get', `/customers/${params.id}`).then((res) => {
                result = {
                    ...result,
                    success: res.success,
                    total_data: res.total_data,
                    data: res.data
                }
            }).catch((err) => {
                // console.log(err.response.data)
            })
        } else {
            paramObject = { ...paramObject, ...params }

            Object.keys(paramObject).map((item, i) => {
                if (!isEmptyValue(paramObject[item])) {
                    paramArray.push(`${item}=${paramObject[item]}`)
                }
            })

            if (!isEmptyValue(paramArray)) {
                paramString = `${paramArray.join("&")}`
            }

            await publicApi('get', `/customers?${paramString}`).then((res) => {
                if ('paging' in res) {
                    let pagingInfo = PaginationInfo(res.total_data, paramObject.limit || 0, res.paging.current)
                    resultPaging = {
                        ...res.paging,
                        index: pagingInfo.index
                    }
                }

                result = {
                    ...result,
                    total_data: res.total_data,
                    limit: paramObject.limit,
                    data: res.data,
                    paging: resultPaging
                }
            }).catch((err) => {
                // console.log(err.response.data)
            })
        }

        return result
    }

    Object.keys(paramObject).map((item, i) => {
        if (!isEmptyValue(paramObject[item])) {
            paramArray.push(`${item}=${paramObject[item]}`)
        }
    })

    if (!isEmptyValue(paramArray)) {
        paramString = `${paramArray.join("&")}`
    }

    await publicApi('get', `/customers?${paramString}`).then((res) => {
        if ('paging' in res) {
            let pagingInfo = PaginationInfo(res.total_data, paramObject.limit || 0, res.paging.current)
            resultPaging = {
                ...res.paging,
                index: pagingInfo.index
            }
        }

        result = {
            ...result,
            total_data: res.total_data,
            limit: paramObject.limit,
            data: res.data,
            paging: resultPaging
        }
    }).catch((err) => {
        // console.log(err.response.data)
    })

    return result
}

const Add = async (data) => {
    let result = initialResult

    if (!isEmptyValue(data) && _.isObject(data)) {
        await publicApi('post', '/customers', data).then((res) => {
            result = {
                ...result,
                success: res.success,
                total_data: res.total_data,
                data: res.data
            }
        }).catch((err) => {
            // console.log(err.response.data)
        })
    }

    return result
}

const Update = async (id, data) => {
    let result = initialResult

    if (!isEmptyValue(data) && _.isObject(data) && !_.isNaN(id)) {
        await publicApi('put', `/customers/${id}`, data).then((res) => {
            result = {
                ...result,
                success: res.success,
                total_data: res.total_data,
                data: res.data
            }
        }).catch((err) => {
            // console.log(err.response.data)
        })
    }

    return result
}

const Delete = async (id) => {
    let result = initialResult

    if (!_.isNaN(id)) {
        const data = { is_active: "0" }

        await publicApi('put', `/customers/${id}`, data).then((res) => {
            result = {
                ...result,
                success: res.success,
                total_data: res.total_data,
                data: res.data
            }
        }).catch((err) => {
            // console.log(err.response.data)
        })
    }

    return result
}

export const customerController = {
    Get,
    Add,
    Update,
    Delete,
}