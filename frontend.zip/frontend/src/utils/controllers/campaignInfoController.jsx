import React from 'react'
import _, { isEmpty } from 'lodash'
import { publicApi, paginationService, generalService } from '../services'

const { IsEmpty } = generalService

const { PaginationInfo } = paginationService

const initialResult = {
    success: false,
    total_data: 0,
    // limit: 1,
    data: null,
    // paging: null
}

const Get = async (params) => {
    let result = initialResult
    let resultPaging = {}
    let paramString = ''
    let paramArray = []
    let paramObject = {
        limit: 20,
        order: 'name'
    }

    if (!IsEmpty(params) && _.isObject(params)) {
        if ('id' in params && !_.isNaN(params.id)) {
            await publicApi('get', `/campaign_info/${params.id}`).then((res) => {
                result = {
                    ...result,
                    success: res.success,
                    total_data: res.total_data,
                    data: res.data
                }
            }).catch((err) => {
                // console.log(err.response.data)
            })
        } else {
            paramObject = { ...paramObject, ...params }

            Object.keys(paramObject).map((item, i) => {
                if (!IsEmpty(paramObject[item])) {
                    paramArray.push(`${item}=${paramObject[item]}`)
                }
            })

            if (!IsEmpty(paramArray)) {
                paramString = `${paramArray.join("&")}`
            }

            await publicApi('get', `/campaign_info?${paramString}`).then((res) => {
                if ('paging' in res) {
                    let pagingInfo = PaginationInfo(res.total_data, paramObject.limit || 0, res.paging.current)
                    resultPaging = {
                        ...res.paging,
                        index: pagingInfo.index
                    }
                }

                result = {
                    ...result,
                    total_data: res.total_data,
                    limit: paramObject.limit,
                    data: res.data,
                    paging: resultPaging
                }
            }).catch((err) => {
                // console.log(err.response.data)
            })
        }

        return result
    }

    Object.keys(paramObject).map((item, i) => {
        if (!IsEmpty(paramObject[item])) {
            paramArray.push(`${item}=${paramObject[item]}`)
        }
    })

    if (!IsEmpty(paramArray)) {
        paramString = `${paramArray.join("&")}`
    }

    await publicApi('get', `/campaign_info?${paramString}`).then((res) => {
        if ('paging' in res) {
            let pagingInfo = PaginationInfo(res.total_data, paramObject.limit || 0, res.paging.current)
            resultPaging = {
                ...res.paging,
                index: pagingInfo.index
            }
        }

        result = {
            ...result,
            total_data: res.total_data,
            limit: paramObject.limit,
            data: res.data,
            paging: resultPaging
        }
    }).catch((err) => {
        // return result
    })

    return result
}

const Add = async (data) => {
    let result = initialResult

    if (!IsEmpty(data) && _.isObject(data)) {
        await publicApi('post', '/campaign_info', data).then((res) => {
            result = {
                ...result,
                success: res.success,
                total_data: res.total_data,
                data: res.data
            }
        }).catch((err) => {
            // console.log(err.response.data)
        })
    }

    return result
}

const Update = async (id, data) => {
    let result = initialResult

    if (!IsEmpty(data) && _.isObject(data) && !_.isNaN(id)) {
        await publicApi('put', `/campaign_info/${id}`, data).then((res) => {
            result = {
                ...result,
                success: res.success,
                total_data: res.total_data,
                data: res.data
            }
        }).catch((err) => {
            // console.log(err.response.data)
        })
    }

    return result
}

const Delete = async (id) => {
    let result = initialResult

    if (!_.isNaN(id)) {
        const data = { is_active: "0" }

        await publicApi('put', `/campaign_info/${id}`, data).then((res) => {
            result = {
                ...result,
                success: res.success,
                total_data: res.total_data,
                data: res.data
            }
        }).catch((err) => {
            // console.log(err.response.data)
        })
    }

    return result
}

export const campaignInfoController = {
    Get,
    Add,
    Update,
    Delete
}