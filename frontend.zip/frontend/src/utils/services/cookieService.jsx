import Cookies from 'universal-cookie'
import _ from 'lodash'
import { generalService } from './generalService'

const cookies = new Cookies()
const { isEmptyValue } = generalService

const Get = (key = false, opt = {}) => {
    if (key && !isEmptyValue(key) && _.isString(key)) {
        if (!_.isObject(opt)) {
            console.log('cookie error, option must be an object')
            return false;
        }

        try {
            const result = cookies.get(key, opt)

            // if (_.isObject(result)) {
            //     return JSON.parse(result);
            // }

            return result;
        } catch (err) {
            console.log(`cookie error, unable to get cookie ${key}`)
            return false;
        }
    }

    console.log('cookie error, key undefined')
    return false;
}

const GetAll = (opt = {}) => {
    if (!_.isObject(opt)) {
        console.log('cookie error, option must be an object')
        return false;
    }

    try {
        const result = cookies.getAll(opt)

        if (_.isObject(result)) {
            return JSON.stringify(result);
        }

        return result;
    } catch (err) {
        console.log('cookie error, unable to get all cookie')
        return false;
    }
}

const Set = (key = false, val = false, opt = {}) => {
    if (key && val && !isEmptyValue(key) && !isEmptyValue(val) && _.isString(key)) {
        if (!_.isObject(opt)) {
            console.log('cookie error, option must be an object')
            return false;
        }

        if (_.isObject(val)) {
            val = JSON.stringify(val)
        }

        try {
            cookies.set(key, val, opt)
            return key;
        } catch (err) {
            console.log(`cookie error, unable to set cookie ${key}`)
            return false;
        }
    }

    console.log('cookie error, key undefined')
    return false;
}

const Remove = (key = false, opt = {}) => {
    if (key && !isEmptyValue(key) && _.isString(key)) {
        if (!_.isObject(opt)) {
            console.log('cookie error, option must be an object')
            return false;
        }

        try {
            cookies.remove(key, opt)
            return key;
        } catch (err) {
            console.log(`cookie error, unable to remove cookie ${key}`)
            return false;
        }
    }

    console.log('cookie error, key undefined')
    return false;
}

export const cookieService = {
    Get,
    GetAll,
    Set,
    Remove
}
