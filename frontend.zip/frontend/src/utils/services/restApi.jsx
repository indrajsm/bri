import axios from 'axios'
import { cookieService } from '.';

export const publicApi = async (method, endpoint, data = []) => {
    const optMethod = method.toString().toLowerCase() || 'get'
    const token = cookieService.Get('ytoken')

    axios.defaults.baseURL = process.env.REACT_APP_MY_API
    axios.defaults.withCredentials = true
    axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded'

    if (endpoint !== '/users/login') {
        axios.defaults.headers.common = {
            'Authorization': `Bearer ${(token)}`
        }
    }

    let result = {}
    switch (optMethod) {
        case 'post':
            result = await axios.post(endpoint, data)
            break
        case 'put':
            result = await axios.put(endpoint, data)
            break
        case 'delete':
            result = await axios.delete(endpoint)
            break
        default:
            result = await axios.get(endpoint)
    }

    return result['data']
}
