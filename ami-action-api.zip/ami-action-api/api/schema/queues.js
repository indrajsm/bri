const Joi = require('@hapi/joi')

const schemas = {
    queueDetail: Joi.object().keys({
        id: Joi.string().required()
    }),
    queueMemberUpdate: Joi.object().keys({
        extension: Joi.string().required(),
        action: Joi.string().valid('add', 'remove').required()
    }),
    queueMemberStatusUpdate: Joi.object().keys({
        extension: Joi.string().required(),
        is_paused: Joi.boolean().required()
    }),
}

module.exports = schemas
