const Joi = require('@hapi/joi')

const schemas = {
    dial: Joi.object().keys({
        source: Joi.string().required(),
        destination: Joi.string().required(),
        actionid: Joi.string().required()
    }),
    hangup: Joi.object().keys({
        channel: Joi.string().required()
    }) 
}

module.exports = schemas
