const Joi = require('@hapi/joi')

const schemas = {
    details: Joi.object().keys({
        channel: Joi.string().required(),
        digit: Joi.number().required()
    }) 
}

module.exports = schemas
