const ami = require('../config/ami')

exports.whisper = (source, destination) => {
    return new Promise(async (resolve, reject) => {
        console.log('source: ', source);
        console.log('destination: ', destination);
        const whisperPrefix = '557'
        const unixTime = Math.floor(Date.now() / 1000) 
        const amiOptions = {
            'action': 'originate', 
            'channel' : 'SIP/' + source, 
            'exten': whisperPrefix + destination,
            'context': 'app-chanspy',
            'priority': 1,
            'variable':{
    			'SIPADDHEADER51':'Call-Info: answer-after=0'
  		    },
            'actionid': unixTime,
            'async':'yes',
        }

        ami.action(amiOptions, function(err, res) { 
            if (err) {
                console.log('error callback: ', err);
                return resolve(err)
            } else { 
                return resolve(res)
            }
        }) 
    })
}


exports.unwhisper = (channel) => {
    return new Promise(async (resolve, reject) => {
        const unixTime = Math.floor(Date.now() / 1000)
        const amiOptions = {
            'action': 'Hangup',   
            'channel' : channel,  
            'actionid': unixTime, 
            'async':'yes',
        }

        ami.action(amiOptions, function(err, res) { 
            if (err) {
                console.log('error: ', err);
                return resolve(err)
            } else { 
                return resolve(res)
            }
        }) 
    }) 
}
