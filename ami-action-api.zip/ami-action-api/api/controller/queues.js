const ami = require('../config/ami')

exports.addQueueMember = (extension, queue) => {
    return new Promise(async (resolve, reject) => {
        let res = {
            total_data: 0,
            success: false,
            data: false
        }
        const unixTime = Math.floor(Date.now() / 1000)
        const amiOptions = {
            'action': 'QueueAdd',  
            'queue': queue,	
            'interface':'SIP/' + extension,
            'paused': true,	
            'actionid': unixTime,
            'async':'yes',
        }

        ami.action(amiOptions, (err, res) => { 
            if (err) {
                // throw err
                console.error(err)
                res = {
                    success: false,
                    data: err
                }
                return resolve(res)
            }
            
            res = {
                total_data: 1,
                success: true,
                data: res
            }
            return resolve(res)
        }) 
    })
}

exports.removeQueueMember = (extension, queue) => {
    return new Promise(async (resolve, reject) => {
        let res = {
            total_data: 0,
            success: false,
            data: {}
        }
        const unixTime = Math.floor(Date.now() / 1000)
        const amiOptions = {
            'action': 'QueueRemove',  
            'queue': queue,	
            'interface':'SIP/' + extension,
            'actionid': unixTime,
            'async':'yes',
        }

        ami.action(amiOptions, (err, res) => { 
            if (err) {
                // throw err
                console.error(err)
                res = {
                    success: false,
                    data: err
                }
                return resolve(res)
            }
            
            res = {
                total_data: 1,
                success: true,
                data: res
            }
            return resolve(res)
        }) 
    })
}

exports.pauseQueueMember = (extension, queue, isPaused) => {
    return new Promise(async (resolve, reject) => {
        let res = {
            total_data: 0,
            success: false,
            data: {}
        }
        const unixTime = Math.floor(Date.now() / 1000)
        const amiOptions = {
            'action': 'QueuePause',  
            'queue': queue,	
            'interface':'SIP/' + extension,
            'actionid': unixTime,
            'paused': isPaused, 
            'async':'yes',
        }

        ami.action(amiOptions, (err, res) => {
            if (err) {
                // throw err
                console.error(err)
                res = {
                    success: false,
                    data: err
                }
                return resolve(res)
            }
            
            res = {
                total_data: 1,
                success: true,
                data: res
            }
            return resolve(res)
        }) 
    })
}
