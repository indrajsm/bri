const ami = require('../config/ami')

exports.transfer = (channel, destination, phone_number, username, context = 'CTX_CALL_REDIRECT') => {
    return new Promise(async (resolve, reject) => {
        const unixTime = Math.floor(Date.now() / 1000)
        const amiOptions = {
            'action': 'Redirect',   
            'channel' : channel,  
            'exten' : destination,   
            'context': context,
            'priority': 1, 
            'phone_number': phone_number,
            'username': username,
            'actionid': unixTime, 
            'async':'yes',
        }
        

        console.log(amiOptions)

        ami.action(amiOptions, function(err, res) { 
            if (err) {
                console.log('error: ', err);
                return resolve(err)
            } else { 
                return resolve(res)
            }
        }) 
    })
}
