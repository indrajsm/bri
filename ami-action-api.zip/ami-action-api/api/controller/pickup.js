const ami = require('../config/ami')

exports.pickup = (channel, destination, context = 'CTX_CALL_ANSWER')  => {
    return new Promise(async (resolve, reject) => {
        const unixTime = Math.floor(Date.now() / 1000)
        const amiOptions = {
            'action': 'Redirect',   
            'channel' : channel,  
            'context': context,
            'exten' : destination,   
            'priority': 1, 
            'actionid': unixTime, 
            'async':'yes',
        }

        ami.action(amiOptions, function(err, res) { 
            if (err) {
                console.log('error: ', err);
                return resolve(err)
            } else { 
                return resolve(res)
            }
        }) 
    })
}

