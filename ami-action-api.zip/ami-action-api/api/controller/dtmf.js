const ami = require('../config/ami')

exports.play = (channel, digit) => {
    return new Promise(async (resolve, reject) => {
        console.log('channel: ', channel);
        console.log('digit: ', digit);
        const unixTime = Math.floor(Date.now() / 1000)
        const amiOptions = {
            'action': 'PlayDTMF',   
            'channel' : channel,  
            'digit' : digit,    
            'actionid': unixTime, 
            'async':'yes',
        }

        ami.action(amiOptions, function(err, res) { 
            if (err) {
                console.log('error: ', err);
                return resolve(err)
            } else { 
                return resolve(res)
            }
        }) 
    })

}
 