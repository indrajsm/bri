const ami = require('../config/ami')

exports.listen = (source, destination) => {
    return new Promise(async (resolve, reject) => {
        
        console.log('source: ', source);
        console.log('destination: ', destination);
        const unixTime = Math.floor(Date.now() / 1000) 
        const listenPrefix = '556'
        const amiOptions = {
            'action': 'originate', 
            'channel' : 'SIP/' + source, 
            'exten': listenPrefix + destination,
            'context': 'app-chanspy',
            'priority': 1,
            'variable':{
    			'SIPADDHEADER51':'Call-Info: answer-after=0'
  		    },
            'actionid': unixTime,
            'async':'yes',
        }
        
        console.log(amiOptions)
        ami.action(amiOptions, function(err, res) { 
            if (err) {
                console.log('error callback: ', err);
                return resolve(err)
            } else { 
                console.log(res)
                return resolve(res)

            }
        }) 
    })
}

exports.unlisten = (channel) => {
    return new Promise(async (resolve, reject) => {
        const unixTime = Math.floor(Date.now() / 1000)
        const amiOptions = {
            'action': 'Hangup',   
            'channel' : channel,  
            'actionid': unixTime, 
            'async':'yes',
        }

        ami.action(amiOptions, function(err, res) { 
            if (err) {
                console.log('error: ', err);
                return resolve(err)
            } else { 
                return resolve(res)
            }
        }) 
    }) 
}
