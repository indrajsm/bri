const ami = require('../config/ami')
const config = require('../config')

exports.dial = (source, destination,actionid) => {
    return new Promise(async (resolve, reject) => { 
        prefix = config.outbound_prefix
        const amiOptions = {
            'action': 'originate', 
            'channel' : 'SIP/' + source, 
            'exten': prefix + destination,
            'context': 'from-internal',
            'priority': 1,
            'variable':{
    			'SIPADDHEADER51':'Call-Info: answer-after=0'
  		    },
            'actionid': actionid,
            'async':'yes',
        }
        

        ami.action(amiOptions, function(err, res) { 
            if (err) {
                console.log('error callback: ', err);
                return resolve(err)
            } else { 
                return resolve(res)
            }
        }) 
    })

}


exports.hangup = (channel) => {
    return new Promise(async (resolve, reject) => {
        const unixTime = Math.floor(Date.now() / 1000)
        const amiOptions = {
            'action': 'Hangup',   
            'channel' : channel,  
            'actionid': unixTime, 
            'async':'yes',
        }

        ami.action(amiOptions, function(err, res) { 
            if (err) {
                console.log('error: ', err);
                return resolve(err)
            } else { 
                return resolve(res)
            }
        }) 
    }) 
}