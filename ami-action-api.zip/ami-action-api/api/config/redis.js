const redis = require('redis')
const redisConfig = require('./index').redis
const redisOptions = {
    host: redisConfig.host,
    port: redisConfig.port,
	db: redisConfig.db,
    enable_offline_queue: false,
    password: redisConfig.password
}


let redisConnected = false 
const redisClient = redis.createClient(redisOptions)
  
redisClient.on('connect', function(){
    console.log('Redis connected!');
    redisConnected = true;
    exports.redisConnected = redisConnected
})
// redis error event
redisClient.on('error', function (err) {
    console.error(`Redis error: ${err}`)
    redisConnected = false;
    exports.redisConnected = redisConnected
});

redisClient.on('reconnecting', function () {
    console.log('Redis reconnecting ...');
    redisConnected = false;
    exports.redisConnected = redisConnected
});

exports.redisClient = redisClient
exports.redisConnected = redisConnected
