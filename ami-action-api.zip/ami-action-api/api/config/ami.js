const amiConfig = require('../config/index').ami
const ami = new require('asterisk-manager')(amiConfig.port, amiConfig.host, amiConfig.user, amiConfig.password, true)

ami.keepConnected()

// AMI Connection Events
ami.on('connect', (e) => {
	console.log('AMI connected!')
})

ami.on('close', (e) => {
	console.log('close: ', e)
})

ami.on('disconnect', (e) => {
	console.log('disconnect: ', e)
})

ami.on('error', (e) => {
	console.error(e)
	ami.disconnect()
})

module.exports = ami
