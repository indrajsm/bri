const rabbitmqConn = require("../config/rabbitmq")


function publishData(data) { 
    return new Promise((resolve, reject) => {

        if (!rabbitmqConn.rabbitmqConnected) { 
            return reject()
        }
 
        const content = Buffer.from(JSON.stringify(data), 'utf-8') 
        rabbitmqConn.rabbitmqChannel.publish(rabbitmqConn.exchangeName, rabbitmqConn.routingKey, content, { persistent: true}, function (err) {
            if (err) { 
                return reject(err)
            }    
            
            resolve(true)
        })
    })
}


exports.publishData = publishData