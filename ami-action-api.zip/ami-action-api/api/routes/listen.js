const express = require('express')

const listenController = require('../controller/listen')
const response = require('../helpers/response')
const router = express.Router()


router.post('/', async (req, res) => {
    const source = req.body.source
    const destination = req.body.destination

    

    if (source != undefined && destination != undefined) {
        let result = await listenController.listen(source, destination)
        let   data = {
            data:result
        }
        console.log(data);
        return response.sendSuccessData(res, data)
    } 
    else {
        return response.sendMethodNotAllowed(res , 'gagal')
    }
})


router.post('/unlisten',  async (req, res) => {
    const channel = req.body.channel 
    let results = await listenController.unlisten(channel)
    let data = {
        data: results
    }
    return response.sendSuccessData(res, data)
})



module.exports = router
