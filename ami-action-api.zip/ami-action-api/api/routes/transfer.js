const express = require('express')
const socketIOHelper = require("../helpers/socket_io")
const transferController = require('../controller/transfer')
const response = require('../helpers/response')
const router = express.Router()


router.post('/', async (req, res) => {
    const channel = req.body.channel
    const destination = req.body.destination
    const phone_number = req.body.phone_number
    const username = req.body.username

    if (channel != undefined && destination != undefined) {
        let results = await transferController.transfer(channel, destination, phone_number, username)
        let data = {
            data: results
        }
        console.log(data);

        const socketMessage = {
            phone_no: phone_number,
            destination: destination,
            channel: channel,
            username: username
        }

        console.log(socketMessage);
        socketIOHelper.emit('TransferCall', JSON.stringify(socketMessage))

        



        return response.sendSuccessData(res, data)
    }
    else {
        return response.sendMethodNotAllowed(res, 'gagal')
    }


})








module.exports = router
