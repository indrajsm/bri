const _ = require('lodash')
const config = require('../config')
const express = require('express')
const fs = require('fs')
const path = require('path')
const response = require('../helpers/response')
const routePath = './api/routes/'
const router = express.Router()
const scriptName = path.basename(__filename)

router.get('/', (req, res) => {
    res.send({app: 'Synergix AMI Action API'})
})

fs.readdirSync(routePath).forEach(function (file) {
    // not including this file
    if (file != scriptName) {
        // get only filename, cut the file format (.js)
        const name = file.split('.')[0]
        router.use(`/${name}`, require(`./${name}`))
    }
})

// for non-existing route
router.all('*', (req, res) => {
    response.sendNotFound(res)
})

// for production
if (config.env == 'production') {
    // override error
    router.use((error, req, res, next) => {
        if (error instanceof SyntaxError) { // Handle SyntaxError here.
            return response.sendBadRequest(res, 'Data Not Valid')
        }

        console.error(error.stack)
        response.sendInternalServerError(res)
    })
}

module.exports = router
