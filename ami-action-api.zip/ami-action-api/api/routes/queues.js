const express = require('express')
const queueSchema = require('../schema/queues')
const queuesController = require('../controller/queues')
const response = require('../helpers/response')
const router = express.Router()
const validationMiddleware = require('../middleware/validation')

router.put('/:id/members', validationMiddleware(queueSchema.queueDetail, 'params'), validationMiddleware(queueSchema.queueMemberUpdate, 'body'), async (req, res, next) => {
	const queue = req.params.id
	const extension = req.body.extension
	const action = req.body.action
	let result 
	if (action == 'add') {
		result = await queuesController.addQueueMember(extension, queue)
	} else {
		result = await queuesController.removeQueueMember(extension, queue)
	} 
	if (result.success === false) { 
		return response.sendSuccessData(res, result)
	}

	return response.sendSuccessData(res, result)
})

router.put('/:id/member_statuses', validationMiddleware(queueSchema.queueDetail, 'params'), validationMiddleware(queueSchema.queueMemberStatusUpdate, 'body'), async (req, res, next) => {
    const queue = req.params.id
	const extension = req.body.extension
    const isPaused = req.body.is_paused
    const result = await queuesController.pauseQueueMember(extension, queue, isPaused)
	
	if (result.success === false) {
		return response.sendSuccessData(res,result) 
	}

	return response.sendSuccessData(res, result)
})

// for existing endpoint with other request method
router.all(['/queues/:id/members', '/queues/:id/member_statuses'], (req, res, next) => {
	response.sendMethodNotAllowed(res)
})

module.exports = router
