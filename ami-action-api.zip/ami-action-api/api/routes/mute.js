const express = require('express')

const muteController = require('../controller/mute')
const response = require('../helpers/response')
const router = express.Router()


router.post('/', async (req, res) => { 
    const channel = req.body.channel 
    const direction = req.body.direction 
    const state = req.body.state  

   
    if (channel != undefined) {
        let result = await muteController.muteAudio(channel, direction, state)
        let data = {
            data: result,
            total_data:1
        }
        console.log(data);
        return response.sendSuccessData(res, data)
    }
    else {
        return response.sendMethodNotAllowed(res, 'gagal')
    }
     
    
})


module.exports = router
