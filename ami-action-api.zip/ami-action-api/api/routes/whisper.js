const express = require('express')

const whisperController = require('../controller/whisper')
const response = require('../helpers/response')
const router = express.Router()


router.post('/', async (req, res) => {
    const source = req.body.source
    const destination = req.body.destination



    if (source != undefined && destination != undefined) {
        let result = await whisperController.whisper(source, destination)
        let data = {
            data: result,
            total_data:1
        }
        console.log(data);
        return response.sendSuccessData(res, data)
    }
    else {
        return response.sendMethodNotAllowed(res, 'gagal')
    }
})


router.post('/unwhisper',  async (req, res) => {
    const channel = req.body.channel 
    let results = await whisperController.unwhisper(channel)
    let data = {
        data: results
    }
    return response.sendSuccessData(res, data)
})



module.exports = router
