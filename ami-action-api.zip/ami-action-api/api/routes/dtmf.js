const express = require('express')
const validationMiddleware = require('../middleware/validation')
const dtmfSchema = require('../schema/dtmf')
const dftmController = require('../controller/dtmf')
const response = require('../helpers/response')
const router = express.Router()

router.post('/', validationMiddleware(dtmfSchema.details, 'body'), async (req, res) => {
    const channel = req.body.channel 
    const digit = req.body.digit   
    let results = await dftmController.play(channel, digit)
    let data = {
        data: results
    }
    return response.sendSuccessData(res, data)
})
 
module.exports = router
