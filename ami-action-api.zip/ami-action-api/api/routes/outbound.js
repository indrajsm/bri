const express = require('express')
const validationMiddleware = require('../middleware/validation')
const outboundSchema = require('../schema/outbound')
const outboundController = require('../controller/outbound')
const response = require('../helpers/response')
const router = express.Router()

router.post('/dial', validationMiddleware(outboundSchema.dial, 'body'), async (req, res) => {
    const {source,destination,actionid} = req.body 
    let results = await outboundController.dial(source, destination,actionid)
    let data = {
        data: results
    }
    return response.sendSuccessData(res, data)
})

router.post('/hangup', validationMiddleware(outboundSchema.hangup, 'body'), async (req, res) => {
    const channel = req.body.channel 
    let results = await outboundController.hangup(channel)
    let data = {
        data: results
    }
    return response.sendSuccessData(res, data)
})

module.exports = router
