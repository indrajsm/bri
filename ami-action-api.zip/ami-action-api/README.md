# Synergix AMI Action API 

Synergix AMI Action API using Node.js with Express.js Framework

For Windows system:
Please install nodemon "npm install -g nodemon" to run this project.
Available execution command for Windows: 
- "npm run dev-win" to start with development environment (.env file)
- "npm run stag-win" to start with staging environment (.env-staging file)
- "npm run prod-win" to start with production environment (.env-production file)

For Linux and MacOS system:
Please install pm2 "npm install -g pm2" to run this project.
Available execution command for Linux and MacOS: 
- "npm run dev" to start with development environment (.env file)
- "npm run stag" to start with staging environment (.env-staging file)
- "npm run prod" to start with production environment (.env-production file)