const redisHelper = require('./helper/redis')
var mysql = require('mysql');
const { db } = require('./config');
var dbPool = require('./config/database')
module.exports = {
    start: function (generalListener, paramLib) {
        var _ = paramLib._;
        var counter = paramLib.counter;
        var nrc = paramLib.nrc;

        generalListener.on('connection', (socket) => {
            const socketId = socket.id
            const user_id = socket.handshake.query.user_id || false
            const extension = socket.handshake.query.extension || false
            const user_level_id = socket.userLevel || false


            console.log('socketId ', socket.id)
            console.log('user_id: ', user_id)
            console.log('extension: ', extension)


            console.log('------------------------')

            if (extension) {
                const cacheKey = `ext:${extension}`
                const cacheField = 'socket_id'
                redisHelper.setData({ key: cacheKey, field: cacheField, data: socketId })
            }

            socket.on('disconnect', () => {
                console.log('disconnect socketId ', socket.id)
            })


            socket.on("AgentCalled", function (data) {
                let receivedData = JSON.parse(data)
                const { socket_id } = receivedData
                console.log("receivedData: ", receivedData);
                socket.broadcast.to(socket_id).emit("agent-called-event", receivedData)
            })



            socket.on("AgentConnect", function (data) {
                let receivedData = JSON.parse(data)
                const { socket_id } = receivedData
                socket.broadcast.to(socket_id).emit("agent-connect-event", receivedData)
            })


            socket.on("AgentComplete", function (data) {
                let receivedData = JSON.parse(data)
                const { socket_id } = receivedData
                socket.broadcast.to(socket_id).emit("agent-complete-event", receivedData)
            })


            socket.on("Hangup", function (data) {
                let receivedData = JSON.parse(data)
                const { socket_id } = receivedData
                socket.broadcast.to(socket_id).emit("hangup-event", receivedData)
            })

            socket.on("OriginateResponse", function (data) {
                let receivedData = JSON.parse(data)
                const { socket_id } = receivedData
                socket.broadcast.to(socket_id).emit("originate-response-event", receivedData)
            })

            socket.on("BridgeEnter", function (data) {
                let receivedData = JSON.parse(data)
                const { socket_id } = receivedData
                socket.broadcast.to(socket_id).emit("bridge-enter-event", receivedData)
            })


            socket.on("TransferCall", async function (data) {
                let receivedData = JSON.parse(data)
                const { destination, phone_no, channel } = receivedData

                // get socket id from cache
                let cacheKey = `ext:${destination}`
                let cacheField = 'socket_id'
                redisHelper.getData(cacheKey, cacheField).then(res => {
                    if (res !== 'null') {
                        const socket_id = res.replace(/['"]+/g, '')
                        socket.broadcast.to(socket_id).emit("transfercall-event", { phone_no: phone_no, call_id: call_id, channel: channel })
                    }
                }).catch(err => {
                    console.log(err)
                })
            })


            socket.on("TransferCallServer", async function (data) {
                let receivedData = JSON.parse(data)
                const { destination, phone_no, customer_id, call_id, channel, campaign_id } = receivedData

                // get socket id from cache
                let cacheKey = `ext:${destination}`
                let cacheField = 'socket_id'
                redisHelper.getData(cacheKey, cacheField).then(res => {
                    if (res !== 'null') {
                        const socket_id = res.replace(/['"]+/g, '')
                        socket.broadcast.to(socket_id).emit("transfercallserver-event", {
                            phone_no: phone_no, customer_id: customer_id, call_id: call_id, channel: channel, campaign_id: campaign_id
                        })
                    }
                }).catch(err => {
                    console.log(err)
                })
            })


            // testSocket
            socket.on("socket-test", data => {
                console.log(data)
                // bordcast to all clients
                generalListener.emit("socket-test", data);
            });

            // testSocket
            socket.on("socket-testing", function (data) {
                console.log('socket-testing: ', data);
                // bordcast to all clients
                socket.broadcast.to(data).emit("socket-testing", data)
            });



            // message
            socket.on("message", function (data) {
                // broadcase to all clients
                generalListener.emit("message", data);
            });



            /* User Escort */
            socket.on("escorts", function (data) {
                console.log(data);
                counter.userEscort(function (result) {
                    generalListener.emit("total-escorts", result);
                    console.log('total-escort', result);
                });
            });


            // socket.on("call-campaigns", function (data) {

            //     let campaignId = data.campaign_id || false

            //     if (campaignId === false) {
            //         if (user_level_id > 1) {
            //             counter.totalCallAllCampaigns(function (result) {
            //                 console.log('========total-call-campaigns======')
            //                 console.log(result)
            //                 generalListener.emit("total-call-campaigns", result);
            //             });
            //         }
            //         else {
            //             let queryCallCampaigns = `SELECT user_id, username, campaign_id, COUNT(calls.id) AS total_call FROM calls JOIN users ON users.id = calls.user_id WHERE date(call_date) = CURRENT_DATE AND calls.user_id = ${user_id} AND calls.outbound_status_id = 1  GROUP BY  campaign_id`
            //             dbPool.query(queryCallCampaigns, function (err, result) {
            //                 if (err) {
            //                     return;
            //                 }

            //                 const data = JSON.stringify(result);
            //                 console.log('========total-call-campaigns======')
            //                 console.log(data)
            //                 generalListener.emit("total-call-campaigns", data);
            //             })
            //         }

            //     }
            //     else {
            //         let queryCallCampaigns = `SELECT user_id, username, campaign_id, COUNT(calls.id) AS total_call FROM calls JOIN users ON users.id = calls.user_id WHERE date(call_date) = CURRENT_DATE AND calls.campaign_id = ${campaignId} AND calls.outbound_status_id = 1  GROUP BY user_id, campaign_id`

            //         dbPool.query(queryCallCampaigns, function (err, result) {
            //             if (err) {
            //                 return;
            //             }

            //             const data = JSON.stringify(result);
            //             console.log('========total-call-campaigns======')
            //             console.log(data)
            //             generalListener.emit("total-call-campaigns", data);
            //         })
            //     }
            // });

            // socket.on("amount-campaigns", function (data) {
            //     let campaignId = data.campaign_id || false
            //     if (campaignId === false) {
            //         if (user_level_id > 1) {
            //             counter.totalAmountAllCampaigns(function (result) {
            //                 console.log('========total-amount-campaigns======')
            //                 console.log(result)
            //                 generalListener.emit("total-amount-campaigns", result);
            //             });
            //         }
            //         else {
            //             let queryAmountCampaigns = `SELECT users.id AS user_id, username, calls.campaign_id, SUM(amount) AS amount FROM calls JOIN users ON users.id = calls.user_id JOIN customers ON customers.id = calls.customer_id WHERE date(call_date) = CURRENT_DATE AND calls.user_id = ${user_id} AND calls.outbound_status_id = 1 AND customers.customer_status_id = 4 GROUP BY  calls.campaign_id`

            //             dbPool.query(queryAmountCampaigns, function (err, result) {
            //                 if (err) {
            //                     return;
            //                 }

            //                 var data = JSON.stringify(result);
            //                 console.log('========total-amount-campaigns======')

            //                 console.log(data)
            //                 generalListener.emit("total-amount-campaigns", data);
            //             })
            //         }
            //     }
            //     else {
            //         let queryAmountCampaigns = `SELECT users.id AS user_id, username, calls.campaign_id, SUM(amount) AS amount FROM calls JOIN users ON users.id = calls.user_id JOIN customers ON customers.id = calls.customer_id WHERE date(call_date) = CURRENT_DATE AND calls.campaign_id = ${campaignId} AND calls.outbound_status_id = 1 AND customers.customer_status_id = 4 GROUP BY calls.user_id, calls.campaign_id`

            //         dbPool.query(queryAmountCampaigns, function (err, result) {
            //             if (err) {
            //                 return;
            //             }

            //             var data = JSON.stringify(result);
            //             console.log('========total-amount-campaigns======')
            //             console.log(data)
            //             generalListener.emit("total-amount-campaigns", data);
            //         })
            //     }


            // });


            socket.on("call-all-campaigns", function (data) {

                counter.totalCallAllCampaigns(function (result) {
                    console.log('========total-call-all-campaigns======')
                    console.log(result)
                    generalListener.emit("total-call-all-campaigns", result);
                });

            });
            socket.on("amount-all-campaigns", function (data) {
                counter.totalAmountAllCampaigns(function (result) {
                    console.log('========total-amount-all-campaigns======')
                    console.log(result)
                    generalListener.emit("total-amount-all-campaigns", result);
                });

            });
            socket.on("call-campaigns", function (data) {
                let campaignId = data.campaign_id
                let queryCallCampaigns = `SELECT user_id, username, campaign_id, COUNT(calls.id) AS total_call FROM calls JOIN users ON users.id = calls.user_id WHERE date(call_date) = CURRENT_DATE AND calls.campaign_id = ${campaignId} AND calls.outbound_status_id = 1  GROUP BY user_id, campaign_id`
                
                dbPool.query(queryCallCampaigns, function (err, result) {
                    if (err) {
                        return;
                    }

                    const data = JSON.stringify(result);
                    console.log('========total-call-campaigns======')
                    console.log(data)
                    generalListener.emit("total-call-campaigns", data);
                })
            });
            socket.on("amount-campaigns", function (data) {
                let campaignId = data.campaign_id
                let queryAmountCampaigns = `SELECT users.id AS user_id, username, calls.campaign_id, SUM(amount) AS amount FROM calls JOIN users ON users.id = calls.user_id JOIN customers ON customers.id = calls.customer_id WHERE date(call_date) = CURRENT_DATE AND calls.campaign_id = ${campaignId} AND calls.outbound_status_id = 1 GROUP BY calls.user_id, calls.campaign_id`
                
                dbPool.query(queryAmountCampaigns, function (err, result) {
                    if (err) {
                        return;
                    }

                    var data = JSON.stringify(result);
                    console.log('========total-amount-campaigns======')
                    console.log(data)
                    generalListener.emit("total-amount-campaigns", data);
                })
            });


        });
    },
};
