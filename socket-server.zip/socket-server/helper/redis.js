//const crypto = require('crypto')
const redisConn = require('../config/redis')
const _ = require('lodash')

/**
 * set data for Redis
 * @param  {string} key - Redis key
 * @param  {string} field - Redis field
 * @param  {Object} data - Redis data
 * @returns {Promise.<string>} - reply result
 */
exports.setData = ({key = '', field = '', data = {}}) => {
    return new Promise(async (resolve, reject) => {
        if (!redisConn.redisStatus) {
            return resolve(false)
        }

        //let dataField = crypto.createHash('md5').update(field).digest('hex')
        let dataField = field
        redisConn.redisClient.hmset(key, dataField, JSON.stringify(data), async (err, res) => {
            let setExpire = await this.setExpire({key})
            resolve(res)
        })
    })
}

/**
 * get data from Redis
 * @param  {string} key - Redis key
 * @param  {string} field - Redis field
 * @returns {Promise.<Object>} - data result
 */
exports.getData = (key, field) => {

    return new Promise(async (resolve, reject) => {
        if (!redisConn.redisStatus) {
            return resolve(false)
        }

        //let dataField = crypto.createHash('md5').update(field).digest('hex')
        let dataField = field  
        redisConn.redisClient.hmget(key, dataField, (err, res) => {
            if (err) {
                console.error(err)
                return resolve(err)
            }
            
            resolve(_.trim(res))
        })
         
    })
    
}


/**
 * get data from Redis
 * @param  {string} key - Redis key 
 * @returns {Promise.<Object>} - data result
 */
exports.getAll = ({key = ''}) => {
    return new Promise(async (resolve, reject) => {
        if (!redisConn.redisStatus) {
            return resolve(false)
        }
   
        redisConn.redisClient.hgetall(key, (err, res) => {
            if (err) {
                console.error(err)
                return resolve(err)
            }

            if (res) {
                resolve([res])
            } else {
                resolve(false)
            }
        })
 
    })
}


/**
 * check Redis key and field
 * @param  {string} key - Redis key
 * @param  {string} field - Redis field
 * @returns {Promise.<number>} - reply result
 */
exports.checkData = ({key = '', field = ''}) => {
    return new Promise((resolve, reject) => {
        if (!redisConn.redisStatus) {
            return resolve(false)
        }

        //let dataField = crypto.createHash('md5').update(field).digest('hex')
        let dataField = field
        redisConn.redisClient.hexists(key, dataField, (err, res) => {
            if (err) {
                console.error(err)
                return resolve(err)
            }
            
            resolve(res)         
        })
    })
}

/**
 * delete field and data from Redis key
 * @param  {string[]} key - Redis key
 * @returns {Promise.<number>} - reply result
 */
exports.deleteData = ({key = []}) => {
    return new Promise((resolve, reject) => {
        if (!redisConn.redisStatus) {
            return resolve(false)
        }
         
        for (k in key) {  
            redisConn.redisClient.del(key[k], (err, res) => {
                if (err) {
                    console.error(err)
                } 
            })
        }
    })
}


/**
 * delete field from Redis hash
 * @param  {string} key - Redis hash key
 * @param  {string[]} field - Redis hash field
 * @returns {Promise.<number>} - reply result
 */
exports.deleteHashData = ({key, field = []}) => {
    return new Promise((resolve, reject) => {
        if (!redisConn.redisStatus) {
            return resolve(false)
        }
        
        redisConn.redisClient.hdel(key, field, (err, res) => {
            if (err) {
                console.error(err)
            } 
        }) 
    })
}

/**
 * set expire data for Redis
 * @param  {string} key - Redis key
 * @returns {Promise.<number>} - reply result
 */
exports.setExpire = ({key = ''}) => {
    return new Promise((resolve, reject) => {
        if (!redisConn.redisStatus) {
            return resolve(false)
        }
        
        redisConn.redisClient.expire(key, redisConn.redisExpire, (err, res) => {
            if (err) {
                console.error(res)
            }
        })
    })
}
