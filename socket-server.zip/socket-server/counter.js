var mysql = require('mysql');
const { db } = require('./config');
var dbPool = require('./config/database')



function monUserCount(callback) {
    var queryUser = 'SELECT * FROM view_monitor_user_count LIMIT 1';

    dbPool.query(queryUser, function (err, result) {
        if (err) {
            callback(err);
            return;
        }

        var data = JSON.stringify({
            login_count: result[0].login_count,
            offline: result[0].offline,
            not_available: result[0].not_available,
            ready_in: result[0].ready_in,
            online_in: result[0].online_in,
            acw_user: result[0].acw_user,
            break_user: result[0].break_user,
            ready_media: result[0].ready_media,
            ready_out: result[0].ready_out,
            online_out: result[0].online_out,
            online_media: result[0].online_media,
            ready_chat: result[0].ready_chat,
            ringing: result[0].ringing,
            paperwork: result[0].paperwork,
            ready_inb_email: result[0].ready_inb_email,
            ready_out_email: result[0].ready_out_email,
            ready_inb_sms: result[0].ready_inb_sms,
            ready_out_sms: result[0].ready_out_sms,
            chat_user: result[0].chat_user,
            voice_mail: result[0].voice_mail
        });

        callback(data);
    });
};

function monCallCount(callback) {
    var queryCallCount = 'SELECT * FROM view_monitor_call_count LIMIT 1';

    dbPool.query(queryCallCount, function (err, result) {
        if (err) {
            callback(err);
            return;
        }

        var data = JSON.stringify({
            incoming_call: result[0].incoming_call,
            ivr_call: result[0].ivr_call,
            queue_call: result[0].queue_call,
            answer_call: result[0].answer_call,
            abandone_ivr: result[0].abandone_ivr,
            abandone_queue: result[0].abandone_queue,
            abandone_transfer: result[0].abandone_transfer,
            abandone_agent: result[0].abandone_agent,
            voice_mail: result[0].voice_mail
        });

        callback(data);
    });
}

function monCallDuration(callback) {
    var queryCallDuration = 'SELECT * FROM view_monitor_call_duration LIMIT 1';

    dbPool.query(queryCallDuration, function (err, result) {
        if (err) {
            callback(err);
            return;
        }

        var data = JSON.stringify({
            avg_asa: result[0].avg_asa,
            avg_aat_ivr: result[0].avg_aat_ivr,
            avg_aat: result[0].avg_aat,
            avg_aht: result[0].avg_aht,
            avg_acd: result[0].avg_acd,
            avg_acw: result[0].avg_acw,
            ringing_time: result[0].ringing_time,
            abandone_rate: result[0].abandone_rate,
            answer_rate: result[0].answer_rate,
            service_level: result[0].service_level,
            voice_rate: result[0].voice_rate
        });

        callback(data);
    });
}

function monCallType(callback) {
    var queryCallType = 'SELECT * FROM view_monitor_inbound_type LIMIT 1';

    dbPool.query(queryCallType, function (err, result) {
        if (err) {
            callback(err);
            return;
        }

        var data = JSON.stringify([{
            name: 'Blank Call',
            total: result[0].blank_chat
        },
        {
            name: 'Test Call',
            total: result[0].test_chat
        },
        {
            name: 'Wrong Call',
            total: result[0].wrong_chat
        },
        {
            name: 'Prank Call',
            total: result[0].prank_chat
        },
        {
            name: 'Inquiry',
            total: result[0].inquiry
        },
        {
            name: 'Permohonan',
            total: result[0].request
        },
        {
            name: 'Complaint',
            total: result[0].complaint
        },
        {
            name: 'FollowUp Ticket',
            total: result[0].followup_ticket
        },

        ]);

        callback(data);
    });
}

function userEscort(callback) {
    var queryUserEscort = `SELECT
	users.id,
	users.username AS agent,
	user_activity_id,
	user_activities.name AS activity,
	(SELECT extensions.ext_no FROM extensions WHERE extensions.user_id = users.id) AS extension ,
	IF
	( CURRENT_TIMESTAMP ( ) > users.last_activity_time, timediff( CURRENT_TIMESTAMP ( ), users.last_activity_time ), '00:00:00' ) AS duration,
	date_format(
		(
		SELECT
			user_events.event_date 
		FROM
			user_events
		WHERE
			cast( user_events.event_date AS date ) = curdate( ) 
			AND user_events.user_id = users.id
			AND user_events.user_activity_id > 1 
		ORDER BY
			user_events.id
			LIMIT 1 
		),
		'%Y-%m-%d %H:%i:%s' 
	) AS first_login,
	date_format(
		(
		SELECT
			user_events.event_date 
		FROM
			user_events
		WHERE
			cast( user_events.event_date AS date ) = curdate( ) 
			AND user_events.user_id = users.id 
			AND user_events.is_logout = 1 
		ORDER BY
			user_events.id DESC 
			LIMIT 1 
		),
		'%Y-%m-%d %H:%i:%s' 
	) AS last_logout
FROM
	users
	JOIN user_activities ON user_activities.id = users.user_activity_id 
WHERE
	user_activity_id > 1 AND is_login = 1 `;

    dbPool.query(queryUserEscort, function (err, result) {
        if (err) {
            callback(err);
            return;
        }

        var data = JSON.stringify(result);

        callback(data);
    });
}

function unreadMedia(callback) {
    var queryUnreadMedia = 'SELECT * FROM view_total_unread_media LIMIT 1';

    dbPool.query(queryUnreadMedia, function (err, result) {
        if (err) {
            callback(err);
            return;
        }

        var data = JSON.stringify(result);

        callback(data);
    });
};

function monMedia(callback) {
    var queryUnreadMedia = 'SELECT * FROM view_monitor_media LIMIT 1';

    dbPool.query(queryUnreadMedia, function (err, result) {
        if (err) {
            callback(err);
            return;
        }

        var data = JSON.stringify(result);

        callback(data);
    });
};

function monIncomingCall(callback) {
    var queryIncomingCall = 'SELECT * FROM view_monitor_incoming';

    dbPool.query(queryIncomingCall, function (err, result) {
        if (err) {
            callback(err);
            return;
        }

        var data = JSON.stringify({
            incoming_call: result[0].incoming_call,
            ivr_call: result[0].ivr_call,
            queue_call: result[0].queue_call
        });

        callback(data);
    });
};

function totalPreclose(callback) {
    var queryTotalPreclose = 'SELECT COUNT(id) as total FROM tickets WHERE ticket_status_id= 5';

    dbPool.query(queryTotalPreclose, function (err, result) {
        if (err) {
            callback(err);
            return;
        }

        var data = JSON.stringify({
            total_preclose: result[0].total
        });

        callback(data);
    });
};

function totalCallAllCampaigns(callback) {
    const queryCallAllCampaigns = `SELECT user_id, username, COUNT(calls.id) as total_call FROM calls JOIN users ON users.id = calls.user_id WHERE DATE(call_date) = CURRENT_DATE AND calls.outbound_status_id = 1 GROUP BY user_id`

    dbPool.query(queryCallAllCampaigns, function (err, result) {
        if (err) {
            callback(err);
            return;
        }

        const data = JSON.stringify(result);
        callback(data);
    })
}

function totalAmountAllCampaigns(callback) {
    const queryAmountAllCampaigns = `SELECT users.id AS user_id, username, SUM(amount) AS amount FROM calls JOIN users ON users.id = calls.user_id JOIN customers ON customers.id = calls.customer_id WHERE date(call_date) = CURRENT_DATE AND calls.outbound_status_id = 1 AND customers.customer_status_id = 4 GROUP BY calls.user_id`

    dbPool.query(queryAmountAllCampaigns, function (err, result) {
        if (err) {
            callback(err);
            return;
        }

        const data = JSON.stringify(result);
        callback(data);
    })
}





// enable function to be access from different file
exports.monUserCount = monUserCount;
exports.monCallCount = monCallCount;
exports.monCallDuration = monCallDuration;
exports.monCallType = monCallType;
exports.userEscort = userEscort;
exports.unreadMedia = unreadMedia;
exports.monIncomingCall = monIncomingCall;
// exports.monBrandCount = monBrandCount;
exports.monMedia = monMedia;
exports.totalPreclose = totalPreclose;
exports.totalCallAllCampaigns = totalCallAllCampaigns;
exports.totalAmountAllCampaigns = totalAmountAllCampaigns;
