module.exports = {
    start: function (ticket, paramLib) {
        var _ = paramLib._;
        var nrc = paramLib.nrc;

        ticket.on('connection', function (socket) {
            // Ticket Email Notif (insert data to email table for notification)
			socket.on('email-notification', function (data) {
				if (_.isObject(data)) {
					var ticket_id = data.ticket_id;
					var type = data.type; // status, assign, follow_up, over_sla, over_sla_hmin1, over_sla_hplus1, over_sla_hplus2
					
					if (ticket_id && type) {
						var command = 'php /var/www/html/synergix-beko/ticket-script/email_ticket_single.php '+ticket_id+' '+type;
						console.log('running command: '+command);
						var errorCallback = function(data) {
							console.log(data);
						};
						var dataCallback = function(data) {
							console.log(data);
						};
						nrc.run(command, { onData: dataCallback, onError: errorCallback });
					}
				}
			});
			
			// Copy email_attachments data dari email inbound ke ticket_attachments
			socket.on('copy-attachment', function (data) {
				if (_.isObject(data)) {
					var ticket_id = data.ticket_id;
					var email_id = data.email_id;
					
					if (ticket_id && email_id) {
						var command = 'php /var/www/html/synergix-beko/ticket-script/copy_email_attachment.php '+ticket_id+' '+email_id;
						console.log('running command: '+command);
						var errorCallback = function(data) {
							console.log(data);
						};
						var dataCallback = function(data) {
							console.log(data);
						};
						nrc.run(command, { onData: dataCallback, onError: errorCallback });
					}
				}
			});
			
			// Tag media ke ticket
			socket.on('media-tag', function (data) {
				console.log('media-tag!', data);
				if (_.isObject(data)) {
					var ticket_id = data.ticket_id;
					var media_id = data.media_id;
					var media_record_id = data.media_record_id;
					
					if (ticket_id && media_id && media_record_id) {
						var command = 'php /var/www/html/synergix-beko/ticket-script/media_ticket_tag.php '+ticket_id+' '+media_id+' '+media_record_id;
						console.log('running command: '+command);
						var errorCallback = function(data) {
							console.log(data);
						};
						var dataCallback = function(data) {
							console.log(data);
						};
						nrc.run(command, { onData: dataCallback, onError: errorCallback });
					}
				}
			});
        });
    }
}