const _ = require('lodash')
const express = require('express')
const app = express()
const fs = require('fs')
const http = require('http').Server(app)
const io = require('socket.io')
const jwt = require('jsonwebtoken')
const os = require('os')
const config = require('./config')
const dbPool = require('./config/database')
const dbConn = require('./config/databaseNoPool')
const generalEvent = require('./generalEvent')
var counter = require('./counter');
var paramLib = {
    _,
    counter,
    
};


app.get('/', (req, res) => {
	res.send('<h1>Synergix Websocket Server</h1>')
})

app.get('/testwithpool', (req, res) => {
	dbPool.query('SELECT * FROM calls LIMIT 10', (err, result, fields) => {
		if (err) { 
			console.error('error ',err)  
			res.status(200).send(err)
		} else {
			res.status(200).send(result)
		}
	})
})

app.get('/testnopool', (req, res) => {	
	let query = 'SELECT * FROM calls LIMIT 10'
	
	dbConn.query(query, (err, result, fields) => {
		if (err) { 
			console.error('error ',err)  
			res.status(200).send(err)
		} else { 
			res.status(200).send(result)
		}

	})
}) 

http.listen(config.port,'0.0.0.0', (err) => {
	if (err) {
		console.error(`server error`)
	} else {
		console.log(`App is up and running for ${config.env} environment | PORT: ${config.port}`)
	}
})

// socket.io server 
var listener = io.listen(http)

listener.use((socket, next) => {
    
	let token = socket.handshake.query.token,
		clientIp = socket.request.connection.remoteAddress,
		listIp = fs.readFileSync('list_ip.txt').toString().split("\n"),
		decodedToken
		
	const isWindows = (os.platform() === 'win32')
	
	if (isWindows) {
	   listIp = fs.readFileSync('list_ip.txt').toString().split("\r\n")
       
	}
	
	try {
		if (_.indexOf(listIp, clientIp) >= 0) {
			socket.connectedUser = 'machine'
			next()
		} else {
			//const secret = new Buffer.from(config.jwt.key, 'base64')
			const secret = config.jwt.key
			const algorithms = [config.jwt.algorithm]
			decodedToken = jwt.verify(token, secret, {algorithms: algorithms})
			socket.connectedUser = decodedToken.username
			socket.tokenExpire = decodedToken.exp * 1000
            socket.userLevel = decodedToken.user_level_id
			
			next()
		}
	} catch (e) {
		next(new Error('not valid token'))
		const err = new Error('not valid token')
		err.data = { message: 'not valid token', authenticated: false }
		next(err)
	}
})

generalEvent.start(listener.sockets, paramLib);
