const config = require('./index')
const mysql = require('mysql')

const dbConn = mysql.createConnection({
    host: config.db.host,
    user: config.db.user,
    password: config.db.password,
    database: config.db.name,
    port: config.db.port,
    multipleStatements: true,
    dateStrings: true // Force date types (TIMESTAMP, DATETIME, DATE) to be returned as strings rather then inflated into JavaScript Date objects. (Default: false)
})

dbConn.connect((err) => {
    if (err) throw err;
})

module.exports = dbConn
