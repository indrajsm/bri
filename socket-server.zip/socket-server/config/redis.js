const redis = require('redis')
const redisConfig = require('./index').redis
const redisOptions = {
    host: redisConfig.host,
    port: redisConfig.port,
	db: redisConfig.db,
    enable_offline_queue: false,
    password: redisConfig.password
};
const redisExpire = redisConfig.expire // in seconds
let redisStatus = false

if (redisConfig.serviceStatus == 1) {
    const redisClient = redis.createClient(redisOptions);

    // redis error event
    redisClient.on('error', function (err) {
        console.error(`Redis error: ${err}`)
        redisStatus = false;
        exports.redisStatus = redisStatus
    });

    // redis connect event
    redisClient.on('connect', function () {
        console.log('Redis connected!');
        redisStatus = true;
        exports.redisStatus = redisStatus
    });

    redisClient.on('reconnecting', function () {
        console.log('Redis reconnecting ...');
        redisStatus = false;
        exports.redisStatus = redisStatus
    });
    
    exports.redisClient = redisClient
}

exports.redisExpire = redisExpire
exports.redisStatus = redisStatus
