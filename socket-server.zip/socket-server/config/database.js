const config = require('./index')
const mysql = require('mysql')
const util = require('util')

const pool = mysql.createPool({
  connectionLimit: 50,
  host: config.db.host,
  user: config.db.user,
  password: config.db.password,
  port: config.db.port,
  database: config.db.name
})



// Ping database to check for common exception errors.
pool.getConnection((err, connection) => {
  if (err) {
    if (err.code === 'PROTOCOL_CONNECTION_LOST') {
      console.error('Database connection was closed.')
    }
    if (err.code === 'ER_CON_COUNT_ERROR') {
      console.error('Database has too many connections.')
    }
    if (err.code === 'ECONNREFUSED') {
      console.error('Database connection was refused.')
    }
  }

  if (connection) connection.release()

  return
})

pool.on('connection', function (connection) {
  //console.log('connection');
});

pool.on('acquire', function (connection) {
  //console.log('Connection %d acquired', connection.threadId);
});

pool.on('enqueue', function () {
  //console.log('Waiting for available connection slot');
});

pool.on('release', function (connection) {
  //console.log('Connection %d released', connection.threadId);
});

// Promisify for Node.js async/await.
pool.query = util.promisify(pool.query)

module.exports = pool