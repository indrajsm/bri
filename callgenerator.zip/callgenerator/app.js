const main = require('./main')
const logger = require('./helper/logger')
const cron = require('node-cron'); 

let is_running = false

try {
    cron.schedule('*/5 * * * * *', function () {
  

        if (is_running === false) {
            
            is_running = true 
            main.main()
            
            is_running = false
        } else {
            console.log(`process is already running`);
        }
    });
    logger("debug", { from: "app", message: "Running..." })
} catch (error) {
    logger("error", { from: "app", event: error })
}

