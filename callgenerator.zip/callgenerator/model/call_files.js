const db = require('../config/database')
const table = "call_files";
var currentdate = new Date();
var datetime = currentdate.getFullYear() + "-"
    + (currentdate.getMonth() + 1) + "-"
    + currentdate.getDate() + " "
    + currentdate.getHours() + ":"
    + currentdate.getMinutes() + ":"
    + currentdate.getSeconds();

class call_files {
    static async insertCallFiles(campaign_id, customer_id, filename, filepath) {

        return await db.table(table).insert({ 'campaign_id': campaign_id, 'customer_id': customer_id, 'filename': filename, 'filepath': filepath, 'created_at': datetime })
            .then(res => res[0])
            .catch(err => console.error(err))
    }
    static async updateCallFiles(callfileID) {

        return await db.table(table).update('is_moved', 1).where('id', callfileID)
            .then(res => res)
            .catch(err => console.error(err))
    }
}


module.exports = call_files;