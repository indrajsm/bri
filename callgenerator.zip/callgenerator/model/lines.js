
const db = require('../config/database')
const table = "call_lines";


class call_lines {
    static async getCount() {

        return db.table(table).count('id as count').where('status_id', 1).whereNull('dialing_no')
            .then(res => res[0])
            .catch(err => console.error(err))
    }


    static async updateLines(phone_number) {
        return await db.table(table).where('status_id', 1).whereNull('dialing_no').limit(1).update({ dialing_no: phone_number, updated_at: db.fn.now() })
            .then(res => res[0])
            .catch(err => console.error(err))
    }

    static async getLines(phone_number) {
        return await db.table(table).select('line_no').where({ status_id: 1, dialing_no: phone_number }).orderBy('updated_at','desc').limit(1)
            .then(res => res[0])
            .catch(err => console.error(err))
    }

    static async bookLines(phone_number, user_id, ext_no) {
        return await db.table(table).where('status_id', 1).whereNull('dialing_no').limit(1).update({ dialing_no: phone_number, user_id: user_id, ext_no: ext_no, updated_at: db.fn.now() })
            .then(res => res[0])
            .catch(err => console.error(err))
    }


    static async getBookedLines(phone_number, user_id, ext_no) {
        return await db.table(table).select('line_no').where({ status_id: 1, dialing_no: phone_number, user_id: user_id, ext_no: ext_no  }).orderBy('updated_at','desc').limit(1)
            .then(res => res[0])
            .catch(err => console.error(err))
    }


}




module.exports = call_lines;