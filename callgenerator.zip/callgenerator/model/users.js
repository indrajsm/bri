
const db = require('../config/database')
const table ="users";


class users{
    static async getCount(campaign_id) {
        return db.table(table).count('users.id as count')
                        .join('campaign_users', function() {
                                this.on('users.id','=','campaign_users.user_id'),
                                this.andOnVal('campaign_users.campaign_id','=',campaign_id)
                        })
                        .join('extensions','users.id','=','extensions.user_id')
                        .where( 'users.user_activity_id', 8)
                        .where('campaign_users.is_active', 1)
                        .whereNotIn(
                            'users.id',
                            db.from('call_lines').select('user_id').whereNotNull('user_id')
                        )
            .then(res => res[0])
            .catch(err => console.error(err))           
    }

    static async getUsers(campaign_id) {
        return db.table(table).select(['users.id as user_id', 'extensions.ext_no as ext_no'])
                        .join('campaign_users',function(){this.on('users.id','=','campaign_users.user_id'),this.andOnVal('campaign_users.campaign_id','=',campaign_id)})
                        .join('extensions','users.id','=','extensions.user_id')
                        .where( 'users.user_activity_id', 8)
                        .where('campaign_users.is_active', 1)
                        .whereNotIn(
                            'users.id',
                            db.from('call_lines').select('user_id').whereNotNull('user_id')
                        )
            .then(res => res)
            .catch(err => console.error(err))           
    }

}




module.exports = users;