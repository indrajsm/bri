

const db = require('../config/database')
const table = "customers";


class customers {
    

    static async updateCustomer(customer_id) {
        return await db.table(table).where('id', customer_id).limit(1).update('is_req_callfile', 0 )
            .then(res => res)
            .catch(err => console.error(err))
    }

    

    
}





module.exports = customers;