

const db = require('../config/database')
const table = "campaigns";


class campaigns {
    static async getCount() {

        return db.table(table)
                .count('id as count')
                .where('is_active', 1)
                .where('media_id', 1)
                .where('start_date', '<=', db.fn.now())
                .where('end_date', '>=', db.fn.now())
                .orderBy('last_generate_date', 'desc').limit(1)
            .then(res => res[0])
            .catch(err => console.error(err))
    }

    static async getCampaign() { 
        return db.table(table).select('id', 'name')
                    .where('is_active', 1)
                    .where('media_id', 1)
                    .where('start_date', '<=', db.fn.now())
                    .where('end_date', '>=', db.fn.now())
                    .orderBy('last_generate_date', 'asc').limit(1)
            .then(res => res[0])
            .catch(err => console.error(err))
    }

    static async getCountCampaignCustomers(campaign_id) { 
        return db.table(table).count('campaigns.id as count')
                .join('customers', 'campaigns.id', '=', 'customers.campaign_id')
                .join('campaign_users', 'campaigns.id', '=', 'campaign_users.campaign_id')
                .where('campaigns.is_active', 1)
                .where('campaigns.media_id', 1)
                .where('campaigns.id', campaign_id)
            
                .whereIn('customers.customer_status_id', [1, 2, 3])
                .whereNull('customers.outbound_category_id')
                .where('customers.next_call_date', '<=', db.fn.now())
                .where('customers.is_req_callfile', 1)
                .where('customers.is_active', 1) 
            .then(res => res[0])
            .catch(err => console.error(err))
    }

    static async getCampaignCustomers(campaign_id) {
        const ifCondition = db.raw(`IF(customers.phone_to_call=2,customers.phone_2, customers.phone_1) as phone_no`);
 
        return db.table(table).select('customers.id AS customer_id','campaigns.name as campaign_name', 'customers.campaign_id', 'customers.phone_to_call', 'customers.phone_1','customers.phone_2', 'campaign_users.user_id as user_id')
                .select(ifCondition)
                .join('customers', 'campaigns.id','=','customers.campaign_id')
                .join('campaign_users', 'campaigns.id', '=', 'campaign_users.campaign_id')
                .where('campaigns.is_active', 1)
                .where('campaigns.media_id', 1)
                .where('campaigns.id', campaign_id)
                
                .whereIn('customers.customer_status_id', [1, 2, 3])
                .whereNull('customers.outbound_category_id')
                .where('customers.next_call_date', '<=', db.fn.now())
                .where('customers.is_req_callfile',1)
                .where('customers.is_active',1)
                //.groupBy('phone_no')
                .orderBy('customers.total_call_attempt')
                .limit(1)
            .then(res => res[0])
            .catch(err => console.error(err))       
    }



    static async updateCampaign(campaign_id) {

        return await db.table(table).where('id', campaign_id).limit(1).update('last_generate_date', db.fn.now())
            .then(res => res)
            .catch(err => console.error(err))
    }


}





module.exports = campaigns;