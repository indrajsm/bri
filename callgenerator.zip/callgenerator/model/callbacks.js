
const db = require('../config/database')
const table = "callbacks";


class callbacks {
    static async getCount(campaign_id, agent_ids) {
 
        return db.table(table).count('callbacks.id as count')
                    .join('campaigns', 'callbacks.campaign_id', '=', 'campaigns.id') 
                    .join('campaign_users', function() {
                        this.on('callbacks.user_id', '=', 'campaign_users.user_id'),
                        this.onVal('campaign_users.campaign_id', '=', campaign_id)
                    })
                    .join('users', 'campaign_users.user_id', '=', 'users.id')
                    .join('extensions', 'users.id', '=', 'extensions.user_id')
                    .where('users.user_activity_id', 8)
                    .where('is_called', 0)
                    .where('campaigns.id', campaign_id)
                    .whereIn('users.id', [agent_ids])
                    .whereNotIn(
                        'users.id',
                        db.from('call_lines').select('user_id').whereNotNull('user_id')
                    )
                    //.groupBy('callbacks.id')
            .then(res => res[0])
            .catch(err => console.error(err))
    }

    static async getCallback(campaign_id, user_id) {

        return db.table(table).select(['callbacks.*', 'extensions.ext_no'])
                    .join('campaigns', 'callbacks.campaign_id', '=', 'campaigns.id') 
                    .join('campaign_users', function() {
                        this.on('callbacks.user_id', '=', 'campaign_users.user_id'),
                        this.onVal('campaign_users.campaign_id', '=', campaign_id)
                    })
                    .join('users', 'campaign_users.user_id', '=', 'users.id')
                    .join('extensions', 'users.id', '=', 'extensions.user_id')
                    .where('users.user_activity_id', 8)
                    .where('is_called', 0)
                    .where('campaigns.id', campaign_id)
                    .where('users.id', user_id)
                    .whereNotIn(
                        'users.id',
                        db.from('call_lines').select('user_id').whereNotNull('user_id')
                    )
                    .limit(1)
                    //.groupBy('callbacks.id').limit(limit)
                    
            .then(res => res[0])
            .catch(err => console.error(err))
    }

    static async updateCallBack(callback_id) {
        return db.table(table).where('id', callback_id).limit(1).update('is_called', 1)
            .then(res => res)
            .catch(err => console.error(err))
    }
}




module.exports = callbacks;