const config = require('./index')
const knex = require('knex');

const DB = knex({
  client: 'mysql',
  connection: {
    host: config.db.host,
    user: config.db.user,
    password: config.db.password,
    database: config.db.name,
    port: config.db.port
  },
  pool: { min: 0, max: 50 }
});

DB.client.pool.on('connection', (connection) => {
  //console.log('connection');
})

DB.client.pool.on('acquire', (connection) => {
  //console.log('Connection %d acquired', connection.threadId);
})
DB.client.pool.on('enqueue', (connection) => {
  //console.log('Waiting for available connection slot');
})
DB.client.pool.on('release', (connection) => {
  //console.log('Connection %d released', connection.threadId);
}) 
module.exports = DB