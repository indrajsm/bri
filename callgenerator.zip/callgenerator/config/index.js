const dotenv = require('dotenv')
const env = process.env.NODE_ENV

if (env == 'production') {
	dotenv.config({ path: './.env-production' })
} else if (env == 'staging') {
	dotenv.config({ path: './.env-staging' })
} else {
	dotenv.config({ path: './.env' })
}

const config = {
	env: env,
	timezone: 'Asia/Jakarta',
    port: process.env.PORT || 5000,   
	
    db: {
		user: process.env.DB_USER || 'root',
		password: process.env.DB_PASSWORD || 'password',
		host: process.env.DB_HOST || '',
		port: process.env.DB_PORT || 3306,
		name: process.env.DB_NAME || ''
	},
	call_file_dir: process.env.CALL_FILE_DIR,
	pbx_outgoing_dir: process.env.PBX_OUTGOING_DIR 	
}
 
module.exports = config