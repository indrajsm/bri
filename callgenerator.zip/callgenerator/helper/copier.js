const fs = require('fs-extra');

async function copy(src, dest) {
  try {
    await fs.move(src, dest, { overwrite: true, errorOnExist: true });
    return true;
  } catch (error) {
    if (error.message.includes('already exists')) {
      return false;
    }
    throw error;
  }
}

async function copier(src, dest, maxAttempts) {    
  try {
      //console.log(src, dest, maxAttempts)
      if (!await copy(src, dest)); {
          //console.log(src, dest, maxAttempts)
          for (let i = 1; i <= maxAttempts; i++) {
              if (await copy(src, `${dest}_copy${i}`)) {
                  console.log("success")
                return ;
              }
          }
        return 1 ;
      }
  } catch (error) {
    console.error(error);
  }
}


// copier(src, dest, maxAttempts);

module.exports = {copy, copier};