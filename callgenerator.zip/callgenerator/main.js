const users = require('./model/users')
const campaigns = require('./model/campaigns')
const lines = require('./model/lines')
const callbacks = require('./model/callbacks')
const callfile = require('./model/call_files')
const customers = require('./model/customers')
const {copier, copy} = require('./helper/copier')
const config = require('./config/index') 
const moment = require("moment")
const fsPromises = require('fs').promises 
const call_files = require('./model/call_files')

var currentdate = new Date();
var datetime = currentdate.getDate() + "-"
    + (currentdate.getMonth() + 1) + "-"
    + currentdate.getFullYear() + "-"
    + currentdate.getHours() + "-"
    + currentdate.getMinutes() + "-"
    + currentdate.getSeconds();

const main = async () => {

    var campaign_id;
    var campaign_name;
    var count_agent = 0;
    var count_line = 0;
    var limit = 0;
    var count_callback = 0;
    //var getCountCamp = await campaigns.getCount(); 
 
    console.log(`=========================================================================`); 
    // ambil satu campaign aktif 
    var get_campaign = await campaigns.getCampaign()
    if (get_campaign) {
        console.log(`campaign_id:${get_campaign.id}, campaign_name: ${get_campaign.name}`); 
        campaign_id = parseInt(`${get_campaign.id}`);
        campaign_name = (`${get_campaign.name}`);

        var get_agent_count = await users.getCount(campaign_id);
        count_agent = parseInt(`${get_agent_count.count}`); 
        console.log(`total available agent on campaign ${get_campaign.name}:  ${count_agent} agents`);

        const agents = await users.getUsers(campaign_id)
 
        if (get_agent_count.count > 0){
            
            const agent_ids = agents.map(e => e.user_id).join(",")
            const get_count_line = await lines.getCount();
            count_line = parseInt(`${get_count_line.count}`); 
            console.log(`total available line:  ${count_line} lines`);

            if (count_line > 0) {
                if (count_line <= count_agent)
                    limit = count_line;
                else
                    limit = count_agent;

                
                
                
                const get_count_callback = await callbacks.getCount(campaign_id, agent_ids);
                count_callback = (typeof get_count_callback !== 'undefined') ? parseInt(`${get_count_callback.count}`) : 0
                console.log(`callback data on campaign ${get_campaign.name}: ${count_callback}`);

                if (count_callback > 0) {

                    let usedLimit = 1

                    for (i = 0; i < agents.length; i++) {

                        if (usedLimit > limit) {
                            break
                        } 

                        callback_data = await callbacks.getCallback(campaign_id, agents[i].user_id)
                        if (callback_data) {
  
                            // booking call line
                            await lines.bookLines(callback_data.phone_no, agents[i].user_id, agents[i].ext_no)
                            const bookedLine = await lines.getBookedLines(callback_data.phone_no, agents[i].user_id, agents[i].ext_no)

                            if (bookedLine) {

                                const lineNo = bookedLine.line_no
                                const baseDir = config.call_file_dir
                                const createDateTime = moment(new Date() ).format("YYYY-MM-DD_HH.mm.ss")
                                const fileName = 'campaignId-' + callback_data.campaign_id + '.custID-' + callback_data.customer_id + '.phoneNo-' + callback_data.phone_no + '.' + createDateTime + '-cb.call'
                                const fullPath = baseDir + fileName;
 

                                const data = 'channel:Local/s@callout\n' +
                                            'application:Playback\n' +
                                            'set:numtodial=' + callback_data.phone_no + '\n' +
                                            'set:trunkname=trunk-telebri\n' +
                                            'set:callerid=' + `${lineNo}` + '\n' +
                                            'set:customerid=' + callback_data.customer_id + '\n' +
                                            'set:campaignid=' + callback_data.campaign_id + '\n' +
                                            'set:callbackid=' + callback_data.id + '\n' +
                                            'set:userid=' + callback_data.user_id + '\n' +
                                            'set:extno=' + callback_data.ext_no + '\n' 


                                try {
                                    // buat call file
                                    await fsPromises.writeFile(fullPath, data)

                                    const insert_id = await callfile.insertCallFiles(callback_data.campaign_id, callback_data.customer_id, fileName, fullPath)

                                    // check file
                                    const readData = await fsPromises.readFile(fullPath)

                                    if (readData) { 
                                        // pindahkan call file ke directory pbx out
                                        const result = await copy(fullPath, config.pbx_outgoing_dir + fileName)
        
                                        if (result) {
                                            // update usedLimit
                                            usedLimit++

                                            console.log(`filename: ${fileName} moved to ${config.pbx_outgoing_dir}`)
                                            await call_files.updateCallFiles(insert_id) 
                                        }
                                    } else {
                                        console.log('not exists! file: ', paths);
                                    }


                                } catch (error) {
                                    console.log(error)
                                }

                            }
                        }
                    } 

                }
                else {

                    var get_count_customer = await campaigns.getCountCampaignCustomers(campaign_id);
                    count_customer = (typeof get_count_customer !== 'undefined') ? parseInt(`${get_count_customer.count}`) : 0
                    console.log(`customer data on campaign ${get_campaign.name}: ${count_customer}`);

                    if (count_customer > 0) {

                        let usedLimit = 1

                        for (i = 0; i < agents.length; i++) {

                            if (usedLimit > limit) {
                                break
                            } 

                            customer_data = await campaigns.getCampaignCustomers(campaign_id)
                            if (customer_data) {
                                // booking call line
                                await lines.bookLines(customer_data.phone_no, agents[i].user_id, agents[i].ext_no)
                                const bookedLine = await lines.getBookedLines(customer_data.phone_no, agents[i].user_id, agents[i].ext_no)
                                

                                if (bookedLine) { 

                                    const lineNo = bookedLine.line_no
                                    const baseDir = config.call_file_dir
                                    const createDateTime = moment(new Date() ).format("YYYY-MM-DD_HH.mm.ss")
                                    const fileName = 'campaignId-' + customer_data.campaign_id + '.custID-' + customer_data.customer_id + '.phoneNo-' + customer_data.phone_no + '.' + createDateTime + '.call'
                                    const fullPath = baseDir + fileName;

                                    const  data = 'channel:Local/s@callout\n' +
                                                'application:Playback\n' +
                                                'set:numtodial=' + customer_data.phone_no + '\n' +
                                                'set:trunkname=trunk-telebri\n' +
                                                'set:callerid=' + `${lineNo}` + '\n' +
                                                'set:customerid=' + customer_data.customer_id + '\n' +
                                                'set:campaignid=' + customer_data.campaign_id + '\n' +
                                                'set:callbackid= 0' + '\n' +
                                                'set:userid=' + agents[i].user_id + '\n' +
                                                'set:extno=' + agents[i].ext_no + '\n' 

                                    try {
                                        // buat call file
                                        await fsPromises.writeFile(fullPath, data)
                                        
                                        const insert_id = await callfile.insertCallFiles(customer_data.campaign_id, customer_data.customer_id, fileName, fullPath)
                                        
                                        if (insert_id > 0) {
                                            await customers.updateCustomer(customer_data.customer_id)
                                        }

                                        // check file
                                        const readData = await fsPromises.readFile(fullPath)
                                
                                        if (readData) { 
                                            // pindahkan call file ke directory pbx out
                                            const result = await copy(fullPath, config.pbx_outgoing_dir + fileName)
        
                                            if (result) {
                                                // update usedLimit
                                                usedLimit++

                                                console.log(`filename: ${fileName} moved to ${config.pbx_outgoing_dir}`)
                                                await call_files.updateCallFiles(insert_id) 
                                            }
                                        } else {
                                            console.log('not exists! file: ', fullPath);
                                        }



                                    } catch (error) {
                                        console.log(error)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        var result = await campaigns.updateCampaign(campaign_id) 
    }
    


}




exports.main = main